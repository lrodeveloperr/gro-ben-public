import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);
const legalRoot = path.resolve(projectRoot, "..", "legal-pages-final");
const names = [
  "README.md",
  "index.md",
  "privacy.md",
  "terms.md",
  "support.md",
  "third-party-notices.md",
];
const files = new Map(
  await Promise.all(
    names.map(async (name) => [
      name,
      await readFile(path.join(legalRoot, name), "utf8"),
    ]),
  ),
);
const all = [...files.values()].join("\n");

for (const name of names) assert.ok(files.get(name)?.trim(), `${name} is empty`);
for (const name of ["index.md", "privacy.md", "terms.md", "support.md"])
  assert.match(files.get(name) || "", /^---\n[\s\S]*?\n---\n/);

for (const required of [
  "SNAP & EBT Grocery Tracker",
  "Lateef Razaq-Oyetola",
  "lrodeveloperr@gmail.com",
  "Programa de Asistencia Nutricional",
  "Tarjeta de la Familia",
])
  assert.ok(all.includes(required), `legal set missing ${required}`);

const privacy = files.get("privacy.md") || "";
const terms = files.get("terms.md") || "";
const support = files.get("support.md") || "";
assert.match(privacy, /36 Zorra Street, Toronto, Ontario M8Z 0G5, Canada/);
assert.equal(all.includes("1611"), false, "private unit number must not appear");
assert.match(terms, /monthly and annual base plans/);
assert.match(terms, /one-time, non-consumable/);
assert.match(support, /Manage or cancel in Google Play/);
assert.match(support, /Restore purchase/);
assert.match(privacy, /does not receive your full payment-card number/);

for (const stale of [
  "no subscription, in-app purchase",
  "Delete all app data",
  "número de tarjeta EBT o PAN",
  "intersticial cerrable",
  "carritos clonados",
  "es provista por",
  "Declared license: Not declared",
  "buffers@0.1.1",
])
  assert.equal(all.includes(stale), false, `stale legal wording: ${stale}`);

console.log(
  "Legal verification passed: all six GitHub files reflect purchases, PAN/Tarjeta de la Familia, tracker-only deletion, and the final dependency graph.",
);
