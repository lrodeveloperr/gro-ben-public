import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const metadata = await readFile(
  path.join(root, "src/releaseMetadata.ts"),
  "utf8",
);
const privacy = await readFile(path.join(root, "PRIVACY.md"), "utf8");
const hostedPrivacy = await readFile(
  path.join(root, "store-assets/privacy-policy.html"),
  "utf8",
);
const terms = await readFile(path.join(root, "TERMS.md"), "utf8");
const hostedTerms = await readFile(
  path.join(root, "store-assets/terms.html"),
  "utf8",
);

for (const [name, source] of [
  ["src/releaseMetadata.ts", metadata],
  ["PRIVACY.md", privacy],
  ["store-assets/privacy-policy.html", hostedPrivacy],
  ["TERMS.md", terms],
  ["store-assets/terms.html", hostedTerms],
]) {
  assert.equal(
    /\[(?:ADD|REPLACE)[^\]]+\]/.test(source),
    false,
    `${name} still contains release placeholders`,
  );
}

assert.match(metadata, /publisherLegalName:\s*'Lateef Razaq-Oyetola'/);
assert.match(metadata, /googlePlayDeveloperName:\s*'Good Use Studios'/);
assert.match(metadata, /monitoredSupportEmail:\s*'lrodeveloperr@gmail\.com'/);
assert.match(metadata, /privacyPolicyUrl:\s*'https:\/\/[^']+'/);
assert.match(metadata, /termsUrl:\s*'https:\/\/[^']+'/);
assert.match(metadata, /supportUrl:\s*'https:\/\/[^']+'/);

for (const [name, value] of [
  [
    "EXPO_PUBLIC_ANDROID_ADMOB_APP_ID",
    process.env.EXPO_PUBLIC_ANDROID_ADMOB_APP_ID,
  ],
  ["EXPO_PUBLIC_IOS_ADMOB_APP_ID", process.env.EXPO_PUBLIC_IOS_ADMOB_APP_ID],
  [
    "EXPO_PUBLIC_ANDROID_ADMOB_REWARDED_ID",
    process.env.EXPO_PUBLIC_ANDROID_ADMOB_REWARDED_ID,
  ],
  [
    "EXPO_PUBLIC_ANDROID_ADMOB_BANNER_ID",
    process.env.EXPO_PUBLIC_ANDROID_ADMOB_BANNER_ID,
  ],
  [
    "EXPO_PUBLIC_IOS_ADMOB_BANNER_ID",
    process.env.EXPO_PUBLIC_IOS_ADMOB_BANNER_ID,
  ],
  [
    "EXPO_PUBLIC_ANDROID_ADMOB_INTERSTITIAL_ID",
    process.env.EXPO_PUBLIC_ANDROID_ADMOB_INTERSTITIAL_ID,
  ],
  [
    "EXPO_PUBLIC_IOS_ADMOB_INTERSTITIAL_ID",
    process.env.EXPO_PUBLIC_IOS_ADMOB_INTERSTITIAL_ID,
  ],
]) {
  assert.match(
    value || "",
    name.endsWith("_APP_ID") ? /^ca-app-pub-\d+~\d+$/ : /^ca-app-pub-\d+\/\d+$/,
    `${name} must contain a production Google Mobile Ads identifier`,
  );
}

console.log(
  "Release metadata and production advertising identifiers are complete.",
);
