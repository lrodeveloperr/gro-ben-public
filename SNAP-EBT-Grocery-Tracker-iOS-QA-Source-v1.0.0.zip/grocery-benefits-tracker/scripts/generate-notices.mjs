import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dependencyTree = JSON.parse(
  execFileSync('npm', ['ls', '--omit=dev', '--all', '--json'], {
    cwd: projectRoot,
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
  }),
);
const lockfile = JSON.parse(
  readFileSync(join(projectRoot, 'package-lock.json'), 'utf8'),
);

function nameFromLockPath(lockPath) {
  return lockPath.split('node_modules/').at(-1);
}

const installedPaths = new Map();
for (const [lockPath, metadata] of Object.entries(lockfile.packages ?? {})) {
  if (!lockPath.includes('node_modules/') || !metadata.version) continue;
  const name = nameFromLockPath(lockPath);
  installedPaths.set(`${name}@${metadata.version}`, join(projectRoot, lockPath));
}

const dependencies = new Map();
function collect(tree) {
  for (const [name, metadata] of Object.entries(tree ?? {})) {
    if (!metadata.version) {
      collect(metadata.dependencies);
      continue;
    }
    const id = `${name}@${metadata.version}`;
    dependencies.set(id, { id, name, version: metadata.version });
    collect(metadata.dependencies);
  }
}
collect(dependencyTree.dependencies);

function readLegalText(packagePath) {
  if (!packagePath || !existsSync(packagePath)) return '';

  const filenames = readdirSync(packagePath)
    .filter((name) =>
      /^(licen[cs]e|copying|notice)(?:\..*)?$/i.test(name),
    )
    .sort((a, b) => a.localeCompare(b));

  return filenames
    .map((filename) => {
      const text = readFileSync(join(packagePath, filename), 'utf8').trim();
      return text ? `${filename}\n${text}` : '';
    })
    .filter(Boolean)
    .join('\n\n');
}

const groups = new Map();
for (const dependency of [...dependencies.values()].sort((a, b) =>
  a.id.localeCompare(b.id),
)) {
  const packagePath = installedPaths.get(dependency.id);
  let packageMetadata = {};
  if (packagePath && existsSync(join(packagePath, 'package.json'))) {
    packageMetadata = JSON.parse(
      readFileSync(join(packagePath, 'package.json'), 'utf8'),
    );
  }

  const declaredLicense = packageMetadata.license ?? 'Not declared';
  const legalText = readLegalText(packagePath);
  const normalizedText =
    legalText ||
    `No separate license or notice file was present in the installed package.\nDeclared license: ${declaredLicense}`;
  const key = createHash('sha256')
    .update(`${declaredLicense}\n${normalizedText}`)
    .digest('hex');
  const group = groups.get(key) ?? {
    packages: [],
    declaredLicense,
    legalText: normalizedText,
  };
  group.packages.push(dependency.id);
  groups.set(key, group);
}

const sortedGroups = [...groups.values()].sort((a, b) =>
  a.packages[0].localeCompare(b.packages[0]),
);

const sections = sortedGroups
  .map(
    (group) =>
      `Packages:\n${group.packages.map((name) => `- ${name}`).join('\n')}\n\n` +
      `Declared license: ${group.declaredLicense}\n\n${group.legalText}`,
  );

const noticeText = [
  'SNAP & EBT Grocery Tracker — Third-Party Notices',
  '',
  'Generated from the installed production dependency graph for version 1.0.0.',
  'The final signed binaries must be checked again because native build tooling may add or remove components.',
  '',
  `Packages inventoried: ${dependencies.size}`,
  '',
  ...sections.flatMap((section) => [
    '='.repeat(72),
    section,
    '',
  ]),
].join('\n');

const markdownSections = sortedGroups.flatMap((group, index) => [
  `## License group ${index + 1}`,
  '',
  '**Packages:**',
  '',
  ...group.packages.map((name) => `- \`${name}\``),
  '',
  `**Declared license:** \`${group.declaredLicense}\``,
  '',
  '````text',
  group.legalText,
  '````',
  '',
]);

const noticeMarkdown = [
  '---',
  'title: Third-Party Notices — SNAP & EBT Grocery Tracker',
  'description: Open-source software notices for SNAP & EBT Grocery Tracker version 1.0.0',
  '---',
  '',
  '# SNAP & EBT Grocery Tracker Third-Party Notices',
  '',
  '**Applies to:** Version 1.0.0 source dependency graph for Android and iOS  ',
  `**Production packages inventoried:** ${dependencies.size}`,
  '',
  'The App uses third-party platforms, services, and open-source software. Their inclusion does not mean that their providers or contributors sponsor or endorse the App. Third-party names and marks remain the property of their respective owners.',
  '',
  'This inventory was generated from the frozen npm production dependency graph. Native Gradle and CocoaPods tooling can add or remove binary components, so this file must be regenerated and compared with the final signed Android and iOS store archives before submission.',
  '',
  '---',
  '',
  '# Avisos de terceros — Español',
  '',
  'La Aplicación usa plataformas, servicios y software de código abierto de terceros. Su inclusión no significa que sus proveedores o colaboradores patrocinen o respalden la Aplicación. Los nombres y marcas de terceros pertenecen a sus respectivos titulares.',
  '',
  'Este inventario se generó del grafo congelado de dependencias de producción de npm. Las herramientas nativas de Gradle y CocoaPods pueden añadir o eliminar componentes binarios; por eso, este archivo debe regenerarse y compararse con los archivos finales firmados de Android y iOS antes de enviarlos a las tiendas.',
  '',
  '---',
  '',
  ...markdownSections,
].join('\n');

writeFileSync(join(projectRoot, 'THIRD_PARTY_NOTICES.txt'), noticeText);
writeFileSync(
  join(projectRoot, '..', 'legal-pages-final', 'third-party-notices.md'),
  noticeMarkdown,
);
writeFileSync(
  join(projectRoot, 'src', 'thirdPartyNotices.ts'),
  `// Generated by scripts/generate-notices.mjs. Do not edit by hand.\n` +
    `export const THIRD_PARTY_NOTICES = ${JSON.stringify(noticeText)};\n`,
);

console.log(
  `Generated notices for ${dependencies.size} production dependency packages in ${groups.size} license groups.`,
);
