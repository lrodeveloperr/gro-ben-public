import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (name) => readFile(path.join(root, name), "utf8");
const readJson = async (name) => JSON.parse(await read(name));
const app = (await readJson("app.json")).expo;
const eas = await readJson("eas.json");
const pkg = await readJson("package.json");
const appSource = await read("App.tsx");
const adsSource = await read("src/ads.tsx");
const billingSource = await read("src/billing.ts");
const storageSource = await read("src/storage.ts");
const codecSource = await read("src/storageCodec.ts");
const i18nSource = await read("src/i18n.ts");
const reportingSource = await read("src/reporting.ts");
const xlsxSource = await read("src/xlsxReport.ts");
const dynamicConfig = await read("app.config.js");
const metadata = await read("src/releaseMetadata.ts");

assert.equal(app.name, "SNAP & EBT Grocery Tracker");
assert.equal(app.version, "1.0.0");
assert.equal(pkg.version, app.version);
assert.deepEqual(app.platforms, ["ios", "android"]);
assert.equal(app.updates.enabled, false);
assert.equal(app.ios.bundleIdentifier, "com.goodusestudios.snapebtgrocerytracker");
assert.equal(app.ios.deploymentTarget, "16.4");
assert.equal(app.ios.privacyManifests.NSPrivacyTracking, false);
assert.equal(app.android.package, "com.goodusestudios.snapebtgrocerytracker");
assert.equal(app.android.allowBackup, false);
assert.equal(app.android.versionCode, 1);
assert.ok(app.locales.en && app.locales["es-PR"]);

for (const permission of [
  "android.permission.INTERNET",
  "android.permission.ACCESS_NETWORK_STATE",
])
  assert.ok(app.android.permissions.includes(permission));
for (const permission of [
  "android.permission.CAMERA",
  "android.permission.RECORD_AUDIO",
  "android.permission.ACCESS_FINE_LOCATION",
  "android.permission.POST_NOTIFICATIONS",
])
  assert.ok(app.android.blockedPermissions.includes(permission));

const findPlugin = (name) =>
  app.plugins.find((plugin) =>
    Array.isArray(plugin) ? plugin[0] === name : plugin === name,
  );
for (const plugin of [
  "expo-iap",
  "expo-sqlite",
  "./plugins/withLocalOnlyDatabase",
  "react-native-google-mobile-ads",
])
  assert.ok(findPlugin(plugin), `missing plugin ${plugin}`);
const adsPlugin = findPlugin("react-native-google-mobile-ads");
assert.equal(adsPlugin[1].delayAppMeasurementInit, true);
assert.equal(adsPlugin[1].optimizeAdLoading, true);

for (const dependency of [
  "expo-iap",
  "expo-sqlite",
  "expo-crypto",
  "expo-file-system",
  "expo-print",
  "expo-sharing",
  "jszip",
  "react-native-google-mobile-ads",
])
  assert.ok(pkg.dependencies[dependency], `missing ${dependency}`);
assert.equal(pkg.dependencies["@react-native-async-storage/async-storage"], undefined);

for (const behavior of [
  "ProgramOnboarding",
  'type Tab = "cart" | "purchases" | "wallet" | "settings"',
  "useAdFreeEntitlement",
  "WalletBanner",
  "InlineReportAd",
  "showRewardedReportAd",
  "shareExcelReport",
  "sharePdfReport",
  "Tarjeta de la Familia",
  "Informes que valen la pena ver",
])
  assert.ok(appSource.includes(behavior), `missing app behavior: ${behavior}`);
assert.equal(appSource.includes("Informes que vale la pena ver"), false);
assert.equal(appSource.includes("Reemplazar y clonar"), false);

assert.ok(storageSource.includes("PRAGMA journal_mode = WAL"));
assert.ok(storageSource.includes("withExclusiveTransactionAsync"));
assert.ok(storageSource.includes("recovery_snapshots"));
assert.ok(storageSource.includes("CryptoDigestAlgorithm.SHA256"));
assert.ok(codecSource.includes("version: 2"));
assert.ok(codecSource.includes('value.program !== "pan-pr"'));

assert.ok(adsSource.includes("AdsConsent.gatherConsent"));
assert.ok(adsSource.includes("requestNonPersonalizedAdsOnly: true"));
assert.ok(adsSource.includes("MAX_CACHE_AGE_MS = 50 * 60 * 1000"));
assert.ok(adsSource.includes("LOAD_TIMEOUT_MS"));
assert.ok(adsSource.includes("BannerAdSize.ANCHORED_ADAPTIVE_BANNER"));
assert.ok(billingSource.includes('ANDROID_MONTHLY_BASE_PLAN_ID = "monthly"'));
assert.ok(billingSource.includes('ANDROID_ANNUAL_BASE_PLAN_ID = "annual"'));
assert.ok(billingSource.includes('IOS_LIFETIME_PRODUCT_ID = "remove_ads_forever"'));
assert.ok(billingSource.includes("finishTransaction"));
assert.ok(billingSource.includes("getActiveSubscriptions"));
assert.ok(billingSource.includes("getAvailablePurchases"));

assert.ok(i18nSource.includes("Programa") || appSource.includes("Programa"));
assert.ok(i18nSource.includes("Te damos la bienvenida"));
assert.ok(i18nSource.includes("Archivo de Excel"));
assert.ok(reportingSource.includes("@page{size:Letter"));
assert.ok(reportingSource.includes("file.delete()"));
assert.ok(
  reportingSource.includes("SNAP &amp; EBT GROCERY TRACKER") &&
    xlsxSource.includes("SNAP & EBT Grocery Tracker"),
);
assert.ok(xlsxSource.includes("application/vnd.openxmlformats"));
assert.ok(xlsxSource.includes("Historial de compras"));

for (const key of [
  "EXPO_PUBLIC_ANDROID_ADMOB_APP_ID",
  "EXPO_PUBLIC_IOS_ADMOB_APP_ID",
  "EXPO_PUBLIC_ANDROID_ADMOB_BANNER_ID",
  "EXPO_PUBLIC_IOS_ADMOB_BANNER_ID",
  "EXPO_PUBLIC_ANDROID_ADMOB_REWARDED_ID",
  "EXPO_PUBLIC_ANDROID_ADMOB_INTERSTITIAL_ID",
  "EXPO_PUBLIC_IOS_ADMOB_INTERSTITIAL_ID",
])
  assert.ok(dynamicConfig.includes(key), `production gate missing ${key}`);
assert.ok(dynamicConfig.includes("Production builds cannot enable simulated purchases"));
assert.equal(eas.build.preview.android.buildType, "apk");
assert.equal(eas.build.preview.env.EXPO_PUBLIC_QA_PURCHASES, "1");
assert.equal(eas.build.production.android.buildType, "app-bundle");
assert.equal(eas.build.production.env.EXPO_PUBLIC_QA_PURCHASES, "0");

for (const pattern of [
  /appName:\s*'SNAP & EBT Grocery Tracker'/,
  /googlePlayDeveloperName:\s*'Good Use Studios'/,
  /publisherLegalName:\s*'Lateef Razaq-Oyetola'/,
  /monitoredSupportEmail:\s*'lrodeveloperr@gmail\.com'/,
  /lrodeveloperr\.github\.io\/SNAP-EBT-Grocery-Tracker\/privacy\.html/,
])
  assert.match(metadata, pattern);

const notices = await read("THIRD_PARTY_NOTICES.txt");
assert.ok(notices.length > 100_000);
for (const dependency of Object.keys(pkg.dependencies))
  assert.ok(notices.includes(`${dependency}@`), `notices missing ${dependency}`);

const icon = await readFile(path.join(root, "assets/icon.png"));
assert.equal(icon.readUInt32BE(16), 1024);
assert.equal(icon.readUInt32BE(20), 1024);

for (const name of [
  "PRIVACY.md",
  "TERMS.md",
  "STORE_LISTING.md",
  "APP_STORE_LISTING.md",
  "RELEASE_CHECKLIST.md",
  "TEST_MATRIX.md",
  "plugins/withLocalOnlyDatabase.js",
])
  assert.equal((await stat(path.join(root, name))).isFile(), true);

console.log(
  "Package verification passed: billing, PAN labels, durable local storage, ad safeguards, exports, and release gates are present.",
);
