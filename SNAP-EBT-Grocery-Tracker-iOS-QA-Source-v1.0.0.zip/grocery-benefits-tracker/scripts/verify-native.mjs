import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (name) => readFile(path.join(root, name), "utf8");

const androidGradle = await read("android/app/build.gradle");
const androidManifest = await read("android/app/src/main/AndroidManifest.xml");
assert.match(
  androidGradle,
  /applicationId 'com\.goodusestudios\.snapebtgrocerytracker\.qa'/,
);
assert.match(androidManifest, /android:allowBackup="false"/);
assert.match(androidManifest, /com\.android\.vending\.BILLING/);
assert.match(androidManifest, /ca-app-pub-3940256099942544~3347511713/);

const iosRoot = path.join(root, "ios");
const iosAppDirectory = (await readdir(iosRoot, { withFileTypes: true })).find(
  (entry) => entry.isDirectory() && entry.name.endsWith("QA"),
);
assert.ok(iosAppDirectory, "missing generated iOS QA application directory");
const iosProjectName = `${iosAppDirectory.name}.xcodeproj/project.pbxproj`;
const iosProject = await read(path.join("ios", iosProjectName));
const iosInfo = await read(path.join("ios", iosAppDirectory.name, "Info.plist"));
const appDelegate = await read(
  path.join("ios", iosAppDirectory.name, "AppDelegate.swift"),
);
assert.match(
  iosProject,
  /PRODUCT_BUNDLE_IDENTIFIER = "com\.goodusestudios\.snapebtgrocerytracker\.qa"/,
);
assert.match(iosInfo, /ca-app-pub-3940256099942544~1458002511/);
assert.match(appDelegate, /excludeTrackerDatabaseFromBackup\(\)/);
assert.match(appDelegate, /isExcludedFromBackup = true/);

console.log(
  "Native QA verification passed: separate package IDs, test AdMob application IDs, billing permission, and local-only backup settings are present.",
);
