# QA Native Build Handoff

## Android APK

The QA application ID is `com.goodusestudios.snapebtgrocerytracker.qa`. It uses Google's official test AdMob application/ad-unit IDs and clearly labelled simulated purchase controls. No purchase can charge money in this profile.

### EAS Build

After signing in to an Expo account:

```sh
npm install
npx eas-cli login
npx eas-cli build --platform android --profile preview
```

The `preview` profile produces a directly installable APK. Download the completed `.apk` from the EAS build page and install it on the Android phone. No converter is involved.

### Local Android Studio / SDK build

Requirements: JDK 17, Android SDK/Build Tools 36, and the Android/NDK versions requested by the generated Gradle project.

```sh
npm install
env EXPO_OFFLINE=1 __UNSAFE_EXPO_HOME_DIRECTORY=/tmp/snap-expo-home EXPO_PUBLIC_QA_PURCHASES=1 npx expo prebuild --clean --no-install
cd android
env EXPO_PUBLIC_QA_PURCHASES=1 ./gradlew :app:assembleRelease
```

The debug-signed QA test output is normally:

`android/app/build/outputs/apk/release/app-release.apk`

This key is for device testing only and must never be used for a store release.

## iOS QA

An iOS simulator build can be requested with:

```sh
npx eas-cli build --platform ios --profile simulator
```

A physical-device/TestFlight build requires an Apple Developer account, App Store Connect configuration, signing credentials, and a TestFlight-compatible EAS profile or macOS/Xcode archive. The iOS QA bundle ID is `com.goodusestudios.snapebtgrocerytracker.qa`.

## What QA purchases test

- Android displays `$0.99` monthly and `$6.99` annual test plans.
- iOS displays the `$12.99` lifetime test purchase.
- Buttons are labelled **TEST MODE** and only change the local entitlement state.
- The reset control returns the App to the free ad-supported state.
- Official Google test ads can validate placement and availability behavior.

Real Google Play or Apple billing can only be validated later with configured store products and licensed sandbox/internal-test accounts. A directly installed APK cannot validate live Google Play subscription products.

## Production safety

Production builds require `EXPO_PUBLIC_BUILD_PROFILE=production`, disable simulated purchases, use the production package IDs, and fail unless every required live AdMob ID is present and is not a Google test ID. Live identifiers and signing credentials are intentionally absent from this source.
