# Evidence Register

## Product boundary

- USDA eligible-food guidance: https://www.fns.usda.gov/snap/eligible-food-items
- USDA SNAP program: https://www.fns.usda.gov/snap/supplemental-nutrition-assistance-program
- USDA state food-restriction materials: https://www.fns.usda.gov/resources?f%5B0%5D=program%3A2&f%5B1%5D=resource_type%3A401

The app never infers official eligibility and stores only user classifications.

## Store and advertising boundary

- Apple App Review Guidelines: https://developer.apple.com/app-store/review/guidelines/
- Apple App Tracking Transparency: https://developer.apple.com/documentation/apptrackingtransparency
- Apple third-party SDK/privacy manifest requirements: https://developer.apple.com/support/third-party-SDK-requirements/
- Google Play Ads policy: https://support.google.com/googleplay/android-developer/answer/9857753
- Google disruptive/unexpected ads policy: https://support.google.com/googleplay/android-developer/answer/12271244
- AdMob interstitial guidance: https://developers.google.com/admob/android/interstitial
- AdMob rewarded guidance: https://developers.google.com/admob/android/rewarded
- AdMob UMP/privacy guidance: https://developers.google.com/admob/android/privacy
- Android Auto Backup: https://developer.android.com/identity/data/autobackup

Implementation: UMP before requests; non-personalized ads; no shopping request extras; rewarded opt-in; interstitial after details close; shared 30-minute cap; precache refresh; unavailable fallback.

## Publisher boundary

- CRA GST/HST registration: https://www.canada.ca/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/when-register-charge.html

The consumer launch is U.S.-only while publisher-side Canadian obligations remain applicable.
