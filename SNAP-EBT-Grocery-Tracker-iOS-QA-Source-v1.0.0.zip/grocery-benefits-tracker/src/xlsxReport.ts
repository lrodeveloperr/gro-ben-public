import JSZip from "jszip";

import {
  itemTotalCents,
  totalsFromPurchases,
  type Language,
  type Purchase,
} from "./domain";
import { dateLabel, statusLabel, t } from "./i18n";

export type XlsxReportInput = {
  purchases: Purchase[];
  language: Language;
  title: string;
  scope: string;
  partial?: boolean;
};

type Cell =
  | { value: string; style?: number }
  | { value: number; style?: number };

function xml(value: unknown) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function columnName(index: number) {
  let value = index + 1;
  let result = "";
  while (value > 0) {
    const remainder = (value - 1) % 26;
    result = String.fromCharCode(65 + remainder) + result;
    value = Math.floor((value - 1) / 26);
  }
  return result;
}

function cellXml(cell: Cell, row: number, column: number) {
  const reference = `${columnName(column)}${row}`;
  const style = cell.style === undefined ? "" : ` s="${cell.style}"`;
  if (typeof cell.value === "number")
    return `<c r="${reference}"${style}><v>${cell.value}</v></c>`;
  return `<c r="${reference}" t="inlineStr"${style}><is><t xml:space="preserve">${xml(cell.value)}</t></is></c>`;
}

function worksheetXml(
  rows: Cell[][],
  widths: number[],
  options: { freezeHeader?: boolean; autoFilter?: boolean } = {},
) {
  const rowXml = rows
    .map(
      (cells, rowIndex) =>
        `<row r="${rowIndex + 1}">${cells
          .map((cell, columnIndex) => cellXml(cell, rowIndex + 1, columnIndex))
          .join("")}</row>`,
    )
    .join("");
  const columns = widths
    .map(
      (width, index) =>
        `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`,
    )
    .join("");
  const lastColumn = columnName(Math.max(0, widths.length - 1));
  const lastRow = Math.max(1, rows.length);
  const freeze = options.freezeHeader
    ? '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/>'
    : '<selection activeCell="A1" sqref="A1"/>';
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetViews><sheetView workbookViewId="0">${freeze}</sheetView></sheetViews>
  <sheetFormatPr defaultRowHeight="18"/>
  <cols>${columns}</cols>
  <sheetData>${rowXml}</sheetData>
  ${options.autoFilter ? `<autoFilter ref="A1:${lastColumn}${lastRow}"/>` : ""}
</worksheet>`;
}

function local(language: Language, english: string, spanish: string) {
  return language === "es-PR" ? spanish : english;
}

function buildRows(input: XlsxReportInput) {
  const totals = totalsFromPurchases(input.purchases);
  const summary: Cell[][] = [
    [{ value: "SNAP & EBT Grocery Tracker", style: 1 }],
    [{ value: input.title, style: 4 }],
    [{ value: input.scope }],
    [{ value: t(input.language, "disclaimer"), style: 5 }],
    [],
    [
      { value: local(input.language, "Metric", "Métrica"), style: 2 },
      { value: local(input.language, "Value", "Valor"), style: 2 },
    ],
    [
      { value: t(input.language, "benefitsUsed") },
      { value: totals.eligibleCents / 100, style: 3 },
    ],
    [
      { value: t(input.language, "totalSpent") },
      { value: totals.totalCents / 100, style: 3 },
    ],
    [
      { value: t(input.language, "purchases") },
      { value: input.purchases.length },
    ],
    [
      { value: t(input.language, "itemCount") },
      { value: totals.itemCount },
    ],
    [
      { value: statusLabel(input.language, "not-eligible") },
      { value: totals.notEligibleCents / 100, style: 3 },
    ],
    [
      { value: statusLabel(input.language, "unsure") },
      { value: totals.unsureCents / 100, style: 3 },
    ],
  ];

  const purchaseRows: Cell[][] = [
    (input.language === "es-PR"
      ? [
          "Fecha",
          "Tienda",
          "Tarjeta de beneficios",
          "Artículos",
          "Beneficios usados",
          "Marcado como no elegible",
          "No estoy seguro",
          "Total",
        ]
      : [
          "Date",
          "Store",
          "Benefit card",
          "Items",
          "Benefits used",
          "Marked not eligible",
          "Not sure",
          "Total",
        ]).map((value) => ({ value, style: 2 })),
    ...input.purchases.map((purchase) => [
      { value: dateLabel(input.language, purchase.completedAt) },
      { value: purchase.store },
      { value: purchase.cardName || t(input.language, "noCard") },
      { value: purchase.items.length },
      { value: purchase.eligibleCents / 100, style: 3 },
      { value: purchase.notEligibleCents / 100, style: 3 },
      { value: purchase.unsureCents / 100, style: 3 },
      {
        value:
          (purchase.eligibleCents +
            purchase.notEligibleCents +
            purchase.unsureCents) /
          100,
        style: 3,
      },
    ]),
  ];

  const itemRows: Cell[][] = [
    (input.language === "es-PR"
      ? [
          "Fecha",
          "Tienda",
          "Artículo",
          "Cantidad",
          "Precio por unidad",
          "Clasificación",
          "Total del artículo",
        ]
      : [
          "Date",
          "Store",
          "Item",
          "Quantity",
          "Unit price",
          "Classification",
          "Item total",
        ]).map((value) => ({ value, style: 2 })),
    ...input.purchases.flatMap((purchase) =>
      purchase.items.map((item) => [
        { value: dateLabel(input.language, purchase.completedAt) },
        { value: purchase.store },
        { value: item.name },
        { value: item.quantity },
        { value: item.priceCents / 100, style: 3 },
        { value: statusLabel(input.language, item.eligibility) },
        { value: itemTotalCents(item) / 100, style: 3 },
      ]),
    ),
  ];

  return { summary, purchaseRows, itemRows };
}

export async function createXlsxReport(input: XlsxReportInput) {
  const zip = new JSZip();
  const { summary, purchaseRows, itemRows } = buildRows(input);
  const sheetNames = [
    local(input.language, "Summary", "Resumen"),
    local(input.language, "Purchase History", "Historial de compras"),
    local(input.language, "Item Details", "Detalles de artículos"),
  ];

  zip.file(
    "[Content_Types].xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>`,
  );
  zip.file(
    "_rels/.rels",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`,
  );
  zip.file(
    "xl/workbook.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <bookViews><workbookView activeTab="0"/></bookViews>
  <sheets>${sheetNames
    .map(
      (name, index) =>
        `<sheet name="${xml(name)}" sheetId="${index + 1}" r:id="rId${index + 1}"/>`,
    )
    .join("")}</sheets>
</workbook>`,
  );
  zip.file(
    "xl/_rels/workbook.xml.rels",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/>
  <Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`,
  );
  zip.file(
    "xl/styles.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="1"><numFmt numFmtId="164" formatCode="$#,##0.00"/></numFmts>
  <fonts count="4">
    <font><sz val="11"/><color rgb="FF102D2A"/><name val="Arial"/></font>
    <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
    <font><b/><sz val="18"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
    <font><b/><sz val="13"/><color rgb="FF102D2A"/><name val="Arial"/></font>
  </fonts>
  <fills count="5">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF102D2A"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF0E765D"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFF5F2E9"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="6">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
    <xf numFmtId="0" fontId="1" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
    <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>
    <xf numFmtId="0" fontId="0" fillId="4" borderId="0" xfId="0" applyFill="1" applyAlignment="1"><alignment wrapText="1"/></xf>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`,
  );
  zip.file(
    "xl/worksheets/sheet1.xml",
    worksheetXml(summary, [34, 20]),
  );
  zip.file(
    "xl/worksheets/sheet2.xml",
    worksheetXml(purchaseRows, [16, 24, 24, 11, 18, 22, 16, 16], {
      freezeHeader: true,
      autoFilter: true,
    }),
  );
  zip.file(
    "xl/worksheets/sheet3.xml",
    worksheetXml(itemRows, [16, 24, 30, 12, 18, 28, 18], {
      freezeHeader: true,
      autoFilter: true,
    }),
  );
  const now = new Date().toISOString();
  zip.file(
    "docProps/core.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:creator>SNAP &amp; EBT Grocery Tracker</dc:creator>
  <dc:title>${xml(input.title)}</dc:title>
  <dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created>
</cp:coreProperties>`,
  );
  zip.file(
    "docProps/app.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>SNAP &amp; EBT Grocery Tracker</Application>
  <AppVersion>1.0.0</AppVersion>
</Properties>`,
  );

  return zip.generateAsync({
    type: "uint8array",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
  });
}
