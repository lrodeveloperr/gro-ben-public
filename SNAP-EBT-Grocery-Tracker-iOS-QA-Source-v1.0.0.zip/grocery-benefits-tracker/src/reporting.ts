import { Directory, File, Paths } from "expo-file-system";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";

import {
  formatCents,
  itemTotalCents,
  totalsFromPurchases,
  type Language,
  type Purchase,
} from "./domain";
import { dateLabel, statusLabel, t } from "./i18n";
import { createXlsxReport } from "./xlsxReport";

type ReportInput = {
  purchases: Purchase[];
  language: Language;
  title: string;
  scope: string;
  partial?: boolean;
};

const green = "FF0E765D";
const dark = "FF102D2A";
const cream = "FFF5F2E9";
const orange = "FFE98B55";
const slate = "FF718197";
const white = "FFFFFFFF";

function cleanFileName(title: string) {
  return (
    title
      .toLocaleLowerCase("en-US")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "report"
  );
}

export function cleanupTemporaryReports() {
  try {
    const pending = [new Directory(Paths.cache)];
    while (pending.length > 0) {
      const directory = pending.pop();
      if (!directory) break;
      for (const entry of directory.list()) {
        if (entry instanceof Directory) {
          pending.push(entry);
        } else if (/\.(xlsx|pdf)$/i.test(entry.name)) {
          entry.delete();
        }
      }
    }
  } catch {
    // Cache cleanup is best-effort and must never block the tracker.
  }
}

function htmlEscape(value: unknown) {
  return String(value ?? "").replace(
    /[&<>"']/g,
    (character) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      })[character] || character,
  );
}

function local(language: Language, english: string, spanish: string) {
  return language === "es-PR" ? spanish : english;
}

function reportRows(purchases: Purchase[]) {
  return purchases.flatMap((purchase) =>
    purchase.items.map((item) => ({ purchase, item })),
  );
}

async function yieldToInterface(index: number) {
  if (index > 0 && index % 250 === 0)
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
}

export async function shareExcelReport(input: ReportInput) {
  const output = await createXlsxReport(input);
  const file = new File(
    Paths.cache,
    `${cleanFileName(input.title)}-${Date.now()}.xlsx`,
  );
  file.create({ overwrite: true, intermediates: true });
  file.write(output);
  try {
    await Sharing.shareAsync(file.uri, {
      mimeType:
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      dialogTitle: t(input.language, "downloadExcel"),
    });
  } finally {
    file.delete();
  }
}

export async function sharePdfReport(input: ReportInput) {
  const totals = totalsFromPurchases(input.purchases);
  const total = Math.max(1, totals.totalCents);
  const eligibleAngle = Math.round((360 * totals.eligibleCents) / total);
  const otherAngle = Math.round(
    (360 * (totals.eligibleCents + totals.notEligibleCents)) / total,
  );
  const rows = input.purchases
    .map(
      (purchase) =>
        `<tr><td>${htmlEscape(dateLabel(input.language, purchase.completedAt))}</td><td>${htmlEscape(purchase.store)}</td><td>${htmlEscape(purchase.cardName || t(input.language, "noCard"))}</td><td>${htmlEscape(formatCents(purchase.eligibleCents, input.language))}</td><td>${htmlEscape(formatCents(purchase.eligibleCents + purchase.notEligibleCents + purchase.unsureCents, input.language))}</td></tr>`,
    )
    .join("");
  const itemRows = reportRows(input.purchases)
    .map(
      ({ purchase, item }) =>
        `<tr><td>${htmlEscape(dateLabel(input.language, purchase.completedAt))}</td><td>${htmlEscape(item.name)}</td><td>${item.quantity}</td><td>${htmlEscape(statusLabel(input.language, item.eligibility))}</td><td>${htmlEscape(formatCents(itemTotalCents(item), input.language))}</td></tr>`,
    )
    .join("");
  const html = `<!doctype html><html lang="${input.language}"><head><meta charset="utf-8"><style>
    @page{size:Letter;margin:.55in}*{box-sizing:border-box}body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;margin:0;color:#102d2a;font-size:10px}header{margin:-.55in -.55in 28px;padding:.42in .55in .3in;background:#102d2a;color:#fff}header small{color:#bde7d7;font-weight:800;letter-spacing:.12em}h1{margin:7px 0 4px;font-size:25px}header p{margin:0;color:#d3e8e0}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.kpi{padding:15px;border-radius:10px;background:#0e765d;color:#fff}.kpi:nth-child(2){background:#e98b55}.kpi:nth-child(3){background:#718197}.kpi small{font-weight:800}.kpi b{display:block;margin-top:5px;font-size:21px}.mix{display:grid;grid-template-columns:120px 1fr;gap:22px;align-items:center;margin:24px 0;padding:18px;border:1px solid #dce5df;border-radius:12px}.pie{width:105px;height:105px;border-radius:50%;background:conic-gradient(#0e765d 0 ${eligibleAngle}deg,#e98b55 ${eligibleAngle}deg ${otherAngle}deg,#718197 ${otherAngle}deg 360deg);position:relative}.pie:after{content:"";position:absolute;inset:25px;border-radius:50%;background:#fff}.legend div{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #e5ebe8}.legend i{display:inline-block;width:8px;height:8px;margin-right:6px;border-radius:3px}h2{margin:22px 0 8px;font-size:16px}table{width:100%;border-collapse:collapse;page-break-inside:auto}thead{display:table-header-group}tr{page-break-inside:avoid}th{padding:8px 6px;background:#0e765d;color:#fff;text-align:left}td{padding:7px 6px;border-bottom:1px solid #e2e9e5}tbody tr:nth-child(even){background:#f4f8f6}.notice{margin-top:18px;padding:11px;border-radius:9px;background:#eef4f1;color:#526c63;font-size:8px}.page-break{page-break-before:always}footer{margin-top:18px;padding-top:8px;border-top:1px solid #dce5df;color:#71837c;font-size:8px}
  </style></head><body><header><small>SNAP &amp; EBT GROCERY TRACKER</small><h1>${htmlEscape(input.language === "es-PR" ? "Resumen" : "Summary")}</h1><p>${htmlEscape(input.title)} · ${htmlEscape(input.scope)}</p></header>
  <section class="kpis"><div class="kpi"><small>${htmlEscape(t(input.language, "benefitsUsed").toLocaleUpperCase())}</small><b>${htmlEscape(formatCents(totals.eligibleCents, input.language))}</b></div><div class="kpi"><small>${htmlEscape(t(input.language, "purchases").toLocaleUpperCase())}</small><b>${input.purchases.length}</b></div><div class="kpi"><small>${htmlEscape(t(input.language, "itemCount").toLocaleUpperCase())}</small><b>${totals.itemCount}</b></div></section>
  <section class="mix"><div class="pie"></div><div class="legend"><h2>${htmlEscape(local(input.language, "Spending mix", "Distribución del gasto"))}</h2><div><span><i style="background:#0e765d"></i>${htmlEscape(statusLabel(input.language, "eligible"))}</span><b>${htmlEscape(formatCents(totals.eligibleCents, input.language))}</b></div><div><span><i style="background:#e98b55"></i>${htmlEscape(statusLabel(input.language, "not-eligible"))}</span><b>${htmlEscape(formatCents(totals.notEligibleCents, input.language))}</b></div><div><span><i style="background:#718197"></i>${htmlEscape(statusLabel(input.language, "unsure"))}</span><b>${htmlEscape(formatCents(totals.unsureCents, input.language))}</b></div></div></section>
  <h2>${htmlEscape(t(input.language, "purchases"))}</h2><table><thead><tr><th>${htmlEscape(local(input.language, "Date", "Fecha"))}</th><th>${htmlEscape(local(input.language, "Store", "Tienda"))}</th><th>${htmlEscape(t(input.language, "card"))}</th><th>${htmlEscape(t(input.language, "benefitsUsed"))}</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table>
  <div class="page-break"></div><header><small>SNAP &amp; EBT GROCERY TRACKER</small><h1>${htmlEscape(local(input.language, "Item details", "Detalles de artículos"))}</h1><p>${htmlEscape(input.scope)}</p></header><table><thead><tr><th>${htmlEscape(local(input.language, "Date", "Fecha"))}</th><th>${htmlEscape(t(input.language, "itemName"))}</th><th>${htmlEscape(t(input.language, "quantity"))}</th><th>${htmlEscape(t(input.language, "classification"))}</th><th>Total</th></tr></thead><tbody>${itemRows}</tbody></table>
  <p class="notice">${htmlEscape(t(input.language, "disclaimer"))}</p><footer>SNAP &amp; EBT Grocery Tracker · ${htmlEscape(new Intl.DateTimeFormat(input.language === "es-PR" ? "es-PR" : "en-US", { dateStyle: "medium" }).format(new Date()))}</footer></body></html>`;
  const result = await Print.printToFileAsync({
    html,
    width: 612,
    height: 792,
    base64: false,
  });
  const file = new File(result.uri);
  try {
    await Sharing.shareAsync(result.uri, {
      mimeType: "application/pdf",
      dialogTitle: t(input.language, "downloadPdf"),
    });
  } finally {
    file.delete();
  }
}
