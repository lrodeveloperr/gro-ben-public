import {
  ErrorCode,
  deepLinkToSubscriptions,
  finishTransaction,
  getActiveSubscriptions,
  getAvailablePurchases,
  useIAP,
  type ProductSubscription,
  type Purchase,
  type SubscriptionOffer,
} from "expo-iap";
import { AppState as NativeAppState, Platform } from "react-native";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import type { Language } from "./domain";
import {
  loadEntitlementCache,
  saveEntitlementCache,
  type EntitlementCache,
} from "./storage";

export const ANDROID_PACKAGE_NAME =
  "com.goodusestudios.snapebtgrocerytracker";
export const ANDROID_SUBSCRIPTION_ID = "ad_free";
export const ANDROID_MONTHLY_BASE_PLAN_ID = "monthly";
export const ANDROID_ANNUAL_BASE_PLAN_ID = "annual";
export const IOS_LIFETIME_PRODUCT_ID = "remove_ads_forever";

export type AndroidPlanId =
  | typeof ANDROID_MONTHLY_BASE_PLAN_ID
  | typeof ANDROID_ANNUAL_BASE_PLAN_ID;

const ANDROID_OFFLINE_GRACE_MS = 7 * 24 * 60 * 60 * 1000;
const QA_PURCHASES = process.env.EXPO_PUBLIC_QA_PURCHASES === "1";

function local(language: Language, english: string, spanish: string) {
  return language === "es-PR" ? spanish : english;
}

function entitlementFromCache(cache: EntitlementCache | null) {
  if (!cache?.isAdFree) return false;
  if (cache.source === "qa") return QA_PURCHASES;
  if (Platform.OS === "ios") return true;
  return Date.now() - cache.verifiedAt <= ANDROID_OFFLINE_GRACE_MS;
}

export function findAndroidOffer(
  subscription: ProductSubscription | undefined,
  planId: AndroidPlanId,
): SubscriptionOffer | null {
  if (!subscription || subscription.platform !== "android") return null;
  return (
    subscription.subscriptionOffers.find(
      (offer) =>
        offer.basePlanIdAndroid === planId &&
        typeof offer.offerTokenAndroid === "string" &&
        offer.offerTokenAndroid.length > 0,
    ) || null
  );
}

type BillingMessage = { kind: "info" | "error"; text: string } | null;

export function useAdFreeEntitlement(language: Language) {
  const [entitlementReady, setEntitlementReady] = useState(false);
  const [isAdFree, setIsAdFree] = useState(false);
  const [activePlanId, setActivePlanId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<BillingMessage>(null);
  const mounted = useRef(true);

  const applyCache = useCallback(async (cache: EntitlementCache) => {
    await saveEntitlementCache(cache);
    const active = entitlementFromCache(cache);
    if (mounted.current) {
      setIsAdFree(active);
      setActivePlanId(cache.planId);
    }
    return active;
  }, []);

  const handleSuccessfulPurchase = useCallback(
    async (purchase: Purchase) => {
      const expected =
        Platform.OS === "android"
          ? purchase.productId === ANDROID_SUBSCRIPTION_ID
          : purchase.productId === IOS_LIFETIME_PRODUCT_ID;
      if (!expected) return;
      if (purchase.purchaseState !== "purchased") {
        setMessage({
          kind: "info",
          text:
            Platform.OS === "ios"
              ? local(
                  language,
                  "The App Store purchase is pending approval.",
                  "La compra del App Store está pendiente de aprobación.",
                )
              : local(
                  language,
                  "The Google Play purchase is pending approval.",
                  "La compra de Google Play está pendiente de aprobación.",
                ),
        });
        return;
      }
      try {
        await finishTransaction({ purchase, isConsumable: false });
        await applyCache({
          version: 1,
          isAdFree: true,
          productId: purchase.productId,
          planId:
            Platform.OS === "android"
              ? purchase.currentPlanId || null
              : "lifetime",
          verifiedAt: Date.now(),
          source: "purchase",
        });
        setMessage({
          kind: "info",
          text: local(
            language,
            "Ad-free access is active.",
            "El acceso sin anuncios está activo.",
          ),
        });
      } catch {
        setMessage({
          kind: "error",
          text: local(
            language,
            "The store completed the purchase, but confirmation is still pending. Use Restore purchase to finish.",
            "La tienda completó la compra, pero la confirmación sigue pendiente. Usa Restaurar compra para terminar.",
          ),
        });
      }
    },
    [applyCache, language],
  );

  const iap = useIAP({
    onPurchaseSuccess: (purchase) => {
      void handleSuccessfulPurchase(purchase);
    },
    onPurchaseError: (error) => {
      if (QA_PURCHASES || error.code === ErrorCode.UserCancelled) return;
      setMessage({
        kind: "error",
        text: local(
          language,
          "The store could not complete the purchase. Please try again.",
          "La tienda no pudo completar la compra. Inténtalo de nuevo.",
        ),
      });
    },
    onError: () => {
      if (QA_PURCHASES) return;
      setMessage({
        kind: "error",
        text: local(
          language,
          "The store is unavailable. Your tracker data and offline functions are unaffected.",
          "La tienda no está disponible. Tus datos y las funciones sin conexión no se ven afectados.",
        ),
      });
    },
  });

  useEffect(() => {
    mounted.current = true;
    loadEntitlementCache()
      .then((cache) => {
        if (!mounted.current) return;
        setIsAdFree(entitlementFromCache(cache));
        setActivePlanId(cache?.planId || null);
        setEntitlementReady(true);
      })
      .catch(() => {
        if (mounted.current) setEntitlementReady(true);
      });
    return () => {
      mounted.current = false;
    };
  }, []);

  const refreshEntitlement = useCallback(async () => {
    if (QA_PURCHASES) {
      const cache = await loadEntitlementCache();
      const active = entitlementFromCache(cache);
      if (mounted.current) {
        setIsAdFree(active);
        setActivePlanId(cache?.planId || null);
      }
      return active;
    }
    if (!iap.connected) throw new Error("Store is not connected");

    if (Platform.OS === "android") {
      const subscriptions = await getActiveSubscriptions([
        ANDROID_SUBSCRIPTION_ID,
      ]);
      const active = subscriptions.find(
        (subscription) =>
          subscription.productId === ANDROID_SUBSCRIPTION_ID &&
          subscription.isActive,
      );
      await applyCache({
        version: 1,
        isAdFree: Boolean(active),
        productId: active?.productId || null,
        planId: active?.currentPlanId || active?.basePlanIdAndroid || null,
        verifiedAt: Date.now(),
        source: "store",
      });
      return Boolean(active);
    }

    const purchases = await getAvailablePurchases({
      onlyIncludeActiveItemsIOS: true,
    });
    const lifetime = purchases.find(
      (purchase) =>
        purchase.productId === IOS_LIFETIME_PRODUCT_ID &&
        purchase.purchaseState === "purchased" &&
        !("revocationDateIOS" in purchase && purchase.revocationDateIOS),
    );
    await applyCache({
      version: 1,
      isAdFree: Boolean(lifetime),
      productId: lifetime?.productId || null,
      planId: lifetime ? "lifetime" : null,
      verifiedAt: Date.now(),
      source: "store",
    });
    return Boolean(lifetime);
  }, [applyCache, iap.connected]);

  useEffect(() => {
    if (!iap.connected || QA_PURCHASES) return;
    if (Platform.OS === "android") {
      void iap.fetchProducts({
        skus: [ANDROID_SUBSCRIPTION_ID],
        type: "subs",
      });
    } else {
      void iap.fetchProducts({
        skus: [IOS_LIFETIME_PRODUCT_ID],
        type: "in-app",
      });
    }
    void refreshEntitlement().catch(() => undefined);
  }, [iap.connected, iap.fetchProducts, refreshEntitlement]);

  useEffect(() => {
    const subscription = NativeAppState.addEventListener("change", (status) => {
      if (status === "active" && iap.connected && !QA_PURCHASES)
        void refreshEntitlement().catch(() => undefined);
    });
    return () => subscription.remove();
  }, [iap.connected, refreshEntitlement]);

  const androidSubscription = useMemo(
    () =>
      iap.subscriptions.find(
        (subscription) => subscription.id === ANDROID_SUBSCRIPTION_ID,
      ),
    [iap.subscriptions],
  );
  const monthlyOffer = findAndroidOffer(
    androidSubscription,
    ANDROID_MONTHLY_BASE_PLAN_ID,
  );
  const annualOffer = findAndroidOffer(
    androidSubscription,
    ANDROID_ANNUAL_BASE_PLAN_ID,
  );
  const iosProduct = iap.products.find(
    (product) => product.id === IOS_LIFETIME_PRODUCT_ID,
  );

  const buyAndroidPlan = useCallback(
    async (planId: AndroidPlanId) => {
      if (QA_PURCHASES) {
        setBusy(true);
        try {
          await applyCache({
            version: 1,
            isAdFree: true,
            productId: ANDROID_SUBSCRIPTION_ID,
            planId,
            verifiedAt: Date.now(),
            source: "qa",
          });
          setMessage({
            kind: "info",
            text: local(
              language,
              "TEST MODE: ad-free access is active. No charge was made.",
              "MODO DE PRUEBA: el acceso sin anuncios está activo. No se hizo ningún cobro.",
            ),
          });
        } finally {
          if (mounted.current) setBusy(false);
        }
        return;
      }
      const offer = findAndroidOffer(androidSubscription, planId);
      if (!iap.connected || !offer?.offerTokenAndroid) {
        setMessage({
          kind: "error",
          text: local(
            language,
            "This plan is not available from Google Play right now.",
            "Este plan no está disponible en Google Play ahora mismo.",
          ),
        });
        return;
      }
      setBusy(true);
      try {
        await iap.requestPurchase({
          request: {
            google: {
              skus: [ANDROID_SUBSCRIPTION_ID],
              subscriptionOffers: [
                {
                  sku: ANDROID_SUBSCRIPTION_ID,
                  offerToken: offer.offerTokenAndroid,
                },
              ],
            },
          },
          type: "subs",
        });
      } catch {
        setMessage({
          kind: "error",
          text: local(
            language,
            "Google Play could not start the purchase.",
            "Google Play no pudo iniciar la compra.",
          ),
        });
      } finally {
        if (mounted.current) setBusy(false);
      }
    },
    [androidSubscription, applyCache, iap, language],
  );

  const buyIosLifetime = useCallback(async () => {
    if (QA_PURCHASES) {
      setBusy(true);
      try {
        await applyCache({
          version: 1,
          isAdFree: true,
          productId: IOS_LIFETIME_PRODUCT_ID,
          planId: "lifetime",
          verifiedAt: Date.now(),
          source: "qa",
        });
        setMessage({
          kind: "info",
          text: local(
            language,
            "TEST MODE: lifetime ad removal is active. No charge was made.",
            "MODO DE PRUEBA: la eliminación de anuncios para siempre está activa. No se hizo ningún cobro.",
          ),
        });
      } finally {
        if (mounted.current) setBusy(false);
      }
      return;
    }
    if (!iap.connected || !iosProduct) {
      setMessage({
        kind: "error",
        text: local(
          language,
          "The lifetime purchase is not available from the App Store right now.",
          "La compra para siempre no está disponible en el App Store ahora mismo.",
        ),
      });
      return;
    }
    setBusy(true);
    try {
      await iap.requestPurchase({
        request: { apple: { sku: IOS_LIFETIME_PRODUCT_ID } },
        type: "in-app",
      });
    } catch {
      setMessage({
        kind: "error",
        text: local(
          language,
          "The App Store could not start the purchase.",
          "El App Store no pudo iniciar la compra.",
        ),
      });
    } finally {
      if (mounted.current) setBusy(false);
    }
  }, [applyCache, iap, iosProduct, language]);

  const restore = useCallback(async () => {
    setBusy(true);
    try {
      if (!QA_PURCHASES) await iap.restorePurchases();
      const restored = await refreshEntitlement();
      setMessage({
        kind: "info",
        text: restored
          ? local(
              language,
              "Your ad-free access was restored.",
              "Se restauró tu acceso sin anuncios.",
            )
          : local(
              language,
              "No active ad-free purchase was found for this store account.",
              "No se encontró una compra activa sin anuncios para esta cuenta de la tienda.",
            ),
      });
    } catch {
      setMessage({
        kind: "error",
        text: local(
          language,
          "The purchase could not be restored. Check your store account and connection.",
          "No se pudo restaurar la compra. Revisa tu cuenta de la tienda y la conexión.",
        ),
      });
    } finally {
      if (mounted.current) setBusy(false);
    }
  }, [iap, language, refreshEntitlement]);

  const manageAndroidSubscription = useCallback(async () => {
    await deepLinkToSubscriptions({
      packageNameAndroid: ANDROID_PACKAGE_NAME,
      skuAndroid: ANDROID_SUBSCRIPTION_ID,
    });
  }, []);

  const resetQaPurchase = useCallback(async () => {
    if (!QA_PURCHASES) return;
    await applyCache({
      version: 1,
      isAdFree: false,
      productId: null,
      planId: null,
      verifiedAt: Date.now(),
      source: "qa",
    });
    setMessage({
      kind: "info",
      text: local(
        language,
        "TEST MODE: free ad-supported state restored.",
        "MODO DE PRUEBA: se restauró la versión gratis con anuncios.",
      ),
    });
  }, [applyCache, language]);

  return {
    connected: iap.connected,
    entitlementReady,
    isAdFree,
    activePlanId,
    busy,
    message,
    clearMessage: () => setMessage(null),
    qaMode: QA_PURCHASES,
    monthlyPrice: monthlyOffer?.displayPrice || (QA_PURCHASES ? "$0.99" : null),
    annualPrice: annualOffer?.displayPrice || (QA_PURCHASES ? "$6.99" : null),
    lifetimePrice:
      iosProduct?.displayPrice || (QA_PURCHASES ? "$12.99" : null),
    buyAndroidPlan,
    buyIosLifetime,
    restore,
    refreshEntitlement,
    manageAndroidSubscription,
    resetQaPurchase,
  };
}
