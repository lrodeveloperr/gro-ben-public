import { Platform } from 'react-native';

export const ANDROID_PACKAGE_NAME =
  'com.goodusestudios.snapebtgrocerytracker';

export function configuredBannerAdUnitId(): string | null {
  return Platform.OS === 'android'
    ? process.env.EXPO_PUBLIC_ANDROID_ADMOB_BANNER_ID || null
    : process.env.EXPO_PUBLIC_IOS_ADMOB_BANNER_ID || null;
}

export function configuredRewardedAdUnitId(): string | null {
  return Platform.OS === 'android'
    ? process.env.EXPO_PUBLIC_ANDROID_ADMOB_REWARDED_ID || null
    : null;
}

export function configuredInterstitialAdUnitId(): string | null {
  return Platform.OS === 'android'
    ? process.env.EXPO_PUBLIC_ANDROID_ADMOB_INTERSTITIAL_ID || null
    : process.env.EXPO_PUBLIC_IOS_ADMOB_INTERSTITIAL_ID || null;
}
