import {
  EMPTY_STATE,
  isCents,
  type AppState,
  type BalanceEntry,
  type BenefitCard,
  type GroceryItem,
  type Purchase,
} from "./domain";

const MAX_RECORDS = 20_000;

function validItem(value: unknown): value is GroceryItem {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<GroceryItem>;
  return (
    typeof item.id === "string" &&
    typeof item.name === "string" &&
    item.name.length <= 160 &&
    isCents(item.priceCents) &&
    Number.isSafeInteger(item.quantity) &&
    Number(item.quantity) >= 1 &&
    Number(item.quantity) <= 99 &&
    (item.eligibility === "eligible" ||
      item.eligibility === "not-eligible" ||
      item.eligibility === "unsure") &&
    (item.chargedEligible === undefined ||
      typeof item.chargedEligible === "boolean")
  );
}

function validCard(value: unknown): value is BenefitCard {
  if (!value || typeof value !== "object") return false;
  const card = value as Partial<BenefitCard>;
  return (
    typeof card.id === "string" &&
    typeof card.name === "string" &&
    card.name.length <= 80 &&
    isCents(card.balanceCents) &&
    typeof card.createdAt === "string" &&
    [
      "emerald",
      "ocean",
      "violet",
      "berry",
      "coral",
      "sunset",
      "amber",
      "slate",
      "teal",
      "indigo",
      "rose",
      "cocoa",
    ].includes(String(card.color))
  );
}

function validPurchase(value: unknown): value is Purchase {
  if (!value || typeof value !== "object") return false;
  const purchase = value as Partial<Purchase>;
  return (
    typeof purchase.id === "string" &&
    typeof purchase.store === "string" &&
    typeof purchase.completedAt === "string" &&
    Array.isArray(purchase.items) &&
    purchase.items.every(validItem) &&
    isCents(purchase.eligibleCents) &&
    isCents(purchase.notEligibleCents) &&
    isCents(purchase.unsureCents) &&
    isCents(purchase.chargedBenefitCents) &&
    (purchase.balanceBeforeCents === null ||
      isCents(purchase.balanceBeforeCents)) &&
    (purchase.balanceAfterCents === null ||
      isCents(purchase.balanceAfterCents))
  );
}

function validEntry(value: unknown): value is BalanceEntry {
  if (!value || typeof value !== "object") return false;
  const entry = value as Partial<BalanceEntry>;
  return (
    typeof entry.id === "string" &&
    typeof entry.cardId === "string" &&
    isCents(entry.amountCents) &&
    typeof entry.createdAt === "string" &&
    (entry.reversedAt === null || typeof entry.reversedAt === "string")
  );
}

export function parseAppState(raw: string | null): AppState | null {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Omit<Partial<AppState>, "version"> & {
      version?: 1 | 2;
    };
    if (
      (value.version !== 1 && value.version !== 2) ||
      !Array.isArray(value.cards) ||
      !value.cards.every(validCard) ||
      !Array.isArray(value.purchases) ||
      !value.purchases.every(validPurchase) ||
      !Array.isArray(value.draftItems) ||
      !value.draftItems.every(validItem) ||
      !Array.isArray(value.balanceEntries) ||
      !value.balanceEntries.every(validEntry) ||
      (value.language !== null &&
        value.language !== "en" &&
        value.language !== "es-PR") ||
      (value.program !== undefined &&
        value.program !== null &&
        value.program !== "snap-ebt" &&
        value.program !== "pan-pr")
    )
      return null;
    return {
      ...EMPTY_STATE,
      ...value,
      version: 2,
      program:
        value.version === 2 &&
        (value.program === "snap-ebt" || value.program === "pan-pr")
          ? value.program
          : null,
      cards: value.cards.slice(0, 100),
      purchases: value.purchases.slice(0, MAX_RECORDS),
      draftItems: value.draftItems.slice(0, 500),
      balanceEntries: value.balanceEntries.slice(0, MAX_RECORDS),
      savedStores: Array.isArray(value.savedStores)
        ? value.savedStores
            .filter((item): item is string => typeof item === "string")
            .slice(0, 500)
        : [],
      recentItemNames: Array.isArray(value.recentItemNames)
        ? value.recentItemNames
            .filter((item): item is string => typeof item === "string")
            .slice(0, 250)
        : [],
      draftStore: typeof value.draftStore === "string" ? value.draftStore : "",
      activeCardId:
        typeof value.activeCardId === "string" ? value.activeCardId : null,
      acceptedTermsAt:
        value.version === 2 && typeof value.acceptedTermsAt === "string"
          ? value.acceptedTermsAt
          : null,
      historyDetailViews: Number.isSafeInteger(value.historyDetailViews)
        ? Number(value.historyDetailViews)
        : 0,
      allTimeAdProgress: value.allTimeAdProgress === 1 ? 1 : 0,
      lastAdAt:
        typeof value.lastAdAt === "number" && Number.isFinite(value.lastAdAt)
          ? value.lastAdAt
          : null,
      ratingPrompted: Boolean(value.ratingPrompted),
    };
  } catch {
    return null;
  }
}

export type EntitlementCache = {
  version: 1;
  isAdFree: boolean;
  productId: string | null;
  planId: string | null;
  verifiedAt: number;
  source: "store" | "purchase" | "qa";
};

export function parseEntitlementCache(
  raw: string | null,
): EntitlementCache | null {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Partial<EntitlementCache>;
    if (
      value.version !== 1 ||
      typeof value.isAdFree !== "boolean" ||
      (value.productId !== null && typeof value.productId !== "string") ||
      (value.planId !== null && typeof value.planId !== "string") ||
      typeof value.verifiedAt !== "number" ||
      !Number.isFinite(value.verifiedAt) ||
      value.verifiedAt < 0 ||
      (value.source !== "store" &&
        value.source !== "purchase" &&
        value.source !== "qa")
    )
      return null;
    return value as EntitlementCache;
  } catch {
    return null;
  }
}
