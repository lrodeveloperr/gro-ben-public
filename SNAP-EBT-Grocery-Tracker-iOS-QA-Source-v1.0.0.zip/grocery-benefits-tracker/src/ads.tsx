import React, { useEffect, useState } from "react";
import { AppState, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import mobileAds, {
  AdEventType,
  AdsConsent,
  AdsConsentPrivacyOptionsRequirementStatus,
  BannerAd,
  BannerAdSize,
  InterstitialAd,
  MaxAdContentRating,
  RewardedAd,
  RewardedAdEventType,
  TestIds,
} from "react-native-google-mobile-ads";

import { t } from "./i18n";
import type { Language } from "./domain";
import {
  configuredBannerAdUnitId,
  configuredInterstitialAdUnitId,
  configuredRewardedAdUnitId,
} from "./releaseConfig";

const MAX_CACHE_AGE_MS = 50 * 60 * 1000;
const LOAD_TIMEOUT_MS = 12 * 1000;
const INITIALIZATION_TIMEOUT_MS = 15 * 1000;
type RewardResult = "earned" | "dismissed" | "unavailable";

let initialization: Promise<boolean> | null = null;
let rewarded: RewardedAd | null = null;
let interstitial: InterstitialAd | null = null;
let rewardedLoadedAt = 0;
let interstitialLoadedAt = 0;
let rewardedLoading = false;
let interstitialLoading = false;

function withTimeout<T>(promise: Promise<T>, milliseconds: number) {
  return Promise.race<T>([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error("Ad operation timed out")), milliseconds),
    ),
  ]);
}

async function ensureAdsReady() {
  if (!initialization) {
    initialization = withTimeout(
      (async () => {
        const consent = await AdsConsent.gatherConsent();
        if (!consent.canRequestAds) return false;
        await mobileAds().setRequestConfiguration({
          maxAdContentRating: MaxAdContentRating.PG,
        });
        await mobileAds().initialize();
        return true;
      })(),
      INITIALIZATION_TIMEOUT_MS,
    ).catch(() => false);
  }
  return initialization;
}

function makeRewarded() {
  return RewardedAd.createForAdRequest(
    configuredRewardedAdUnitId() || TestIds.REWARDED,
    { requestNonPersonalizedAdsOnly: true },
  );
}

function makeInterstitial() {
  return InterstitialAd.createForAdRequest(
    configuredInterstitialAdUnitId() || TestIds.INTERSTITIAL,
    { requestNonPersonalizedAdsOnly: true },
  );
}

function clearStaleAds() {
  if (rewarded && Date.now() - rewardedLoadedAt >= MAX_CACHE_AGE_MS) {
    rewarded = null;
    rewardedLoadedAt = 0;
  }
  if (interstitial && Date.now() - interstitialLoadedAt >= MAX_CACHE_AGE_MS) {
    interstitial = null;
    interstitialLoadedAt = 0;
  }
}

function loadRewarded() {
  clearStaleAds();
  if (rewardedLoading || rewarded) return;
  rewardedLoading = true;
  const ad = makeRewarded();
  rewarded = ad;
  let settled = false;
  const finish = (loaded: boolean) => {
    if (settled) return;
    settled = true;
    clearTimeout(timeout);
    removeLoaded();
    removeError();
    rewardedLoading = false;
    if (loaded) rewardedLoadedAt = Date.now();
    else {
      rewarded = null;
      rewardedLoadedAt = 0;
    }
  };
  const removeLoaded = ad.addAdEventListener(
    RewardedAdEventType.LOADED,
    () => finish(true),
  );
  const removeError = ad.addAdEventListener(AdEventType.ERROR, () =>
    finish(false),
  );
  const timeout = setTimeout(() => finish(false), LOAD_TIMEOUT_MS);
  ad.load();
}

function loadInterstitial() {
  clearStaleAds();
  if (interstitialLoading || interstitial) return;
  interstitialLoading = true;
  const ad = makeInterstitial();
  interstitial = ad;
  let settled = false;
  const finish = (loaded: boolean) => {
    if (settled) return;
    settled = true;
    clearTimeout(timeout);
    removeLoaded();
    removeError();
    interstitialLoading = false;
    if (loaded) interstitialLoadedAt = Date.now();
    else {
      interstitial = null;
      interstitialLoadedAt = 0;
    }
  };
  const removeLoaded = ad.addAdEventListener(AdEventType.LOADED, () =>
    finish(true),
  );
  const removeError = ad.addAdEventListener(AdEventType.ERROR, () =>
    finish(false),
  );
  const timeout = setTimeout(() => finish(false), LOAD_TIMEOUT_MS);
  ad.load();
}

export async function initializeAdsAndPrecache() {
  if (!(await ensureAdsReady())) return false;
  clearStaleAds();
  loadRewarded();
  loadInterstitial();
  return true;
}

export function revalidateAdsOnForeground() {
  clearStaleAds();
  void ensureAdsReady().then((ready) => {
    if (!ready) return;
    loadRewarded();
    loadInterstitial();
  });
}

export async function showRewardedReportAd(): Promise<RewardResult> {
  if (!(await ensureAdsReady())) return "unavailable";
  clearStaleAds();
  if (!rewarded) {
    loadRewarded();
    return "unavailable";
  }
  const ad = rewarded;
  rewarded = null;
  rewardedLoadedAt = 0;
  return new Promise((resolve) => {
    let earned = false;
    let settled = false;
    const finish = (result: RewardResult) => {
      if (settled) return;
      settled = true;
      removes.forEach((remove) => remove());
      loadRewarded();
      resolve(result);
    };
    const removes = [
      ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => {
        earned = true;
      }),
      ad.addAdEventListener(AdEventType.CLOSED, () =>
        finish(earned ? "earned" : "dismissed"),
      ),
      ad.addAdEventListener(AdEventType.ERROR, () => finish("unavailable")),
    ];
    ad.show().catch(() => finish("unavailable"));
  });
}

export async function showNaturalBreakInterstitial(): Promise<boolean> {
  if (!(await ensureAdsReady())) return false;
  clearStaleAds();
  if (!interstitial) {
    loadInterstitial();
    return false;
  }
  const ad = interstitial;
  interstitial = null;
  interstitialLoadedAt = 0;
  return new Promise((resolve) => {
    let settled = false;
    const finish = (shown: boolean) => {
      if (settled) return;
      settled = true;
      removes.forEach((remove) => remove());
      loadInterstitial();
      resolve(shown);
    };
    const removes = [
      ad.addAdEventListener(AdEventType.CLOSED, () => finish(true)),
      ad.addAdEventListener(AdEventType.ERROR, () => finish(false)),
    ];
    ad.show().catch(() => finish(false));
  });
}

function DisplayBanner({
  language,
  size,
}: {
  language: Language;
  size: BannerAdSize;
}) {
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    const subscription = AppState.addEventListener("change", (status) => {
      if (status === "active") {
        setFailed(false);
        setReady(false);
        setNonce((current) => current + 1);
      }
    });
    return () => subscription.remove();
  }, []);

  if (failed) return null;
  return (
    <View
      accessibilityLabel={language === "es-PR" ? "Anuncio" : "Advertisement"}
      style={[styles.banner, !ready && styles.bannerLoading]}
    >
      {ready ? (
        <Text style={styles.adLabel}>
          {language === "es-PR" ? "ANUNCIO" : "ADVERTISEMENT"}
        </Text>
      ) : null}
      <BannerAd
        key={nonce}
        unitId={configuredBannerAdUnitId() || TestIds.ADAPTIVE_BANNER}
        size={size}
        requestOptions={{ requestNonPersonalizedAdsOnly: true }}
        onAdLoaded={() => setReady(true)}
        onAdFailedToLoad={() => setFailed(true)}
      />
    </View>
  );
}

export function WalletBanner({ language }: { language: Language }) {
  return (
    <DisplayBanner
      language={language}
      size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER}
    />
  );
}

export function InlineReportAd({ language }: { language: Language }) {
  if (Platform.OS !== "ios") return null;
  return <DisplayBanner language={language} size={BannerAdSize.LARGE_BANNER} />;
}

export function AdPrivacyButton({ language }: { language: Language }) {
  const [required, setRequired] = useState(false);
  useEffect(() => {
    AdsConsent.getConsentInfo()
      .then((info) =>
        setRequired(
          info.privacyOptionsRequirementStatus ===
            AdsConsentPrivacyOptionsRequirementStatus.REQUIRED,
        ),
      )
      .catch(() => undefined);
  }, []);
  if (!required) return null;
  return (
    <Pressable
      onPress={() => AdsConsent.showPrivacyOptionsForm().catch(() => undefined)}
      accessibilityRole="button"
      accessibilityLabel={t(language, "adPrivacy")}
      style={({ pressed }) => [styles.button, pressed && styles.pressed]}
    >
      <Text style={styles.text}>{t(language, "adPrivacy")}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  banner: {
    alignItems: "center",
    backgroundColor: "#F7FAF8",
    borderTopColor: "#DCE5DF",
    borderTopWidth: StyleSheet.hairlineWidth,
    minHeight: 54,
    overflow: "hidden",
    paddingTop: 3,
  },
  bannerLoading: { height: 1, minHeight: 1, opacity: 0, paddingTop: 0 },
  adLabel: { color: "#6C8079", fontSize: 8, fontWeight: "800", marginBottom: 2 },
  button: {
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 14,
  },
  text: { color: "#0C523D", fontSize: 12, fontWeight: "800" },
  pressed: { opacity: 0.7 },
});
