export type Language = "en" | "es-PR";
export type Program = "snap-ebt" | "pan-pr";
export type Eligibility = "eligible" | "not-eligible" | "unsure";
export type CardColor =
  | "emerald"
  | "ocean"
  | "violet"
  | "berry"
  | "coral"
  | "sunset"
  | "amber"
  | "slate"
  | "teal"
  | "indigo"
  | "rose"
  | "cocoa";

export type BenefitCard = {
  id: string;
  name: string;
  balanceCents: number;
  color: CardColor;
  createdAt: string;
};

export type GroceryItem = {
  id: string;
  name: string;
  priceCents: number;
  quantity: number;
  eligibility: Eligibility;
  chargedEligible?: boolean;
};

export type Purchase = {
  id: string;
  store: string;
  completedAt: string;
  items: GroceryItem[];
  cardId: string | null;
  cardName: string | null;
  eligibleCents: number;
  notEligibleCents: number;
  unsureCents: number;
  chargedBenefitCents: number;
  balanceBeforeCents: number | null;
  balanceAfterCents: number | null;
  correctedAt: string | null;
};

export type BalanceEntry = {
  id: string;
  cardId: string;
  amountCents: number;
  createdAt: string;
  reversedAt: string | null;
};

export type AppState = {
  version: 2;
  language: Language | null;
  program: Program | null;
  acceptedTermsAt: string | null;
  cards: BenefitCard[];
  activeCardId: string | null;
  purchases: Purchase[];
  draftItems: GroceryItem[];
  draftStore: string;
  savedStores: string[];
  recentItemNames: string[];
  balanceEntries: BalanceEntry[];
  historyDetailViews: number;
  allTimeAdProgress: 0 | 1;
  lastAdAt: number | null;
  ratingPrompted: boolean;
};

export type UndoSnapshot = Pick<
  AppState,
  "cards" | "purchases" | "draftItems" | "draftStore" | "balanceEntries"
> & {
  label: string;
};

export const MAX_CENTS = 99_999_999;
export const AD_CAP_MS = 30 * 60 * 1000;

export const CARD_COLORS: Record<
  CardColor,
  { label: string; from: string; to: string }
> = {
  emerald: { label: "Emerald", from: "#0F795F", to: "#084D43" },
  ocean: { label: "Ocean", from: "#1976A8", to: "#124A72" },
  violet: { label: "Violet", from: "#7659B5", to: "#463577" },
  berry: { label: "Berry", from: "#A34571", to: "#6B294D" },
  coral: { label: "Coral", from: "#DD765C", to: "#9D453D" },
  sunset: { label: "Sunset", from: "#D9654A", to: "#8A3B50" },
  amber: { label: "Amber", from: "#C88926", to: "#815518" },
  slate: { label: "Slate", from: "#526B7C", to: "#2E3E4B" },
  teal: { label: "Teal", from: "#188B8A", to: "#0C5659" },
  indigo: { label: "Indigo", from: "#4E63AF", to: "#2F3B72" },
  rose: { label: "Rose", from: "#C75A75", to: "#81384F" },
  cocoa: { label: "Cocoa", from: "#8A654E", to: "#513A30" },
};

export const EMPTY_STATE: AppState = {
  version: 2,
  language: null,
  program: null,
  acceptedTermsAt: null,
  cards: [],
  activeCardId: null,
  purchases: [],
  draftItems: [],
  draftStore: "",
  savedStores: [],
  recentItemNames: [],
  balanceEntries: [],
  historyDetailViews: 0,
  allTimeAdProgress: 0,
  lastAdAt: null,
  ratingPrompted: false,
};

export function isCents(value: unknown): value is number {
  return (
    Number.isSafeInteger(value) &&
    Number(value) >= 0 &&
    Number(value) <= MAX_CENTS
  );
}

export function parseCents(raw: string): number | null {
  const value = raw.trim().replace(/[\s$,]/g, "");
  if (!/^\d+(?:\.\d{0,2})?$/.test(value)) return null;
  const [whole = "0", fraction = ""] = value.split(".");
  const cents =
    Number.parseInt(whole, 10) * 100 +
    Number.parseInt(fraction.padEnd(2, "0") || "0", 10);
  return isCents(cents) ? cents : null;
}

export function formatCents(cents: number, language: Language = "en") {
  return new Intl.NumberFormat(language === "es-PR" ? "es-PR" : "en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(cents / 100);
}

export function itemTotalCents(item: GroceryItem) {
  return item.priceCents * item.quantity;
}

export function totalsFromItems(items: GroceryItem[]) {
  const eligibleCents = items
    .filter((item) => item.eligibility === "eligible")
    .reduce((sum, item) => sum + itemTotalCents(item), 0);
  const notEligibleCents = items
    .filter((item) => item.eligibility === "not-eligible")
    .reduce((sum, item) => sum + itemTotalCents(item), 0);
  const unsureCents = items
    .filter((item) => item.eligibility === "unsure")
    .reduce((sum, item) => sum + itemTotalCents(item), 0);
  return {
    eligibleCents,
    notEligibleCents,
    unsureCents,
    totalCents: eligibleCents + notEligibleCents + unsureCents,
    itemCount: items.reduce((sum, item) => sum + item.quantity, 0),
  };
}

export function totalsFromPurchases(purchases: Purchase[]) {
  return purchases.reduce(
    (total, purchase) => ({
      eligibleCents: total.eligibleCents + purchase.eligibleCents,
      notEligibleCents: total.notEligibleCents + purchase.notEligibleCents,
      unsureCents: total.unsureCents + purchase.unsureCents,
      totalCents:
        total.totalCents +
        purchase.eligibleCents +
        purchase.notEligibleCents +
        purchase.unsureCents,
      itemCount:
        total.itemCount +
        purchase.items.reduce((sum, item) => sum + item.quantity, 0),
    }),
    {
      eligibleCents: 0,
      notEligibleCents: 0,
      unsureCents: 0,
      totalCents: 0,
      itemCount: 0,
    },
  );
}

export function cleanName(value: string) {
  return value.trim().replace(/\s+/g, " ");
}

export function nameKey(value: string) {
  return cleanName(value).toLocaleLowerCase("en-US");
}

export function addRecentName(current: string[], value: string) {
  const cleaned = cleanName(value);
  const key = nameKey(cleaned);
  return key
    ? [
        cleaned,
        ...current.filter((candidate) => nameKey(candidate) !== key),
      ].slice(0, 250)
    : current;
}

export function rememberClassification(
  purchases: Purchase[],
  value: string,
): Eligibility | null {
  const key = nameKey(value);
  for (const purchase of [...purchases].sort((a, b) =>
    b.completedAt.localeCompare(a.completedAt),
  )) {
    const match = purchase.items.find((item) => nameKey(item.name) === key);
    if (match) return match.eligibility;
  }
  return null;
}

export function synchronizeClassification(
  purchases: Purchase[],
  value: string,
  eligibility: Eligibility,
) {
  const key = nameKey(value);
  return purchases.map((purchase) => {
    let changed = false;
    const items = purchase.items.map((item) => {
      if (nameKey(item.name) !== key || item.eligibility === eligibility)
        return item;
      changed = true;
      return { ...item, eligibility };
    });
    if (!changed) return purchase;
    const totals = totalsFromItems(items);
    return {
      ...purchase,
      items,
      eligibleCents: totals.eligibleCents,
      notEligibleCents: totals.notEligibleCents,
      unsureCents: totals.unsureCents,
    };
  });
}

export function hasActiveAdPass(lastAdAt: number | null, now = Date.now()) {
  return lastAdAt !== null && now - lastAdAt >= 0 && now - lastAdAt < AD_CAP_MS;
}

export function purchaseBalanceError(
  balanceCents: number,
  eligibleCents: number,
  language: Language,
) {
  if (!isCents(balanceCents) || !isCents(eligibleCents))
    return language === "es-PR"
      ? "Revisa las cantidades antes de guardar."
      : "Review the amounts before saving.";
  if (balanceCents <= 0)
    return language === "es-PR"
      ? "Esta tarjeta tiene un balance registrado de $0.00. Registra beneficios recibidos o elige otra tarjeta."
      : "This card has a $0.00 tracked balance. Record benefits received or choose another card.";
  if (eligibleCents > balanceCents)
    return language === "es-PR"
      ? "Esta compra dejaría el balance registrado por debajo de $0.00."
      : "This purchase would put the tracked balance below $0.00.";
  return null;
}
