export const MAX_CENTS = 99_999_999;

export type BasketKind = 'eligible' | 'cash';

export type BasketItem = {
  id: string;
  amountCents: number;
  kind: BasketKind;
};

export type LedgerTotals = {
  eligibleCents: number;
  cashCents: number;
  remainingCents: number | null;
  eligibleCount: number;
  cashCount: number;
};

export function isValidCents(value: unknown): value is number {
  return (
    typeof value === 'number' &&
    Number.isSafeInteger(value) &&
    value >= 0 &&
    value <= MAX_CENTS
  );
}

export function sanitizeCurrencyText(raw: string): string {
  const withoutDecorators = raw.replace(/[\s$,]/g, '');
  let cleaned = '';
  let hasDecimal = false;
  let decimalPlaces = 0;

  for (const character of withoutDecorators) {
    if (/\d/.test(character)) {
      if (!hasDecimal || decimalPlaces < 2) {
        cleaned += character;
        if (hasDecimal) decimalPlaces += 1;
      }
      continue;
    }

    if (character === '.' && !hasDecimal) {
      cleaned += character;
      hasDecimal = true;
    }
  }

  const [whole = '', fraction] = cleaned.split('.');
  const trimmedWhole = whole.replace(/^0+(?=\d)/, '');

  if (fraction !== undefined) {
    return `${trimmedWhole || '0'}.${fraction}`;
  }

  return trimmedWhole;
}

export function parseCurrencyToCents(raw: string): number | null {
  const normalized = raw.trim().replace(/[\s$,]/g, '');

  if (!/^\d+(?:\.\d{0,2})?$/.test(normalized)) return null;

  const [wholePart = '0', fractionPart = ''] = normalized.split('.');
  const whole = Number.parseInt(wholePart, 10);
  const fraction = Number.parseInt(fractionPart.padEnd(2, '0') || '0', 10);
  const cents = whole * 100 + fraction;

  return isValidCents(cents) ? cents : null;
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? '-' : '';
  const absolute = Math.abs(cents);
  const whole = Math.floor(absolute / 100)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const fraction = (absolute % 100).toString().padStart(2, '0');

  return `${sign}$${whole}.${fraction}`;
}

export function formatForInput(cents: number): string {
  const absolute = Math.abs(cents);
  return `${Math.floor(absolute / 100)}.${(absolute % 100)
    .toString()
    .padStart(2, '0')}`;
}

export function digitsToCents(digits: string): number {
  if (!/^\d*$/.test(digits)) return 0;

  const parsed = Number.parseInt(digits || '0', 10);
  return isValidCents(parsed) ? parsed : 0;
}

export function appendPriceDigit(current: string, digit: string): string {
  if (!/^\d$/.test(digit)) return current;

  const next = `${current}${digit}`.replace(/^0+(?=\d)/, '');
  return Number.parseInt(next || '0', 10) <= MAX_CENTS ? next : current;
}

export function calculateLedger(
  items: BasketItem[],
  balanceCents: number | null,
): LedgerTotals {
  let eligibleCents = 0;
  let cashCents = 0;
  let eligibleCount = 0;
  let cashCount = 0;

  for (const item of items) {
    if (!isValidCents(item.amountCents)) continue;

    if (item.kind === 'eligible') {
      eligibleCents += item.amountCents;
      eligibleCount += 1;
    } else if (item.kind === 'cash') {
      cashCents += item.amountCents;
      cashCount += 1;
    }
  }

  return {
    eligibleCents,
    cashCents,
    remainingCents:
      balanceCents === null ? null : balanceCents - eligibleCents,
    eligibleCount,
    cashCount,
  };
}
