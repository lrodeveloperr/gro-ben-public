import { cleanName, nameKey, type Language, type Purchase, type GroceryItem } from './domain';

const ITEMS: ReadonlyArray<readonly [string, string]> = [
  ['Apples', 'Manzanas'], ['Bananas', 'Guineos'], ['Oranges', 'Naranjas'], ['Grapes', 'Uvas'],
  ['Strawberries', 'Fresas'], ['Blueberries', 'Arándanos'], ['Raspberries', 'Frambuesas'], ['Lemons', 'Limones'],
  ['Limes', 'Limas'], ['Avocados', 'Aguacates'], ['Peaches', 'Melocotones'], ['Pears', 'Peras'],
  ['Pineapple', 'Piña'], ['Watermelon', 'Sandía'], ['Cantaloupe', 'Melón cantalupo'], ['Mangoes', 'Mangos'],
  ['Cherries', 'Cerezas'], ['Fruit cups', 'Vasitos de fruta'], ['Potatoes', 'Papas'], ['Sweet potatoes', 'Batatas'],
  ['Onions', 'Cebollas'], ['Garlic', 'Ajo'], ['Tomatoes', 'Tomates'], ['Romaine lettuce', 'Lechuga romana'],
  ['Iceberg lettuce', 'Lechuga iceberg'], ['Spinach', 'Espinaca'], ['Kale', 'Kale'], ['Carrots', 'Zanahorias'],
  ['Broccoli', 'Brócoli'], ['Cauliflower', 'Coliflor'], ['Bell peppers', 'Pimientos morrones'], ['Cucumbers', 'Pepinos'],
  ['Celery', 'Apio'], ['Cabbage', 'Repollo'], ['Corn', 'Maíz'], ['Green beans', 'Habichuelas tiernas'],
  ['Zucchini', 'Calabacín'], ['Mushrooms', 'Hongos'], ['Asparagus', 'Espárragos'], ['Frozen mixed vegetables', 'Vegetales mixtos congelados'],
  ['Frozen corn', 'Maíz congelado'], ['Frozen peas', 'Petit pois congelados'], ['Chicken breast', 'Pechuga de pollo'], ['Chicken thighs', 'Muslos de pollo'],
  ['Whole chicken', 'Pollo entero'], ['Ground beef', 'Carne molida de res'], ['Beef steak', 'Bistec de res'], ['Beef roast', 'Asado de res'],
  ['Pork chops', 'Chuletas de cerdo'], ['Pork shoulder', 'Pernil de cerdo'], ['Bacon', 'Tocineta'], ['Breakfast sausage', 'Salchicha de desayuno'],
  ['Deli turkey', 'Pavo rebanado'], ['Ham', 'Jamón'], ['Turkey', 'Pavo'], ['Salmon', 'Salmón'],
  ['Tuna', 'Atún'], ['Shrimp', 'Camarones'], ['Eggs', 'Huevos'], ['Black beans', 'Habichuelas negras'],
  ['Pinto beans', 'Habichuelas pintas'], ['Lentils', 'Lentejas'], ['Whole milk', 'Leche entera'], ['Reduced-fat milk', 'Leche baja en grasa'],
  ['Skim milk', 'Leche descremada'], ['Lactose-free milk', 'Leche sin lactosa'], ['Almond milk', 'Leche de almendras'], ['Cheddar cheese', 'Queso cheddar'],
  ['Mozzarella cheese', 'Queso mozzarella'], ['American cheese', 'Queso americano'], ['Cream cheese', 'Queso crema'], ['Cottage cheese', 'Queso cottage'],
  ['Yogurt', 'Yogur'], ['Greek yogurt', 'Yogur griego'], ['Butter', 'Mantequilla'], ['Sour cream', 'Crema agria'],
  ['Ice cream', 'Helado'], ['White bread', 'Pan blanco'], ['Whole wheat bread', 'Pan integral'], ['Hamburger buns', 'Pan para hamburguesas'],
  ['Hot dog buns', 'Pan para perros calientes'], ['Bagels', 'Bagels'], ['Flour tortillas', 'Tortillas de harina'], ['Corn tortillas', 'Tortillas de maíz'],
  ['Rice', 'Arroz'], ['Brown rice', 'Arroz integral'], ['Pasta', 'Pasta'], ['Macaroni and cheese', 'Macarrones con queso'],
  ['Oatmeal', 'Avena'], ['Breakfast cereal', 'Cereal de desayuno'], ['Pancake mix', 'Mezcla para panqueques'], ['All-purpose flour', 'Harina de trigo'],
  ['Cornmeal', 'Harina de maíz'], ['Crackers', 'Galletas saladas'], ['Granola bars', 'Barras de granola'], ['Peanut butter', 'Mantequilla de maní'],
  ['Jelly', 'Jalea'], ['Granulated sugar', 'Azúcar granulada'], ['Brown sugar', 'Azúcar morena'], ['Salt', 'Sal'],
  ['Black pepper', 'Pimienta negra'], ['Cooking oil', 'Aceite para cocinar'], ['Olive oil', 'Aceite de oliva'], ['Vinegar', 'Vinagre'],
  ['Ketchup', 'Kétchup'], ['Mustard', 'Mostaza'], ['Mayonnaise', 'Mayonesa'], ['Salad dressing', 'Aderezo para ensalada'],
  ['Pasta sauce', 'Salsa para pasta'], ['Tomato sauce', 'Salsa de tomate'], ['Canned tomatoes', 'Tomates enlatados'], ['Canned beans', 'Habichuelas enlatadas'],
  ['Canned corn', 'Maíz enlatado'], ['Canned tuna', 'Atún enlatado'], ['Chicken broth', 'Caldo de pollo'], ['Soup', 'Sopa'],
  ['Instant noodles', 'Fideos instantáneos'], ['Coffee', 'Café'], ['Tea', 'Té'], ['Cocoa mix', 'Mezcla de chocolate'],
  ['Bottled water', 'Agua embotellada'], ['Sparkling water', 'Agua con gas'], ['Fruit juice', 'Jugo de frutas'], ['Orange juice', 'Jugo de naranja'],
  ['Soft drinks', 'Refrescos'], ['Sports drinks', 'Bebidas deportivas'], ['Potato chips', 'Papitas'], ['Tortilla chips', 'Chips de tortilla'],
  ['Popcorn', 'Popcorn (rosetas de maíz)'], ['Cookies', 'Galletas dulces'], ['Candy', 'Dulces'], ['Frozen pizza', 'Pizza congelada'],
  ['Frozen dinners', 'Comidas congeladas'], ['French fries', 'Papas fritas'], ['Chicken nuggets', 'Nuggets de pollo'], ['Paper towels', 'Papel toalla'],
  ['Toilet paper', 'Papel sanitario'], ['Facial tissues', 'Pañuelos faciales'], ['Dish soap', 'Líquido de fregar'], ['Laundry detergent', 'Detergente para ropa'],
  ['Trash bags', 'Bolsas de basura'], ['Aluminum foil', 'Papel de aluminio'], ['Food storage bags', 'Bolsas para guardar alimentos'], ['Hand soap', 'Jabón de manos'],
  ['Shampoo', 'Champú'], ['Toothpaste', 'Pasta dental'], ['Diapers', 'Pañales'], ['Baby wipes', 'Toallitas para bebé'],
  ['Infant formula', 'Fórmula infantil'], ['Pet food', 'Comida para mascotas'],
] as const;

const PUERTO_RICO_STAPLES = [
  'Plátanos', 'Plátanos maduros', 'Gandules', 'Habichuelas rosadas',
  'Yuca', 'Yautía', 'Ñame', 'Malanga', 'Sofrito', 'Recao', 'Pan sobao',
  'Arroz de grano mediano', 'Bacalao',
] as const;

export const COMMON_ITEMS_EN = ITEMS.map(([english]) => english);
export const COMMON_ITEMS_ES_PR = [
  ...PUERTO_RICO_STAPLES,
  ...ITEMS.map(([, spanish]) => spanish),
];

export function itemSuggestions(
  language: Language,
  recent: string[],
  purchases: Purchase[],
  draft: GroceryItem[],
  query: string,
  limit = 9,
) {
  const options: Array<{ name: string; source: 'recent' | 'history' | 'common' }> = [];
  const seen = new Set<string>();
  const push = (value: string, source: 'recent' | 'history' | 'common') => {
    const name = cleanName(value);
    const key = nameKey(name);
    if (!key || seen.has(key)) return;
    seen.add(key);
    options.push({ name, source });
  };
  recent.forEach((name) => push(name, 'recent'));
  [...draft].reverse().forEach((item) => push(item.name, 'recent'));
  [...purchases].sort((a, b) => b.completedAt.localeCompare(a.completedAt)).forEach((purchase) => purchase.items.forEach((item) => push(item.name, 'history')));
  (language === 'es-PR' ? COMMON_ITEMS_ES_PR : COMMON_ITEMS_EN).forEach((name) => push(name, 'common'));
  const needle = query.trim().toLocaleLowerCase(language === 'es-PR' ? 'es-PR' : 'en-US');
  return options.filter((option) => !needle || option.name.toLocaleLowerCase().includes(needle)).slice(0, limit);
}
