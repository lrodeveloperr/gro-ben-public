import type { Eligibility, Language } from './domain';

const copy = {
  en: {
    app: 'SNAP & EBT Grocery Tracker', welcome: 'Welcome', chooseLanguage: 'Choose your language', languageSaved: 'You can change this later in Settings.',
    beforeStart: 'Before you start', choices: 'Your data, your choices', independence: 'This independent tracker does not connect to SNAP/EBT, PAN, or the Family Card and does not decide official eligibility. Never enter an EBT card number, a Family Card number, or a PIN.',
    terms: 'Terms & Conditions', privacy: 'Privacy Policy', agreement: 'I have read and agree to the Terms and Privacy Policy.', agree: 'Agree and use the app', changeLanguage: 'Change language',
    cart: 'Cart', purchases: 'Purchases', wallet: 'Wallet', settings: 'Settings', currentCart: 'Current Cart', card: 'Benefit card', addCard: 'Add card', firstCard: 'Add your first benefit card',
    trackedBalance: 'Tracked balance', recordBenefits: 'Record benefits received', storeName: 'Store name', storePlaceholder: 'Type the store name here', optional: 'optional', clone: 'Clone previous cart',
    addItem: 'Add item', itemName: 'Item name', itemPlaceholder: 'Type any grocery item', unitPrice: 'Unit price', quantity: 'Quantity', classification: 'Your benefit classification',
    eligible: 'Marked eligible', notEligible: 'Marked not eligible', unsure: 'Not sure', saveItem: 'Add to cart', savePurchase: 'Save purchase', emptyCart: 'Start a new cart', emptyCartNote: 'Add the first item when you are ready.',
    report: 'Reports', search: 'Search stores, cards, or items', noHistory: 'No matching history', purchaseSaved: 'Purchase saved', undo: 'Undo', done: 'Done', cancel: 'Cancel', delete: 'Delete', correct: 'Correct',
    allTime: 'All-time report', monthly: 'Monthly report', custom: 'Build a custom report', watchView: 'Watch an ad to view', watchGenerate: 'Watch an ad to generate', notNow: 'Not now',
    benefitsUsed: 'Benefits used', totalSpent: 'Total spent', itemCount: 'Items', downloadExcel: 'Excel workbook', downloadPdf: 'PDF report', exportWarning: 'Exported files can be copied, shared, or backed up outside this app. Choose a safe destination.',
    disclaimer: 'Based on your saved entries. Not an official card statement or eligibility determination.', reportUnlocked: 'Report access is open while you stay on this screen.',
    yourCards: 'Your benefit cards', cardName: 'Card name', currentBalance: 'Current tracked balance', amountReceived: 'Benefits received', updateBalance: 'Update tracked balance', color: 'Color', language: 'Language',
    activity: 'Benefits received activity', reverse: 'Reverse', legal: 'Legal & support', support: 'Support', adPrivacy: 'Advertising privacy choices', deleteData: 'Delete tracker data', startOver: 'Delete tracker data?',
    localClarification: 'This only updates the balance recorded in this app. It does not add benefits to your card.', noCard: 'No card recorded', allCards: 'All cards', allStatus: 'All classifications', filter: 'Filter',
    editClassification: 'Change classification', reportOnly: 'This updates matching saved items and future defaults. It does not change any card balance.', removePurchase: 'Delete purchase', correctPurchase: 'Correct purchase',
    adUnavailable: 'No ad is available right now. You can continue without losing your work.', exportFailed: 'The file could not be generated. Your ad access is saved; try again without another ad.',
    ratingTitle: 'Is SNAP & EBT Grocery Tracker helping?', ratingBody: 'A quick store rating helps other shoppers find a private way to plan before checkout.', rate: 'Rate the app',
    differentiate: 'Plan privately before checkout and avoid surprise shortfalls or awkward split payments.',
  },
  'es-PR': {
    app: 'SNAP & EBT Grocery Tracker', welcome: 'Te damos la bienvenida', chooseLanguage: 'Elige tu idioma', languageSaved: 'Puedes cambiarlo luego en Configuración.',
    beforeStart: 'Antes de comenzar', choices: 'Tus datos, tus decisiones', independence: 'Esta aplicación independiente no se conecta a SNAP/EBT, al PAN ni a la Tarjeta de la Familia, y no decide la elegibilidad oficial. Nunca escribas el número de una tarjeta EBT o de la Tarjeta de la Familia ni un PIN.',
    terms: 'Términos y condiciones', privacy: 'Política de privacidad', agreement: 'He leído y acepto los Términos y la Política de privacidad.', agree: 'Aceptar y usar la aplicación', changeLanguage: 'Cambiar idioma',
    cart: 'Carrito', purchases: 'Compras', wallet: 'Tarjetas', settings: 'Configuración', currentCart: 'Carrito actual', card: 'Tarjeta de beneficios', addCard: 'Añadir tarjeta', firstCard: 'Añade tu primera tarjeta de beneficios',
    trackedBalance: 'Balance registrado', recordBenefits: 'Registrar beneficios recibidos', storeName: 'Nombre de la tienda', storePlaceholder: 'Escribe aquí el nombre de la tienda', optional: 'opcional', clone: 'Copiar un carrito anterior',
    addItem: 'Añadir artículo', itemName: 'Nombre del artículo', itemPlaceholder: 'Escribe cualquier artículo del supermercado', unitPrice: 'Precio por unidad', quantity: 'Cantidad', classification: 'Tu clasificación de beneficios',
    eligible: 'Marcado como elegible', notEligible: 'Marcado como no elegible', unsure: 'No estoy seguro', saveItem: 'Añadir al carrito', savePurchase: 'Guardar compra', emptyCart: 'Comienza un carrito nuevo', emptyCartNote: 'Añade el primer artículo cuando estés listo.',
    report: 'Informes', search: 'Busca tiendas, tarjetas o artículos', noHistory: 'No hay resultados en el historial', purchaseSaved: 'Compra guardada', undo: 'Deshacer', done: 'Listo', cancel: 'Cancelar', delete: 'Eliminar', correct: 'Corregir',
    allTime: 'Informe de todo el período', monthly: 'Informe mensual', custom: 'Crear un informe personalizado', watchView: 'Ver un anuncio para abrir', watchGenerate: 'Ver un anuncio para generar', notNow: 'Ahora no',
    benefitsUsed: 'Beneficios usados', totalSpent: 'Total gastado', itemCount: 'Artículos', downloadExcel: 'Archivo de Excel', downloadPdf: 'Informe PDF', exportWarning: 'Los archivos exportados se pueden copiar, compartir o guardar fuera de esta aplicación. Elige un destino seguro.',
    disclaimer: 'Basado en tus entradas guardadas. No es un estado de cuenta oficial de la tarjeta ni una determinación de elegibilidad.', reportUnlocked: 'El acceso permanece abierto mientras estés en esta pantalla.',
    yourCards: 'Tus tarjetas de beneficios', cardName: 'Nombre de la tarjeta', currentBalance: 'Balance registrado actual', amountReceived: 'Beneficios recibidos', updateBalance: 'Actualizar balance registrado', color: 'Color', language: 'Idioma',
    activity: 'Actividad de beneficios recibidos', reverse: 'Revertir', legal: 'Asuntos legales y ayuda', support: 'Centro de ayuda', adPrivacy: 'Opciones de privacidad de anuncios', deleteData: 'Eliminar datos del registro', startOver: '¿Eliminar los datos del registro?',
    localClarification: 'Esto solo actualiza el balance registrado en esta aplicación. No añade beneficios a tu tarjeta.', noCard: 'Sin tarjeta registrada', allCards: 'Todas las tarjetas', allStatus: 'Todas las clasificaciones', filter: 'Filtrar',
    editClassification: 'Cambiar clasificación', reportOnly: 'Esto actualiza los artículos guardados con el mismo nombre y las selecciones futuras. No cambia el balance de ninguna tarjeta.', removePurchase: 'Eliminar compra', correctPurchase: 'Corregir compra',
    adUnavailable: 'No hay anuncios disponibles ahora. Puedes continuar sin perder tu trabajo.', exportFailed: 'No se pudo generar el archivo. Tu acceso está guardado; intenta de nuevo sin otro anuncio.',
    ratingTitle: '¿SNAP & EBT Grocery Tracker te está ayudando?', ratingBody: 'Una calificación rápida ayuda a otras personas a encontrar una forma privada de planificar antes de pagar.', rate: 'Calificar la aplicación',
    differentiate: 'Planifica en privado antes de pagar y evita descubrir en la caja que no tienes balance suficiente o tener que dividir el pago.',
  },
} as const;

export type CopyKey = keyof typeof copy.en;

export function t(language: Language, key: CopyKey) {
  return copy[language][key];
}

export function statusLabel(language: Language, status: Eligibility) {
  return status === 'eligible' ? t(language, 'eligible') : status === 'not-eligible' ? t(language, 'notEligible') : t(language, 'unsure');
}

export function dateLabel(language: Language, iso: string) {
  return new Intl.DateTimeFormat(language === 'es-PR' ? 'es-PR' : 'en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  }).format(new Date(iso));
}
