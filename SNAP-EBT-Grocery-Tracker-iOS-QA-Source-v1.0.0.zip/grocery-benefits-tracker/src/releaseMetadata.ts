export const RELEASE_METADATA = {
  appName: 'SNAP & EBT Grocery Tracker',
  googlePlayDeveloperName: 'Good Use Studios',
  publisherLegalName: 'Lateef Razaq-Oyetola',
  monitoredSupportEmail: 'lrodeveloperr@gmail.com',
  privacyPolicyUrl: 'https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html',
  termsUrl: 'https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/terms.html',
  supportUrl: 'https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html',
} as const;
