import * as Crypto from "expo-crypto";
import * as SQLite from "expo-sqlite";

import type { AppState } from "./domain";
import {
  parseAppState,
  parseEntitlementCache,
  type EntitlementCache,
} from "./storageCodec";

export { parseAppState, parseEntitlementCache } from "./storageCodec";
export type { EntitlementCache } from "./storageCodec";

export const DATABASE_NAME = "snap-ebt-grocery-tracker.db";
const APP_STATE_KEY = "app-state";
const ENTITLEMENT_KEY = "ad-free-entitlement";
const SNAPSHOT_LIMIT = 5;

type StoredRow = {
  payload: string;
  checksum: string;
  updated_at: number;
};

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

async function checksum(payload: string) {
  return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, payload);
}

async function isIntact(row: Pick<StoredRow, "payload" | "checksum">) {
  return (await checksum(row.payload)) === row.checksum;
}

async function database() {
  if (!databasePromise) {
    databasePromise = (async () => {
      const db = await SQLite.openDatabaseAsync(DATABASE_NAME);
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        PRAGMA foreign_keys = ON;
        PRAGMA synchronous = FULL;
        CREATE TABLE IF NOT EXISTS durable_values (
          key TEXT PRIMARY KEY NOT NULL,
          payload TEXT NOT NULL,
          checksum TEXT NOT NULL,
          updated_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS recovery_snapshots (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          key TEXT NOT NULL,
          payload TEXT NOT NULL,
          checksum TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS recovery_snapshots_key_created
          ON recovery_snapshots(key, created_at DESC);
      `);
      return db;
    })();
  }
  return databasePromise;
}

async function loadDurableValue(key: string) {
  const db = await database();
  const current = await db.getFirstAsync<StoredRow>(
    "SELECT payload, checksum, updated_at FROM durable_values WHERE key = ?",
    key,
  );
  if (current && (await isIntact(current))) return current.payload;

  const snapshots = await db.getAllAsync<StoredRow>(
    `SELECT payload, checksum, created_at AS updated_at
       FROM recovery_snapshots
      WHERE key = ?
      ORDER BY created_at DESC
      LIMIT ?`,
    key,
    SNAPSHOT_LIMIT,
  );
  for (const snapshot of snapshots) {
    if (!(await isIntact(snapshot))) continue;
    await db.runAsync(
      `INSERT INTO durable_values(key, payload, checksum, updated_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(key) DO UPDATE SET
         payload = excluded.payload,
         checksum = excluded.checksum,
         updated_at = excluded.updated_at`,
      key,
      snapshot.payload,
      snapshot.checksum,
      Date.now(),
    );
    return snapshot.payload;
  }
  return null;
}

async function saveDurableValue(key: string, payload: string) {
  const db = await database();
  const nextChecksum = await checksum(payload);
  const updatedAt = Date.now();
  await db.withExclusiveTransactionAsync(async (txn) => {
    const current = await txn.getFirstAsync<StoredRow>(
      "SELECT payload, checksum, updated_at FROM durable_values WHERE key = ?",
      key,
    );
    if (current && current.checksum !== nextChecksum) {
      await txn.runAsync(
        `INSERT INTO recovery_snapshots(key, payload, checksum, created_at)
         VALUES (?, ?, ?, ?)`,
        key,
        current.payload,
        current.checksum,
        current.updated_at,
      );
    }
    await txn.runAsync(
      `INSERT INTO durable_values(key, payload, checksum, updated_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(key) DO UPDATE SET
         payload = excluded.payload,
         checksum = excluded.checksum,
         updated_at = excluded.updated_at`,
      key,
      payload,
      nextChecksum,
      updatedAt,
    );
    await txn.runAsync(
      `DELETE FROM recovery_snapshots
        WHERE key = ? AND id NOT IN (
          SELECT id FROM recovery_snapshots
           WHERE key = ?
           ORDER BY created_at DESC, id DESC
           LIMIT ?
        )`,
      key,
      key,
      SNAPSHOT_LIMIT,
    );
  });
}

export async function loadAppState() {
  return parseAppState(await loadDurableValue(APP_STATE_KEY));
}

export async function saveAppState(state: AppState) {
  const payload = JSON.stringify(state);
  if (!parseAppState(payload)) throw new Error("Refusing to persist invalid state");
  await saveDurableValue(APP_STATE_KEY, payload);
}

export async function loadEntitlementCache() {
  return parseEntitlementCache(await loadDurableValue(ENTITLEMENT_KEY));
}

export async function saveEntitlementCache(value: EntitlementCache) {
  const payload = JSON.stringify(value);
  if (!parseEntitlementCache(payload))
    throw new Error("Refusing to persist invalid entitlement cache");
  await saveDurableValue(ENTITLEMENT_KEY, payload);
}

export async function deleteAppState() {
  const db = await database();
  await db.withExclusiveTransactionAsync(async (txn) => {
    await txn.runAsync(
      "DELETE FROM durable_values WHERE key = ?",
      APP_STATE_KEY,
    );
    await txn.runAsync(
      "DELETE FROM recovery_snapshots WHERE key = ?",
      APP_STATE_KEY,
    );
  });
}

export async function runStorageIntegrityCheck() {
  const db = await database();
  const row = await db.getFirstAsync<{ integrity_check: string }>(
    "PRAGMA integrity_check",
  );
  return row?.integrity_check === "ok";
}
