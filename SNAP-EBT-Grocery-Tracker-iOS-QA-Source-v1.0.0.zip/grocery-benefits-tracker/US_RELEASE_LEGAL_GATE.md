# United States and Puerto Rico Release Gate

Implemented boundaries for version 1.0.0:

- Independent manual household planner; no government affiliation, official account connection, eligibility decision, official balance, benefit transfer, or grocery/benefit payment processing.
- Separate SNAP/EBT and PAN program modes; Tarjeta de la Familia is the Puerto Rico card wording.
- No EBT card number, Family Card number, PIN, Social Security number, or government credential fields.
- Adults-only target audience.
- Bilingual Privacy, Terms, Support, and independent-app disclosures.
- Transactional local-only tracker storage, tracker-only deletion, export warning, Android backup disabled, and iOS database backup exclusion.
- UMP before ads, non-personalized requests, no tracker fields in ad requests, safe placements, and ad-failure fallback.
- Android optional monthly/annual subscription and iOS optional non-consumable lifetime purchase; Apple/Google process payment details.
- Production gate prevents simulated purchases or Google test AdMob IDs.

Before store-distributed testing or submission, the Publisher must:

- Configure products, prices, signing, tax/payee information, and store accounts.
- Complete current Apple/Google privacy, billing, advertising, target-audience, age/content, government-affiliation, and testing declarations accurately.
- Verify signed builds, consent geography, accessibility, restoration/expiry/refund behavior, report sharing, and every hosted legal URL.
- Upload the tested legal documents before external store review.
- Compare final Gradle/CocoaPods dependency graphs and signed archives with the third-party notices.
- Add live AdMob identifiers only after explicit approval and publish/verify `app-ads.txt`.
- Recheck SDK disclosures, consent messages, store policy, crash reports, and target-SDK requirements regularly.
- Obtain qualified legal or tax advice if a binding Canadian or U.S. opinion is required.

No legal or store-acceptance guarantee is made.
