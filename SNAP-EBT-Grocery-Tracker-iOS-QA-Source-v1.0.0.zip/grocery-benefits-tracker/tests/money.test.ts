import assert from "node:assert/strict";
import test from "node:test";
import JSZip from "jszip";

import { COMMON_ITEMS_EN, COMMON_ITEMS_ES_PR } from "../src/catalog";
import {
  EMPTY_STATE,
  formatCents,
  hasActiveAdPass,
  parseCents,
  purchaseBalanceError,
  rememberClassification,
  synchronizeClassification,
  totalsFromItems,
  type Purchase,
} from "../src/domain";
import { parseAppState } from "../src/storageCodec";
import { createXlsxReport } from "../src/xlsxReport";

test("stores and parses every amount as exact integer cents", () => {
  assert.equal(parseCents("150.00"), 15_000);
  assert.equal(parseCents("$1,234.56"), 123_456);
  assert.equal(parseCents("10.01"), 1_001);
  assert.equal(parseCents("12.345"), null);
  assert.equal(parseCents("-1.00"), null);
  assert.equal(formatCents(123_456), "$1,234.56");
});

test("allows exact-balance purchases across an adversarial cents grid", () => {
  for (let cents = 1; cents <= 10_000; cents += 37) {
    assert.equal(purchaseBalanceError(cents, cents, "en"), null);
    assert.match(
      purchaseBalanceError(cents, cents + 1, "en") || "",
      /below \$0\.00/,
    );
  }
});

test("blocks purchases on a zero balance", () => {
  assert.match(
    purchaseBalanceError(0, 0, "en") || "",
    /\$0\.00 tracked balance/,
  );
});

test("multiplies quantities without floating point math", () => {
  assert.deepEqual(
    totalsFromItems([
      {
        id: "a",
        name: "Rice",
        priceCents: 349,
        quantity: 3,
        eligibility: "eligible",
      },
      {
        id: "b",
        name: "Soap",
        priceCents: 579,
        quantity: 2,
        eligibility: "not-eligible",
      },
    ]),
    {
      eligibleCents: 1_047,
      notEligibleCents: 1_158,
      unsureCents: 0,
      totalCents: 2_205,
      itemCount: 5,
    },
  );
});

test("historical classification synchronization leaves charged balance snapshots untouched", () => {
  const purchases: Purchase[] = [
    {
      id: "p1",
      store: "Market",
      completedAt: "2026-08-05T12:00:00.000Z",
      cardId: "c1",
      cardName: "Card",
      items: [
        {
          id: "i1",
          name: "Rice",
          priceCents: 500,
          quantity: 1,
          eligibility: "eligible",
          chargedEligible: true,
        },
      ],
      eligibleCents: 500,
      notEligibleCents: 0,
      unsureCents: 0,
      chargedBenefitCents: 500,
      balanceBeforeCents: 2_000,
      balanceAfterCents: 1_500,
      correctedAt: null,
    },
  ];
  const updated = synchronizeClassification(purchases, "rice", "not-eligible");
  assert.equal(updated[0]?.items[0]?.eligibility, "not-eligible");
  assert.equal(updated[0]?.eligibleCents, 0);
  assert.equal(updated[0]?.notEligibleCents, 500);
  assert.equal(updated[0]?.chargedBenefitCents, 500);
  assert.equal(updated[0]?.balanceAfterCents, 1_500);
  assert.equal(updated[0]?.correctedAt, null);
  assert.equal(rememberClassification(updated, " RICE "), "not-eligible");
});

test("ships a generic English catalog plus Puerto Rico staples", () => {
  assert.equal(COMMON_ITEMS_EN.length, 150);
  assert.equal(COMMON_ITEMS_ES_PR.length, 163);
  assert.equal(
    new Set(COMMON_ITEMS_EN.map((value) => value.toLocaleLowerCase())).size,
    150,
  );
  for (const staple of ["Plátanos", "Gandules", "Yautía", "Sofrito", "Pan sobao"])
    assert.ok(COMMON_ITEMS_ES_PR.includes(staple));
  assert.equal(
    new Set(COMMON_ITEMS_ES_PR.map((value) => value.toLocaleLowerCase("es-PR")))
      .size,
    163,
  );
  assert.equal(
    COMMON_ITEMS_EN.some((value) => /™|®/.test(value)),
    false,
  );
});

test("enforces the 30-minute cross-ad cap exactly", () => {
  const shownAt = 1_000_000;
  assert.equal(hasActiveAdPass(shownAt, shownAt + 29 * 60 * 1_000), true);
  assert.equal(hasActiveAdPass(shownAt, shownAt + 30 * 60 * 1_000), false);
  assert.equal(hasActiveAdPass(shownAt, shownAt - 1), false);
});

test("rejects corrupt storage and accepts a valid empty production state", () => {
  assert.equal(parseAppState("{bad-json"), null);
  assert.equal(
    parseAppState(JSON.stringify({ ...EMPTY_STATE, version: 9 })),
    null,
  );
  assert.deepEqual(parseAppState(JSON.stringify(EMPTY_STATE)), EMPTY_STATE);
});

test("migrates version 1 data while requiring a fresh program and terms choice", () => {
  const migrated = parseAppState(
    JSON.stringify({
      ...EMPTY_STATE,
      version: 1,
      program: undefined,
      language: "es-PR",
      acceptedTermsAt: "2026-01-01T00:00:00.000Z",
    }),
  );
  assert.equal(migrated?.version, 2);
  assert.equal(migrated?.program, null);
  assert.equal(migrated?.acceptedTermsAt, null);
});

test("creates a standard offline XLSX workbook with all three report sheets", async () => {
  const bytes = await createXlsxReport({
    language: "es-PR",
    title: "Informe de todo el período",
    scope: "Todos los registros",
    purchases: [
      {
        id: "p1",
        store: "Colmado",
        completedAt: "2026-08-05T12:00:00.000Z",
        cardId: "c1",
        cardName: "Tarjeta de la Familia",
        items: [
          {
            id: "i1",
            name: "Gandules",
            priceCents: 249,
            quantity: 2,
            eligibility: "eligible",
            chargedEligible: true,
          },
        ],
        eligibleCents: 498,
        notEligibleCents: 0,
        unsureCents: 0,
        chargedBenefitCents: 498,
        balanceBeforeCents: 2_000,
        balanceAfterCents: 1_502,
        correctedAt: null,
      },
    ],
  });
  assert.equal(String.fromCharCode(bytes[0] || 0, bytes[1] || 0), "PK");
  const zip = await JSZip.loadAsync(bytes);
  for (const path of [
    "[Content_Types].xml",
    "xl/workbook.xml",
    "xl/styles.xml",
    "xl/worksheets/sheet1.xml",
    "xl/worksheets/sheet2.xml",
    "xl/worksheets/sheet3.xml",
  ])
    assert.ok(zip.file(path), `missing ${path}`);
  const workbook = await zip.file("xl/workbook.xml")?.async("string");
  const items = await zip.file("xl/worksheets/sheet3.xml")?.async("string");
  assert.match(workbook || "", /Historial de compras/);
  assert.match(items || "", /Tarjeta|Gandules/);
  assert.match(items || "", /Gandules/);
});
