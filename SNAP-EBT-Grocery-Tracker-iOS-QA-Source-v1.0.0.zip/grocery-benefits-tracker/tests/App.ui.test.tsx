import { fireEvent, render, screen, waitFor } from "@testing-library/react-native";
import React from "react";

import App from "../App";
import { EMPTY_STATE, type AppState } from "../src/domain";

let mockStoredState: AppState | null = null;
const mockSaveAppState = jest.fn(async (state: AppState) => {
  mockStoredState = state;
});

jest.mock("../src/storage", () => ({
  loadAppState: jest.fn(async () => mockStoredState),
  saveAppState: (state: AppState) => mockSaveAppState(state),
  deleteAppState: jest.fn(async () => {
    mockStoredState = null;
  }),
  loadEntitlementCache: jest.fn(async () => null),
  saveEntitlementCache: jest.fn(async () => undefined),
}));

jest.mock("../src/billing", () => ({
  useAdFreeEntitlement: () => ({
    connected: true,
    entitlementReady: true,
    isAdFree: false,
    activePlanId: null,
    busy: false,
    message: null,
    clearMessage: jest.fn(),
    qaMode: true,
    monthlyPrice: "$0.99",
    annualPrice: "$6.99",
    lifetimePrice: "$12.99",
    buyAndroidPlan: jest.fn(async () => undefined),
    buyIosLifetime: jest.fn(async () => undefined),
    restore: jest.fn(async () => undefined),
    refreshEntitlement: jest.fn(async () => false),
    manageAndroidSubscription: jest.fn(async () => undefined),
    resetQaPurchase: jest.fn(async () => undefined),
  }),
}));

jest.mock("../src/ads", () => {
  const React = require("react");
  const { View } = require("react-native");
  return {
    AdPrivacyButton: () => null,
    WalletBanner: () => React.createElement(View),
    InlineReportAd: () => React.createElement(View),
    initializeAdsAndPrecache: jest.fn(async () => true),
    revalidateAdsOnForeground: jest.fn(),
    showNaturalBreakInterstitial: jest.fn(async () => false),
    showRewardedReportAd: jest.fn(async () => "unavailable"),
  };
});

jest.mock("../src/reporting", () => ({
  cleanupTemporaryReports: jest.fn(),
  shareExcelReport: jest.fn(async () => undefined),
  sharePdfReport: jest.fn(async () => undefined),
}));

jest.mock("expo-store-review", () => ({
  hasAction: jest.fn(async () => true),
  requestReview: jest.fn(async () => undefined),
}));

beforeEach(() => {
  jest.clearAllMocks();
  mockStoredState = null;
});

test("requires language, program, and legal agreement on first use", async () => {
  await render(<App />);
  expect(await screen.findByText("Choose your language")).toBeTruthy();
  await fireEvent.press(screen.getByText("English"));
  expect(await screen.findByText("Which card do you track?")).toBeTruthy();
  await fireEvent.press(screen.getByText("SNAP / EBT"));
  expect(await screen.findByText("Your data, your choices")).toBeTruthy();
  const agree = screen.getByRole("button", { name: "Agree and use the app" });
  expect(agree.props.accessibilityState).toEqual({ disabled: true });
  await fireEvent.press(screen.getByRole("checkbox"));
  await fireEvent.press(
    screen.getByRole("button", { name: "Agree and use the app" }),
  );
  expect(await screen.findByText("Current Cart")).toBeTruthy();
  expect(screen.getByText("Add your first EBT card")).toBeTruthy();
});

test("supports PAN and Puerto Rican Spanish navigation", async () => {
  await render(<App />);
  await fireEvent.press(await screen.findByText("Español"));
  await fireEvent.press(await screen.findByText("Programa de Asistencia Nutricional (PAN)"));
  expect(await screen.findByText("Tus datos, tus decisiones")).toBeTruthy();
  await fireEvent.press(screen.getByRole("checkbox"));
  await fireEvent.press(
    screen.getByRole("button", { name: "Aceptar y usar la aplicación" }),
  );
  expect(await screen.findByText("Carrito actual")).toBeTruthy();
  await fireEvent.press(screen.getByText("Tarjetas"));
  expect(await screen.findByText("Tarjeta de la Familia")).toBeTruthy();
  await fireEvent.press(screen.getByText("Configuración"));
  expect(await screen.findByText("Español (Puerto Rico)")).toBeTruthy();
});

test("adds a card with an exact-cent tracked balance", async () => {
  mockStoredState = {
    ...EMPTY_STATE,
    language: "en",
    program: "snap-ebt",
    acceptedTermsAt: "2026-08-05T00:00:00.000Z",
  };
  await render(<App />);
  await fireEvent.press(await screen.findByText("Add your first EBT card"));
  await fireEvent.changeText(
    screen.getByPlaceholderText("e.g. Household card"),
    "Family card",
  );
  await fireEvent.changeText(screen.getByPlaceholderText("0.00"), "123.45");
  await fireEvent.press(screen.getByRole("button", { name: "Add card" }));
  expect((await screen.findAllByText("Family card")).length).toBeGreaterThanOrEqual(1);
  expect(screen.getAllByText("$123.45").length).toBeGreaterThanOrEqual(1);
});

test("does not repeat onboarding after relaunch", async () => {
  mockStoredState = {
    ...EMPTY_STATE,
    language: "en",
    program: "snap-ebt",
    acceptedTermsAt: "2026-08-05T00:00:00.000Z",
  };
  await render(<App />);
  expect(await screen.findByText("Current Cart")).toBeTruthy();
  expect(screen.queryByText("Choose your language")).toBeNull();
  expect(screen.queryByText("Which card do you track?")).toBeNull();
  await waitFor(() => expect(mockSaveAppState).toHaveBeenCalled());
});

test("does not preselect a classification for a catalog item", async () => {
  mockStoredState = {
    ...EMPTY_STATE,
    language: "en",
    program: "snap-ebt",
    acceptedTermsAt: "2026-08-05T00:00:00.000Z",
    cards: [
      {
        id: "card-1",
        name: "Family card",
        balanceCents: 10_000,
        color: "emerald",
        createdAt: "2026-08-05T00:00:00.000Z",
      },
    ],
    activeCardId: "card-1",
  };
  await render(<App />);
  await fireEvent.press(await screen.findByText("＋ Add item"));
  await fireEvent.changeText(screen.getByPlaceholderText("Type any grocery item"), "Bananas");
  expect(
    screen
      .getAllByRole("radio")
      .every((option) => option.props.accessibilityState.selected === false),
  ).toBe(true);
  expect(
    screen.getByRole("button", { name: "Add to cart" }).props.accessibilityState,
  ).toEqual({ disabled: true });
});
