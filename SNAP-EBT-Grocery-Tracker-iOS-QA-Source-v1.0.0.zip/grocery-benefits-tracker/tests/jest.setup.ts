jest.mock('react-native-google-mobile-ads', () => {
  const React = require('react');
  const { View } = require('react-native');
  const mobileAds = () => ({
    initialize: jest.fn(async () => []),
    setRequestConfiguration: jest.fn(async () => undefined),
  });
  const createFullScreenAd = () => ({
    addAdEventListener: jest.fn(() => jest.fn()),
    load: jest.fn(),
    show: jest.fn(async () => undefined),
  });
  return {
    __esModule: true,
    default: mobileAds,
    AdsConsent: {
      gatherConsent: jest.fn(async () => ({ canRequestAds: true })),
      getConsentInfo: jest.fn(async () => ({
        privacyOptionsRequirementStatus: 'not-required',
      })),
      showPrivacyOptionsForm: jest.fn(async () => undefined),
    },
    AdsConsentPrivacyOptionsRequirementStatus: {
      REQUIRED: 'required',
      NOT_REQUIRED: 'not-required',
    },
    AdEventType: { LOADED: 'loaded', CLOSED: 'closed', ERROR: 'error' },
    RewardedAdEventType: { EARNED_REWARD: 'earned_reward' },
    RewardedAd: { createForAdRequest: jest.fn(createFullScreenAd) },
    InterstitialAd: { createForAdRequest: jest.fn(createFullScreenAd) },
    BannerAd: ({ children }: { children?: React.ReactNode }) =>
      React.createElement(View, null, children),
    BannerAdSize: {
      ANCHORED_ADAPTIVE_BANNER: 'adaptive',
      LARGE_BANNER: 'large',
    },
    MaxAdContentRating: { PG: 'PG' },
    TestIds: {
      REWARDED: 'test-rewarded',
      INTERSTITIAL: 'test-interstitial',
      ADAPTIVE_BANNER: 'test-banner',
    },
  };
});

globalThis.IS_REACT_ACT_ENVIRONMENT = true;
global.IS_REACT_ACT_ENVIRONMENT = true;

jest.mock('expo-file-system', () => ({
  File: jest.fn(),
  Paths: { cache: 'file://cache/' },
}));
jest.mock('expo-print', () => ({ printToFileAsync: jest.fn(async () => ({ uri: 'file://report.pdf' })) }));
jest.mock('expo-sharing', () => ({ shareAsync: jest.fn(async () => undefined) }));

jest.mock('react-native-safe-area-context', () => {
  const React = require('react');
  const { View } = require('react-native');

  return {
    SafeAreaProvider: ({ children }: { children: React.ReactNode }) => children,
    SafeAreaView: ({ children, ...props }: { children: React.ReactNode }) =>
      React.createElement(View, props, children),
    useSafeAreaInsets: () => ({ top: 0, right: 0, bottom: 0, left: 0 }),
  };
});
