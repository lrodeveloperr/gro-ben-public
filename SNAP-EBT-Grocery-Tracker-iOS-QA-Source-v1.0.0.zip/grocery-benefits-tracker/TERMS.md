---
title: Terms and Conditions — SNAP & EBT Grocery Tracker
description: Terms and Conditions for SNAP & EBT Grocery Tracker on Android and iOS
---

# SNAP & EBT Grocery Tracker Terms and Conditions

**Effective date:** August 6, 2026  
**Last updated:** August 6, 2026  
**Applies to:** Version 1.0.0 on Android and iOS

These Terms and Conditions (**Terms**) govern your use of SNAP & EBT Grocery Tracker (the **App**). The App is provided by **Lateef Razaq-Oyetola**, an individual developer in Ontario, Canada (**Publisher**, **we**, **us**, or **our**). The Google Play listing may display the developer-profile name **Good Use Studios**; that profile name is not a separate legal entity. The Apple App Store seller is **Lateef Razaq-Oyetola**.

A substantively equivalent Puerto Rican Spanish version appears [below](#términos-y-condiciones--español-puerto-rico).

## 1. Agreement

On first use, the App asks you to choose a language and confirm that you have read and agree to these Terms and the [Privacy Policy](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html). If you do not agree, do not select the agreement control or use the App.

These Terms supplement the rules of the store from which you obtained the App. For an iOS download, Apple's [Standard Licensed Application End User License Agreement](https://www.apple.com/legal/internet-services/itunes/dev/stdeula/) (**Apple Standard EULA**) also applies. If these Terms conflict with a mandatory store term or a non-waivable law, the mandatory term or law controls to the extent of the conflict.

## 2. Adults only and market

You must be **18 years or older** and legally able to agree to these Terms. The App is intended for adults in the 50 U.S. states, Washington, D.C., and Puerto Rico. Do not use the App where its use would violate applicable law.

The App is not directed to children and must not be used as a child-directed service.

## 3. Limited license

Subject to these Terms and applicable store rules, the Publisher grants you a personal, limited, revocable, non-exclusive, non-transferable license to install and use the App on a device you own or control for lawful household grocery-benefit planning.

You may not sell, sublicense, distribute, reverse engineer, tamper with, misuse, interfere with, or attempt unauthorized access to the App or its services, except to the extent applicable law expressly permits an activity that cannot be restricted by contract.

## 4. What the App does

The App is a manual, device-local grocery-benefit tracker. It lets you:

- choose English or Puerto Rican Spanish independently from the benefit program;
- choose **SNAP/EBT — States and D.C.** or **Nutrition Assistance Program (NAP; PAN in Spanish) — Puerto Rico**;
- create locally named benefit-card records and tracked balances;
- record benefits received and reversals;
- build carts with item names, prices, quantities, and your own classifications;
- save, copy, search, filter, correct, and delete purchase records;
- remember a classification for a matching item name while keeping historical tracked-balance adjustments controlled; and
- view All-time, Monthly, and Custom reports and generate Excel and U.S.-Letter PDF exports on the device.

The App has no account, login, Publisher-operated database, or Publisher-operated cloud backup. Its core tracking functions work without internet. Internet access is used for advertising, optional App purchases, and external links. Google Play offers optional Android subscriptions, and the Apple App Store offers an optional iOS non-consumable purchase, as described below.

## 5. Independent manual tracker—not an official service

SNAP, EBT, PAN, and NAP are used descriptively. The App is **not affiliated with, endorsed by, authorized by, sponsored by, or operated by the U.S. Department of Agriculture (USDA), the USDA Food and Nutrition Administration (FNA, formerly FNS), the Puerto Rico Department of the Family or ADSEF, any state, territorial, or tribal agency, any EBT processor, any retailer, Apple, or Google**.

The App does not:

- connect to an EBT, NAP/PAN, or government benefit account;
- load, receive, issue, transfer, or process benefits;
- display or verify an official balance or transaction history;
- determine SNAP, PAN, NAP, household, or item eligibility;
- submit a grocery purchase or process a grocery or benefit payment; or
- guarantee how a retailer, terminal, agency, or benefit program will treat an item or transaction.

Official program rules, your official account, retailer systems, receipts, and applicable law control. Confirm important balances, transactions, eligible items, and program rules with an official source.

## 6. Your entries, classifications, and tracked balances

The App's results depend on information you enter and choices you make. **Tracked balance** means only the figure recorded locally in the App. Recording benefits received changes that local figure; it does not add benefits to a real card.

**Marked eligible**, **marked not eligible**, and **not sure** are your personal planning classifications. They are not legal advice, an agency determination, or a retailer guarantee. A remembered classification for a matching name is a convenience only; you remain responsible for reviewing it.

Price, quantity, purchase, deletion, benefit-receipt, and reversal changes may adjust a tracked balance as shown. A historical classification change may affect reports and future defaults without changing a real account or automatically rewriting a historical tracked charge. Review every entry and correction before relying on it.

## 7. Your responsibilities

You agree to:

- enter information lawfully and review it for accuracy;
- use official sources whenever an exact benefit balance or eligibility decision matters;
- protect your device with reasonable security;
- review copied prices and classifications before saving a copied cart;
- review reports before sharing them; and
- delete exported files from every destination where you no longer want them stored.

**Never enter or send an EBT card number, a Family Card number, PIN, Social Security number, government-account credential, or other authentication secret.** The App does not need them. Support will never ask for your PIN.

You retain your rights in information you enter. Because the Publisher does not receive your locally stored entries, you grant no license to the Publisher over them. If you voluntarily send information to support, you permit its limited use to answer the request, protect the App and users, and meet legal obligations as described in the Privacy Policy.

## 8. Advertising

The free version is supported by Google Mobile Ads. Advertising must not cover, disable, or delay the controls used to record a card, balance, cart, or purchase. Every ad format described in this section is removed while a valid ad-free entitlement is active.

### Advertising on both platforms

- **Cards screen:** an anchored adaptive banner may remain in a dedicated, separated area while the Cards screen is open and an ad is available. It does not overlap logging or navigation controls. When offline or no ad is available, the space remains empty or collapses safely.
- **History:** after you view and close every third purchase or item detail, one closeable interstitial may appear at that natural break, capped at no more than once every 30 minutes. The requested detail appears before the ad.
- **Shopping and logging:** no full-screen ad interrupts entry of a card, balance, benefit receipt, cart item, or saved purchase.

### Android report advertising

Android uses clearly disclosed, separately initiated rewarded ads:

| Android action | Advertising rule and access provided |
|---|---|
| Monthly report | You may choose to complete **one rewarded ad** to unlock the in-App report plus its Excel and PDF exports until you leave that report page. Reopening it starts a new report session. |
| All-time report | You may choose to complete **two rewarded ads** to unlock the in-App report plus its Excel and PDF exports until you leave that report page. The App states **2 ads required**, shows **1 of 2 / 2 of 2**, and requires a separate affirmative choice before each ad. The second ad never starts automatically. |
| Custom report | Selecting filters is free. Generating Excel requires one rewarded ad. Generating PDF requires a separate rewarded ad. Generating both formats therefore requires two rewarded ads. |

Completing the first All-time ad earns progress toward that two-ad unlock. That completed first-ad credit remains in local App state until the second ad is completed or App storage is cleared; a temporary interruption or ad-unavailability event does not erase it. Before each rewarded ad, the App identifies the action and reward. You may choose **Not now**.

Closing or skipping a rewarded ad before Google reports completion does not count and does not unlock the report or file. You are never required to click an ad, install anything, buy anything, submit personal information, or rate the App.

If, after you choose to watch a rewarded ad, the ad cannot load or show because of connectivity, ad availability, consent status, or a technical error, the App displays an unavailability message and opens the requested report or export without an ad. Voluntarily closing a loaded ad before completion does not unlock it. If you earned an export but file generation fails, retrying that same export does not require another ad.

### iOS report advertising

On iOS, advertising never unlocks functionality. Reports and exports remain available even if an ad is closed, unavailable, or cannot load.

| iOS action | Non-blocking advertising rule |
|---|---|
| Monthly report | The report opens regardless. One closeable interstitial may appear at the report transition, and one clearly identified inline ad may appear on the report page. |
| All-time report | The report opens regardless. One closeable interstitial may appear after the report renders at a natural transition, one inline ad may appear on the report page, and a second interstitial may appear only after a later completed export/share action—not back-to-back with the first. |
| Custom Excel or PDF | The file is generated and the share action proceeds regardless. One closeable interstitial may appear only after the completed export/share action for that format. |

An iOS ad may be dismissed without penalty. An ad failure, privacy choice, or lack of internet never blocks a report or export.

### Ad content, duration, privacy, and reporting

Google and participating ad sources control available creative, format, duration, audio, close timing, and ad availability. The Publisher does not promise an exact five-second interstitial, a 30-second rewarded ad, a particular advertiser, or a particular reward value beyond the App access stated above.

Ads must be identifiable and dismissible where the format requires it. Use **Settings → Report an ad** or the ad's own information/report control to report inappropriate or age-inappropriate advertising. Advertising privacy choices are available in Settings when required. See the [Privacy Policy](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html) and [Support page](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html).

### Optional ad-free purchases

- **Android:** Google Play offers one ad-free subscription with monthly and annual base plans. The store displays the current price and billing period before purchase. The selected plan renews automatically until canceled through Google Play. Canceling stops future renewal; access normally continues through the paid period. If the subscription expires, is refunded, revoked, or otherwise becomes inactive, ads may return. Tracker data and functionality are not deleted or restricted.
- **iOS:** the Apple App Store offers a one-time, non-consumable **Remove Ads Forever** purchase. It is not a subscription and does not expire, subject to the App Store account, refund, revocation, and store rules. The App provides **Restore Purchase**.
- **Both platforms:** Apple or Google—not the Publisher—processes payment and any payment-card information. The price, tax, currency, refund eligibility, billing authorization, and transaction are controlled by the applicable store and its terms. The App stores only limited entitlement status locally; it does not store payment-card details. Android and iOS purchases are separate and do not transfer between platforms. There is no free trial unless the applicable store expressly displays one.

Use Google Play to manage or cancel an Android subscription. Use the applicable Apple or Google refund process for a refund request. Deleting tracker data does not cancel, refund, or delete a store purchase. Uninstalling the App does not by itself cancel an Android subscription.

## 9. Local storage, exports, and possible data loss

Tracker records are stored in the App's private local container. Android app-data backup is disabled, and App-created tracker files on iOS are configured not to be included in iCloud or device-cloud backup. The App uses local transactional storage and recovery data, but it cannot guarantee recovery after uninstalling, clearing storage, device loss, hardware failure, or operating-system action.

Excel and PDF reports are generated on the device and may contain private household-shopping information. When you save or share a report, the selected destination controls that copy. The Publisher cannot retrieve or delete it for you. Exporting is not an importable App backup.

Use **Settings → Delete tracker data** to remove tracker records and local recovery copies. This does not delete exported files, third-party advertising records, or information held independently by Apple, Google, email providers, or sharing destinations.

## 10. No professional or official advice

The App is a manual household-planning aid. It is not financial, legal, tax, nutritional, social-service, benefits, or other professional advice. Reports are based only on saved entries and are not official statements, receipts, eligibility decisions, or evidence that an agency or retailer must accept.

For an official balance, transaction, eligible-food rule, lost card, suspected fraud, denied purchase, or benefit decision, contact the applicable official agency, benefit-card customer-service channel, retailer, or USDA resource.

## 11. Privacy

The [Privacy Policy](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html) explains local storage, Google Mobile Ads and UMP data, support communications, exports, retention, deletion, adults-only positioning, cross-border processing, and privacy choices. By using the App, you acknowledge those practices. Consent or privacy choices for advertising are handled through the applicable privacy flow where required.

## 12. Third-party services

The App depends in part on third-party software and services, including Apple or Google distribution, Google Mobile Ads and UMP, operating-system file and sharing functions, email, and destinations you select. Their terms and policies apply to their services. The Publisher does not control their availability, ad content, official benefit systems, retailer systems, or your selected export destinations.

The Publisher—not Apple, Google, USDA, a government agency, benefit processor, or retailer—is responsible for the App and its support, except where a store's terms state otherwise. Apple and Google have no obligation to provide maintenance or support for the App beyond their own applicable obligations.

See [Third-Party Notices](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/third-party-notices.html).

## 13. Ownership and trademarks

The Publisher and licensors own the App's original software, design, text, graphics, and other protected material, excluding your entries and third-party material. These Terms do not transfer ownership to you. Open-source software remains governed by its applicable licenses.

Third-party names and marks, including SNAP, EBT, PAN, NAP, USDA, Apple, Google, and Excel, are used descriptively and remain the property of their respective owners, where applicable. Descriptive reference does not imply endorsement.

## 14. Availability, updates, and changes

We aim to keep the App useful, secure, and compatible, but do not promise uninterrupted availability, ad availability, compatibility with every device or sharing destination, permanent availability of every feature, or acceptance of every report by third-party software.

We may release updates to correct errors, improve security or accessibility, maintain compatibility, respond to law or store policy, or change features. Store acceptance and continued listing are controlled by Apple and Google.

## 15. Disclaimer of warranties

To the maximum extent permitted by applicable law, the App is provided **“as is” and “as available.”** The Publisher disclaims implied warranties of merchantability, fitness for a particular purpose, non-infringement, accuracy, and uninterrupted or error-free operation.

This clause does not exclude any warranty, condition, right, or remedy that applicable consumer law does not permit us to exclude.

## 16. Limitation of liability

To the maximum extent permitted by applicable law, the Publisher will not be liable for indirect, incidental, special, consequential, exemplary, or punitive damages, or for lost data, lost benefits, denied transactions, checkout delays, embarrassment, device loss, lost opportunities, or reliance on inaccurate entries, classifications, tracked balances, reports, third-party ads, retailer decisions, program changes, or unavailable services.

Where liability cannot legally be excluded, it is limited only to the extent permitted by applicable law. Nothing in these Terms limits liability for fraud, willful misconduct, gross negligence, personal injury caused by negligence, or any consumer right or remedy that cannot legally be limited.

## 17. Ending use or distribution

You may stop using the App at any time and may delete tracker data before uninstalling. We may suspend support or distribution if reasonably necessary for security, abuse prevention, law, third-party requirements, or store policy. Ending distribution does not give the Publisher access to data on your device.

Sections that by their nature should survive—including ownership, disclaimers, liability limits, governing law, and dispute terms—continue after use ends.

## 18. Governing law and disputes

These Terms are governed by the laws of Ontario and the applicable federal laws of Canada, without regard to conflict-of-law rules. This choice does **not** deprive a U.S. consumer of mandatory federal, state, territorial, or local protections that apply to that consumer.

Before filing a claim, you and the Publisher are encouraged to try to resolve it by emailing `lrodeveloperr@gmail.com`. This informal step does not shorten or waive a legal deadline. Ontario courts have non-exclusive jurisdiction, subject to any right to bring a claim in another competent forum under mandatory law.

These Terms do not require arbitration and do not waive participation in a class action where such a waiver would be invalid or unavailable.

## 19. General terms

If a provision is unenforceable, it will be limited or removed only to the minimum extent necessary, and the rest will continue. Failure to enforce a provision is not a waiver. You may not assign these Terms without consent. The Publisher may assign them as part of a lawful transfer of the App or related business, subject to applicable privacy and consumer law.

## 20. Changes to these Terms

We may update these Terms for changes in the App, advertising, law, or store requirements. New Terms will show a new effective date. Material changes will be highlighted in the App, release notes, or store listing when reasonably practicable. Renewed agreement will be requested when required by law; otherwise, continued use after the effective date means you accept the updated Terms.

## 21. Contact

**Publisher:** Lateef Razaq-Oyetola  
**Location:** Ontario, Canada  
**Email:** `lrodeveloperr@gmail.com`  
**Support:** [SNAP & EBT Grocery Tracker Support](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html)

---

# Términos y condiciones — Español (Puerto Rico)

**Fecha de vigencia:** 6 de agosto de 2026  
**Última actualización:** 6 de agosto de 2026  
**Aplica a:** Versión 1.0.0 en Android y iOS

Estos Términos y condiciones (**Términos**) rigen el uso de SNAP & EBT Grocery Tracker (la **Aplicación**). La Aplicación es ofrecida por **Lateef Razaq-Oyetola**, desarrollador individual en Ontario, Canadá (el **Proveedor**, **nosotros** o **nuestro**). La ficha de Google Play puede mostrar el nombre de perfil **Good Use Studios**; ese perfil no es una entidad legal separada. El vendedor en Apple App Store es **Lateef Razaq-Oyetola**.

## 1. Aceptación

La primera vez, la Aplicación pide escoger idioma y confirmar que leíste y aceptas estos Términos y la [Política de privacidad](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html). Si no aceptas, no marques el control ni uses la Aplicación.

Estos Términos complementan las reglas de la tienda. Para iOS también aplica la [Licencia estándar de aplicaciones de Apple](https://www.apple.com/legal/internet-services/itunes/dev/stdeula/). Si hay conflicto con una regla obligatoria de la tienda o una disposición legal irrenunciable, esa regla o ley controla en la medida del conflicto.

## 2. Solo para personas adultas y mercado

Debes tener **18 años o más** y capacidad legal para aceptar. La Aplicación está destinada a personas adultas en los 50 estados, Washington D.C. y Puerto Rico. No la uses donde hacerlo viole la ley.

No está dirigida a menores ni debe usarse como servicio para niños.

## 3. Licencia limitada

Sujeto a estos Términos y las reglas de la tienda, el Proveedor concede una licencia personal, limitada, revocable, no exclusiva e intransferible para instalar y usar la Aplicación en un dispositivo que poseas o controles para la planificación lícita de compras del hogar con beneficios de asistencia alimentaria.

No puedes vender, sublicenciar, distribuir, hacer ingeniería inversa, alterar, usar indebidamente, interferir ni intentar acceso no autorizado, salvo cuando una ley permita expresamente una actividad que no pueda restringirse por contrato.

## 4. Qué hace la Aplicación

Es un registro manual y local de beneficios para compras. Permite:

- escoger inglés o español de Puerto Rico independientemente del programa;
- escoger **SNAP/EBT — Estados y D.C.** o **Programa de Asistencia Nutricional (PAN; NAP, por sus siglas en inglés) — Puerto Rico**;
- crear registros locales de tarjetas y balances registrados;
- registrar beneficios recibidos y reversiones;
- crear carritos con nombres, precios, cantidades y tus clasificaciones;
- guardar, copiar, buscar, filtrar, corregir y eliminar compras;
- recordar una clasificación para un artículo con el mismo nombre manteniendo controlados los ajustes históricos; y
- ver informes de Todo el período, Mensuales y Personalizados y generar Excel y PDF tamaño Carta de EE. UU. en el dispositivo.

No hay cuenta de la Aplicación, inicio de sesión, base de datos del Proveedor ni copia en la nube del Proveedor. El registro funciona sin internet. Internet se usa para anuncios, compras opcionales de la Aplicación y enlaces externos. Google Play ofrece suscripciones opcionales en Android y el Apple App Store ofrece una compra no consumible opcional en iOS, según se explica abajo.

## 5. Registro manual independiente, no servicio oficial

SNAP, EBT, PAN y NAP se mencionan únicamente con fines descriptivos. La Aplicación **no está afiliada, respaldada, autorizada, patrocinada ni operada por USDA, la Food and Nutrition Administration (FNA, antes FNS), el Departamento de la Familia de Puerto Rico o ADSEF, ninguna agencia estatal, territorial o tribal, ningún procesador EBT, ningún comercio, Apple ni Google**.

La Aplicación no:

- se conecta a una cuenta EBT, PAN, NAP o gubernamental;
- carga, recibe, emite, transfiere ni procesa beneficios;
- muestra ni verifica balances o transacciones oficiales;
- decide elegibilidad de SNAP, PAN, NAP, hogares o artículos;
- envía compras de supermercado ni procesa pagos de supermercado o de beneficios; ni
- garantiza cómo una tienda, terminal, agencia o programa tratará un artículo o transacción.

Controlan las reglas oficiales, la cuenta oficial, los sistemas del comercio, los recibos y la ley. Confirma información importante con una fuente oficial.

## 6. Entradas, clasificaciones y balances registrados

Los resultados dependen de lo que escribes y escoges. **Balance registrado** significa solamente la cifra local. Registrar beneficios recibidos cambia esa cifra; no añade beneficios a una tarjeta real.

**Marcado como elegible**, **marcado como no elegible** y **no estoy seguro** son etiquetas personales. No son asesoría legal, decisión de una agencia ni garantía de un comercio. Una clasificación recordada para un artículo con el mismo nombre es solo una conveniencia; debes revisarla.

Cambios de precio, cantidad, compra, eliminación, beneficios o reversiones pueden ajustar el balance registrado. Una reclasificación histórica puede cambiar informes y selecciones futuras sin cambiar una cuenta real ni reescribir automáticamente un cargo histórico. Revisa todo antes de confiar.

## 7. Tus responsabilidades

Aceptas:

- ingresar información legalmente y revisarla;
- usar fuentes oficiales cuando necesites una cifra o decisión exacta;
- proteger el dispositivo;
- revisar precios y clasificaciones de carritos copiados;
- revisar informes antes de compartir; y
- borrar archivos exportados de todos los destinos donde ya no los quieras.

**Nunca escribas ni envíes el número de una tarjeta EBT o de la Tarjeta de la Familia, un PIN, número de Seguro Social, credencial gubernamental ni otro secreto de acceso.** La Aplicación no los necesita. El equipo de ayuda nunca pedirá tu PIN.

Conservas tus derechos sobre tus entradas. Como el Proveedor no recibe los registros locales, no le concedes licencia sobre ellos. Si envías información voluntariamente al equipo de ayuda, permites el uso limitado para responder, proteger la Aplicación y cumplir obligaciones según la Política de privacidad.

## 8. Anuncios

La versión gratis usa Google Mobile Ads. La publicidad no debe cubrir, desactivar ni retrasar controles para registrar tarjetas, balances, carritos o compras. Todos los anuncios descritos en esta sección se eliminan mientras esté activo un derecho válido de acceso sin anuncios.

### En ambas plataformas

- **Pantalla de tarjetas:** puede permanecer un banner adaptable anclado en un área separada mientras la pantalla esté abierta y haya un anuncio disponible. No se superpone a controles. Sin internet o disponibilidad de anuncios, el espacio queda vacío o se cierra sin afectar el registro.
- **Historial:** después de ver y cerrar cada tercer detalle de compra o artículo, puede aparecer un anuncio intersticial que se puede cerrar en esa pausa natural, máximo uno cada 30 minutos. El detalle aparece antes.
- **Compras y registro:** ningún anuncio de pantalla completa interrumpe tarjetas, balances, beneficios, artículos o guardado de compras.

### Informes en Android

Android usa anuncios recompensados claramente explicados y comenzados por separado:

| Acción en Android | Regla y acceso |
|---|---|
| Informe mensual | Puedes completar **un anuncio recompensado** para abrir el informe, Excel y PDF hasta salir de la página. Al abrir de nuevo comienza otra sesión. |
| Informe de todo el período | Puedes completar **dos anuncios recompensados** para abrir el informe, Excel y PDF hasta salir. La Aplicación dice **se requieren 2 anuncios**, muestra **1 de 2 / 2 de 2** y pide una elección separada antes de cada anuncio. El segundo nunca comienza automáticamente. |
| Informe personalizado | Escoger filtros es gratis. Excel requiere un anuncio y PDF requiere otro. Ambos formatos requieren dos anuncios en total. |

Completar el primer anuncio de Todo el período conserva progreso hacia el desbloqueo. Ese primer crédito permanece en el estado local hasta completar el segundo anuncio o borrar el almacenamiento de la Aplicación; una interrupción temporal o falta de anuncio no lo elimina. Antes de cada anuncio, se explica la acción y recompensa. Puedes escoger **Ahora no**.

Cerrar u omitir antes de que Google confirme la recompensa no cuenta. Nunca tienes que tocar el anuncio, instalar, comprar, dar información personal ni calificar la Aplicación.

Si, después de que eliges ver un anuncio recompensado, el anuncio no puede cargar o mostrarse por conexión, disponibilidad de anuncios, consentimiento o error técnico, la Aplicación muestra un aviso y abre el informe o exportación sin anuncio. Cerrar voluntariamente un anuncio cargado antes de completarlo no lo desbloquea. Si ganaste una exportación y falla el archivo, reintentar esa misma exportación no exige otro anuncio.

### Informes en iOS

En iOS, los anuncios nunca condicionan el acceso a funciones. Informes y exportaciones están disponibles aunque un anuncio se cierre, falle o no cargue.

| Acción en iOS | Regla publicitaria sin bloqueo |
|---|---|
| Informe mensual | Abre de todas maneras. Puede aparecer un anuncio intersticial que se puede cerrar en la transición y un anuncio integrado claramente identificado dentro de la página. |
| Informe de todo el período | Abre de todas maneras. Puede aparecer un anuncio intersticial que se puede cerrar después de mostrarse el informe, un anuncio integrado y un segundo anuncio intersticial solamente después de una exportación o acción de compartir posterior—nunca seguido inmediatamente del primero. |
| Excel o PDF personalizado | El archivo se genera y se comparte de todas maneras. Puede aparecer un anuncio intersticial que se puede cerrar solamente después de completar la exportación o compartir ese formato. |

Cerrar un anuncio de iOS no tiene penalidad. Falla, opción de privacidad o falta de internet nunca bloquea informe o exportación.

### Contenido, duración, privacidad e informes de anuncios

Google y las fuentes participantes controlan contenido, formato, duración, audio, cierre y disponibilidad de anuncios. El Proveedor no promete exactamente cinco segundos, 30 segundos, un anunciante específico ni otra recompensa fuera del acceso indicado.

Los anuncios deben identificarse y poder cerrarse cuando corresponda. Usa **Configuración → Informar un anuncio** o el control del propio anuncio para informar publicidad inapropiada. Las opciones de privacidad aparecen en Configuración cuando se requieren. Consulta la [Política de privacidad](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html) y el [Centro de ayuda](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html).

### Compras opcionales sin anuncios

- **Android:** Google Play ofrece una suscripción sin anuncios con planes base mensuales y anuales. La tienda muestra el precio y período vigentes antes de comprar. El plan se renueva automáticamente hasta que lo canceles en Google Play. La cancelación detiene renovaciones futuras; por lo general, el acceso continúa durante el período pagado. Si la suscripción vence, se reembolsa, se revoca o deja de estar activa, pueden volver los anuncios. Los datos y funciones del registro no se borran ni restringen.
- **iOS:** el Apple App Store ofrece una compra única no consumible para **Eliminar anuncios para siempre**. No es una suscripción y no vence, sujeto a la cuenta del App Store, reembolsos, revocaciones y reglas de la tienda. La Aplicación ofrece **Restaurar compra**.
- **Ambas plataformas:** Apple o Google—no el Proveedor—procesan el pago y cualquier dato de la tarjeta de pago. La tienda aplicable controla el precio, impuesto, moneda, elegibilidad de reembolso, autorización y transacción. La Aplicación guarda localmente solo un estado limitado del derecho de acceso; no guarda datos de tarjetas de pago. Las compras de Android y iOS son separadas y no se transfieren entre plataformas. No hay prueba gratis salvo que la tienda la muestre expresamente.

Usa Google Play para administrar o cancelar una suscripción de Android. Usa el proceso de Apple o Google para pedir un reembolso. Eliminar datos del registro no cancela, reembolsa ni elimina una compra de la tienda. Desinstalar la Aplicación no cancela por sí solo una suscripción de Android.

## 9. Almacenamiento, exportaciones y posible pérdida

Los registros están en el contenedor local privado. La copia de datos está desactivada en Android, y los archivos del registro en iOS se configuran para no incluirse en iCloud o nube del dispositivo. El almacenamiento transaccional y la recuperación local reducen riesgos, pero no garantizan recuperación después de desinstalación, borrado, pérdida, falla o acción del sistema.

Excel y PDF se crean en el dispositivo y pueden contener información privada. El destino controla la copia guardada o compartida. El Proveedor no puede recuperarla ni borrarla. Exportar no crea una copia importable.

Usa **Configuración → Eliminar datos del registro** para borrar registros y recuperación local. Esto no borra archivos exportados, datos publicitarios de terceros ni información de Apple, Google, correo o destinos.

## 10. No es asesoría profesional u oficial

La Aplicación es una ayuda manual para el hogar. No es asesoría financiera, legal, contributiva, nutricional, social, de beneficios ni profesional. Los informes se basan solamente en entradas guardadas y no son estados, recibos o decisiones oficiales.

Para balance, transacción, regla de alimentos, tarjeta perdida, fraude, compra denegada o decisión oficial, contacta la agencia, servicio de tarjeta, comercio o recurso de USDA aplicable.

## 11. Privacidad

La [Política de privacidad](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html) explica almacenamiento, Google Mobile Ads y UMP, comunicaciones con el equipo de ayuda, exportaciones, conservación, eliminación, uso adulto, procesamiento internacional y opciones. Al usar la Aplicación reconoces esas prácticas. Los consentimientos publicitarios se manejan mediante el proceso aplicable.

## 12. Servicios de terceros

La Aplicación depende en parte de software y servicios de Apple o Google, Google Mobile Ads y UMP, funciones del sistema, correo y destinos que eliges. Sus términos aplican. El Proveedor no controla disponibilidad, anuncios, sistemas oficiales, comercios ni destinos.

El Proveedor—no Apple, Google, USDA, ninguna agencia, ningún procesador ni ningún comercio—es responsable de la Aplicación y su Centro de ayuda, salvo donde los términos de una tienda dispongan otra cosa. Apple y Google no tienen obligación de mantenimiento ni soporte fuera de sus propias obligaciones.

Consulta [Avisos de terceros](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/third-party-notices.html).

## 13. Propiedad y marcas

El Proveedor y sus licenciantes poseen el software, diseño, texto, gráficos y material original, excepto tus entradas y material de terceros. Estos Términos no transfieren propiedad. El software de código abierto sigue sus licencias.

Los nombres y marcas de terceros, incluidos SNAP, EBT, PAN, NAP, USDA, Apple, Google y Excel, se mencionan únicamente con fines descriptivos y permanecen como propiedad de sus respectivos titulares, cuando corresponda. Su mención no implica respaldo.

## 14. Disponibilidad, actualizaciones y cambios

Buscamos mantener la Aplicación útil, segura y compatible, pero no prometemos disponibilidad continua, disponibilidad de anuncios, compatibilidad con todo dispositivo o destino, permanencia de funciones ni aceptación de todo archivo.

Podemos actualizar para corregir, mejorar seguridad o accesibilidad, mantener compatibilidad o responder a ley o tiendas. Apple y Google controlan aceptación y permanencia en sus tiendas.

## 15. Exclusión de garantías

Hasta donde la ley permita, la Aplicación se ofrece **“tal cual” y “según disponibilidad.”** El Proveedor excluye garantías implícitas de comerciabilidad, idoneidad, no infracción, exactitud y operación continua o sin errores.

Esto no excluye derechos o remedios que la ley del consumidor no permita excluir.

## 16. Límite de responsabilidad

Hasta donde la ley permita, el Proveedor no responde por daños indirectos, incidentales, especiales, consecuentes, ejemplares o punitivos, ni por pérdida de datos o beneficios, transacciones denegadas, demoras, vergüenza, pérdida del dispositivo u oportunidades, ni por confiar en entradas, clasificaciones, balances, informes, anuncios, decisiones de comercios, cambios de programas o servicios no disponibles.

Cuando la responsabilidad no pueda excluirse, se limita solo hasta donde la ley permita. Nada limita responsabilidad por fraude, conducta intencional, negligencia grave, lesión causada por negligencia o derechos que no puedan limitarse.

## 17. Fin del uso o distribución

Puedes dejar de usar en cualquier momento y borrar datos antes de desinstalar. Podemos suspender el Centro de ayuda o la distribución por seguridad, abuso, ley, terceros o tiendas. Terminar la distribución no da acceso a los datos de tu dispositivo.

Las secciones que por su naturaleza deban continuar—propiedad, exclusiones, límites, ley y disputas—siguen vigentes.

## 18. Ley aplicable y disputas

Rigen las leyes de Ontario y las leyes federales aplicables de Canadá, sin reglas sobre conflicto de leyes. Esto **no** elimina protecciones obligatorias federales, estatales, territoriales o locales de una persona consumidora en Estados Unidos.

Antes de una reclamación, se recomienda intentar resolver escribiendo a `lrodeveloperr@gmail.com`. Este paso informal no acorta ningún plazo legal ni implica renunciar a él. Los tribunales de Ontario tienen jurisdicción no exclusiva, sujeto al derecho de acudir a otro foro competente bajo una disposición legal obligatoria.

No se exige arbitraje ni se renuncia a una acción colectiva cuando tal renuncia sea inválida o no esté disponible.

## 19. Términos generales

Si una disposición no puede exigirse, se limita o elimina solo lo mínimo, y las demás continúan. El hecho de no exigir el cumplimiento de una disposición no implica renunciar a ella. No puedes ceder sin consentimiento. El Proveedor puede ceder como parte de una transferencia legal de la Aplicación o actividad relacionada, sujeto a privacidad y protección del consumidor.

## 20. Cambios a estos Términos

Podemos actualizar por cambios en la Aplicación, anuncios, ley o tiendas. Se mostrará nueva fecha. Los cambios materiales se destacarán cuando sea razonablemente posible. Se pedirá aceptación nueva cuando la ley lo exija; de otro modo, continuar usando después de la fecha significa aceptación.

## 21. Contacto

**Proveedor:** Lateef Razaq-Oyetola  
**Ubicación:** Ontario, Canadá  
**Correo:** `lrodeveloperr@gmail.com`  
**Centro de ayuda:** [Centro de ayuda de SNAP & EBT Grocery Tracker](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html)
