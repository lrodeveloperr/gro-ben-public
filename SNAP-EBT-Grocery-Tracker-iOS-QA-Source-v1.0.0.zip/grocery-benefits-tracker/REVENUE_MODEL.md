# Approved Launch Pricing and Monetization Structure

Updated August 6, 2026. Store pricing and advertising revenue remain subject to store tiers, tax, geography, fill, auction demand, and policy.

## Approved U.S. prices

| Platform | Product | Approved price |
|---|---|---:|
| Android | Monthly ad-free subscription | $0.99/month |
| Android | Annual ad-free subscription | $6.99/year |
| iOS | Remove ads forever, non-consumable | $12.99 once |

The Android annual plan costs about 41% less than twelve monthly payments. The iOS product is a separate one-time purchase; entitlements do not transfer across platforms.

## Free version

Every tracker function remains available in the free version. Paying removes all banner, rewarded, inline, and interstitial ads. If an Android subscription becomes inactive, ads return without deleting or restricting tracker data.

## Implementation controls

- Store prices displayed in production come from Google Play or Apple, never hard-coded labels.
- QA builds show the approved values only inside clearly marked no-charge purchase simulations.
- Google Play product: `ad_free` with base plans `monthly` and `annual`.
- Apple product: `remove_ads_forever`, non-consumable.
- Android supports subscription management and expiry revalidation.
- iOS supports Restore Purchase.
- Live conversion, retention, refund, and forgone-ad-revenue data should be reviewed after launch before any future price change.

## Advertising limits

Google's auction controls creative, price, duration, and fill. The Publisher controls only eligible formats, placements, frequency, and when a request occurs. No revenue or eCPM is guaranteed.
