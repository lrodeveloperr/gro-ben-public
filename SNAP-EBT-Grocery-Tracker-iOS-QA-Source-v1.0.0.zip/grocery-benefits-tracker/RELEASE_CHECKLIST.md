# Release Checklist — Version 1.0.0

## Implemented and locally verified

- [x] Native shared React Native interface with generated Android and iOS projects.
- [x] First-use language, program, and Terms/Privacy agreement.
- [x] English and adversarially reviewed Puerto Rican Spanish.
- [x] Separate SNAP/EBT and Puerto Rico PAN program modes with Tarjeta de la Familia wording.
- [x] Integer-cent accounting, exact-balance handling, corrections, deletion, reversals, copied carts, and undo.
- [x] Transactional SQLite, SHA-256 integrity checks, and five rolling recovery snapshots.
- [x] Android backup disabled and iOS SQLite directory excluded from cloud backup.
- [x] Standard Open XML Excel and U.S.-Letter PDF reports generated on the device.
- [x] UMP before ads, non-personalized requests, Cards-screen banner, 50-minute cache expiry, resume revalidation, load timeouts, and safe offline fallback.
- [x] Android rewarded-report structure and iOS non-blocking report-ad structure.
- [x] Android monthly/annual subscription UI and entitlement handling.
- [x] iOS one-time lifetime purchase and Restore Purchase handling.
- [x] QA builds use official Google test ads and clearly labelled simulated no-charge purchase controls.
- [x] All ads disappear while ad-free access is active.
- [x] Production gate rejects missing/test AdMob IDs and simulated purchases.
- [x] Six updated GitHub Markdown files and regenerated npm dependency notices.
- [x] TypeScript, logic, UI, XLSX, package, native-config, and legal checks pass.
- [x] Android and iOS QA JavaScript bundles export successfully.

## Native QA build and device test

- [ ] Compile the Android QA APK with EAS or an Android SDK-equipped machine.
- [ ] Install on the user's Android phone and exercise the full matrix.
- [ ] Create an iOS simulator/TestFlight QA build with EAS or a Mac.
- [ ] Test offline relaunch, font scaling, TalkBack/VoiceOver, sharing destinations, ad failure/expiry, and simulated purchase/reset flows.
- [ ] Test real sandbox billing later through Google Play internal testing and Apple sandbox/TestFlight; a directly installed APK cannot validate licensed Google Play billing products.

## Store configuration after QA approval

- [ ] Create Google Play subscription product `ad_free` with base plans `monthly` and `annual`.
- [ ] Configure approved U.S. prices: $0.99 monthly and $6.99 annual.
- [ ] Create Apple non-consumable product `remove_ads_forever` at the approved U.S. price of $12.99.
- [ ] Add signing credentials and store accounts.
- [ ] Add production AdMob app/ad-unit IDs only after explicit authorization.
- [ ] Complete Google Data Safety, ads, target audience, content rating, government-affiliation, and billing declarations.
- [ ] Complete Apple App Privacy, age rating, IAP metadata, review notes, and export-compliance declarations.
- [ ] Replace the public GitHub files after testing and verify every rendered URL.
- [ ] Regenerate and compare third-party notices with the final signed AAB and iOS archive.
- [ ] Publish and verify `app-ads.txt` at the final developer domain.
- [ ] Complete Google testing/production access and Apple App Review.
