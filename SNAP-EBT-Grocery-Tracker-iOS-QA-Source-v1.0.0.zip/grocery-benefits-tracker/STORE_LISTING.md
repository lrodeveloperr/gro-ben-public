# Google Play Listing — United States and Puerto Rico

**App:** SNAP & EBT Grocery Tracker  
**Developer profile:** Good Use Studios  
**Legal operator:** Lateef Razaq-Oyetola  
**Category:** Shopping

## Short description

Plan benefit-card groceries privately and avoid checkout surprises.

## Full description

Plan before checkout with a private, manual grocery-benefit tracker designed to reduce balance surprises and awkward split payments.

Choose SNAP/EBT for the states and Washington, D.C., or Puerto Rico's Programa de Asistencia Nutricional (PAN; NAP in English). Add locally named EBT cards or Tarjeta de la Familia records, enter the balance you checked through an official source, record benefits received, and build a cart with exact prices and quantities.

Search and correct purchase history, use your own eligible / not eligible / not sure labels, and create all-time, monthly, or custom Excel and PDF reports. Tracker records remain in app-private local storage. Core tracking and report generation work without internet.

Features:

- Multiple local card records without card numbers or PINs
- Exact-cent tracked balances and controlled corrections
- English and Puerto Rican Spanish
- Puerto Rico program and Tarjeta de la Familia wording
- Searchable purchase and item history
- Copy previous carts, reverse benefit entries, delete records, and undo
- Standard Excel workbooks and U.S.-Letter PDFs generated on the device
- Transactional local storage and rolling recovery snapshots
- No App account, Publisher database, or Publisher cloud backup

The free version contains ads. Google Play offers optional monthly and annual auto-renewing subscriptions that remove all ads. The current price and renewal period are displayed by Google Play before purchase. Cancelling stops future renewals; tracker data and functions remain available if a subscription expires.

SNAP & EBT Grocery Tracker is an independent manual planning tool. It is not affiliated with, endorsed by, authorized by, sponsored by, or operated by USDA, FNA, the Puerto Rico Department of the Family or ADSEF, any government agency, EBT processor, or retailer. It does not connect to a benefit account, add or transfer benefits, show an official balance, determine official eligibility, or process grocery or benefit payments. Official program and retailer records control.

Never enter an EBT card number, Family Card number, PIN, Social Security number, or government-account credential.

Support: lrodeveloperr@gmail.com  
Privacy: https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html  
Terms: https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/terms.html

## Español (Puerto Rico)

**Descripción corta:** Planifica tus compras con beneficios en privado y evita sorpresas al pagar.

Planifica antes de pagar con un registro manual y privado. Escoge SNAP/EBT o el Programa de Asistencia Nutricional (PAN), registra la Tarjeta de la Familia sin escribir su número ni PIN, anota el balance que consultaste en una fuente oficial y crea carritos con precios y cantidades exactas.

Busca y corrige el historial, usa tus propias clasificaciones y crea informes de Excel y PDF en el dispositivo. Los datos del registro permanecen en almacenamiento local privado y las funciones principales trabajan sin internet.

La versión gratis contiene anuncios. Google Play ofrece suscripciones opcionales mensuales y anuales que eliminan todos los anuncios y se renuevan automáticamente hasta que las canceles.

La Aplicación es independiente. No está afiliada, respaldada, autorizada, patrocinada ni operada por USDA, FNA, el Departamento de la Familia o ADSEF, ninguna agencia, ningún procesador EBT ni ningún comercio. No se conecta a cuentas, añade beneficios, muestra balances oficiales, decide elegibilidad ni procesa compras de supermercado o pagos de beneficios.
