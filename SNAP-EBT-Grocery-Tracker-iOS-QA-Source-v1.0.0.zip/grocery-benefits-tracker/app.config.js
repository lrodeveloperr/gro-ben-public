const TEST_ANDROID_APP_ID = "ca-app-pub-3940256099942544~3347511713";
const TEST_IOS_APP_ID = "ca-app-pub-3940256099942544~1458002511";
const GOOGLE_TEST_PUBLISHER = "ca-app-pub-3940256099942544";

const PRODUCTION_KEYS = [
  "EXPO_PUBLIC_ANDROID_ADMOB_APP_ID",
  "EXPO_PUBLIC_IOS_ADMOB_APP_ID",
  "EXPO_PUBLIC_ANDROID_ADMOB_BANNER_ID",
  "EXPO_PUBLIC_IOS_ADMOB_BANNER_ID",
  "EXPO_PUBLIC_ANDROID_ADMOB_REWARDED_ID",
  "EXPO_PUBLIC_ANDROID_ADMOB_INTERSTITIAL_ID",
  "EXPO_PUBLIC_IOS_ADMOB_INTERSTITIAL_ID",
];

module.exports = ({ config }) => {
  const profile = process.env.EXPO_PUBLIC_BUILD_PROFILE || "qa";
  const production = profile === "production";
  if (production) {
    const missing = PRODUCTION_KEYS.filter((key) => !process.env[key]);
    const testIds = PRODUCTION_KEYS.filter((key) =>
      String(process.env[key] || "").startsWith(GOOGLE_TEST_PUBLISHER),
    );
    if (process.env.EXPO_PUBLIC_QA_PURCHASES === "1")
      throw new Error("Production builds cannot enable simulated purchases.");
    if (missing.length || testIds.length) {
      throw new Error(
        `Production AdMob configuration rejected. Missing: ${missing.join(", ") || "none"}. Test IDs: ${testIds.join(", ") || "none"}.`,
      );
    }
  }

  const androidAppId = production
    ? process.env.EXPO_PUBLIC_ANDROID_ADMOB_APP_ID
    : TEST_ANDROID_APP_ID;
  const iosAppId = production
    ? process.env.EXPO_PUBLIC_IOS_ADMOB_APP_ID
    : TEST_IOS_APP_ID;
  const qaSuffix = production ? "" : ".qa";

  return {
    ...config,
    name: production ? config.name : `${config.name} QA`,
    android: {
      ...config.android,
      package: `${config.android.package}${qaSuffix}`,
    },
    ios: {
      ...config.ios,
      bundleIdentifier: `${config.ios.bundleIdentifier}${qaSuffix}`,
    },
    extra: { ...(config.extra || {}), buildProfile: profile },
    plugins: (config.plugins || []).map((plugin) => {
      if (!Array.isArray(plugin) || plugin[0] !== "react-native-google-mobile-ads")
        return plugin;
      return [plugin[0], { ...plugin[1], androidAppId, iosAppId }];
    }),
  };
};
