# Native QA Test Matrix — Version 1.0.0

| Area | Required result |
|---|---|
| First use | Language, program, then legal agreement; accepted flow does not repeat |
| Program | SNAP/EBT and PAN persist independently of English / Español (Puerto Rico) |
| PAN wording | Programa de Asistencia Nutricional, Tarjeta de la Familia, benefits, and balance are used consistently |
| Empty install | No sample card, balance, store, purchase, or grocery record |
| Money | Integer cents; exact balance accepted; invalid or below-zero purchase blocked |
| Cards | Add, select, record benefits, reverse, recolor, and delete; historical card names remain |
| Cart | Store autocomplete, local catalog, learned items, quantity, edit, copy, delete, and undo |
| Classification | Same-name history/report synchronization; tracked card charge remains controlled |
| History | Search/filter, corrections, deletion, third-detail counter, and 30-minute interstitial cap |
| Reports | Android monthly one-ad session; all-time two separately initiated ads; custom Excel/PDF separate |
| iOS reports | Reports and exports remain usable whether ads close, fail, or are unavailable |
| Excel | Valid zipped Open XML workbook, three sheets, Puerto Rican Spanish text, native share |
| PDF | Unicode U.S.-Letter output, native share, private temporary storage, launch cleanup |
| Storage | WAL SQLite, atomic save, integrity checksum, snapshot recovery, restart persistence |
| Deletion | Tracker data and recovery are deleted; language, program, legal acceptance, and entitlement remain |
| Android billing QA | $0.99 monthly and $6.99 annual test cards activate ad-free state with no charge |
| iOS billing QA | $12.99 lifetime test card activates ad-free state; Restore Purchase path is visible |
| Entitlement | Paid state removes banner, rewarded, inline, and interstitial formats |
| Expiry/revocation | Android ads return after inactive subscription; tracker data is untouched |
| Ads | UMP first, non-personalized, dedicated banner, 50-minute stale discard, timeout, offline fallback |
| Ad report | Settings opens a pre-addressed support email without attaching tracker data |
| Privacy | No card-number/PIN fields, no shopping data in ad requests, no Android backup |
| Accessibility | TalkBack/VoiceOver, font scaling, focus order, contrast, touch targets, Android Back |
| Devices | Small/large Android screens, supported iPhone/iOS range, safe areas, rotation policy |
| Legal | All six Markdown files match behavior, purchase model, PAN wording, and operator identity |
