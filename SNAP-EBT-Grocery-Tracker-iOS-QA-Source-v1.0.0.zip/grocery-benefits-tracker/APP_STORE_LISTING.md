# Apple App Store Listing — United States and Puerto Rico

**App:** SNAP & EBT Grocery Tracker  
**Seller:** Lateef Razaq-Oyetola  
**Category:** Shopping  
**Subtitle:** Plan groceries before checkout

## Promotional text

Plan privately, track the balance you recorded, and avoid surprise shortfalls or awkward split payments at checkout.

## Description

SNAP & EBT Grocery Tracker is a private, device-local companion for manually planning grocery-benefit purchases before checkout.

Choose SNAP/EBT for the states and Washington, D.C., or Puerto Rico's Nutrition Assistance Program (NAP; PAN in Spanish). Track locally named EBT cards or Family Card records without entering a card number or PIN. Record benefits received, build carts with quantities, copy an earlier cart, and choose your own eligible / not eligible / not sure classification for each item.

Search purchases and individual items, correct mistakes, reverse a benefit entry, or delete a purchase with clear tracked-balance adjustments. Open all-time, monthly, and custom reports, then share standard Excel workbooks and U.S.-Letter PDFs generated on the device.

Tracker data remains in app-private local storage. Core tracking and reports work without internet. There is no App account, Publisher database, or Publisher cloud backup.

The free version contains ads. An optional one-time, non-consumable **Remove ads forever** purchase removes every ad permanently. It is not a subscription. The App supports Restore Purchase, and the App Store displays the current price before purchase.

SNAP & EBT Grocery Tracker is independent. It is not affiliated with, endorsed by, authorized by, sponsored by, or operated by USDA, FNA, the Puerto Rico Department of the Family or ADSEF, any government agency, EBT processor, or retailer. It does not connect to a benefit account, add or transfer benefits, display an official balance, determine official eligibility, or process grocery or benefit payments. Official program and retailer records control.

Never enter an EBT card number, Family Card number, PIN, Social Security number, or government-account credential.

Support: lrodeveloperr@gmail.com  
Privacy: https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html  
Terms: https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/terms.html

## Keywords

grocery,SNAP,EBT,benefits,balance,cart,budget,shopping,report,tracker

## Puerto Rican Spanish localization

**Subtitle:** Planifica antes de pagar

Planifica en privado, registra el balance que consultaste y evita sorpresas al pagar. Escoge SNAP/EBT o el Programa de Asistencia Nutricional (PAN), registra la Tarjeta de la Familia sin escribir su número ni PIN, guarda carritos y compras, filtra el historial y crea informes de Excel y PDF en el dispositivo.

La versión gratis contiene anuncios. Una compra única no consumible permite **Eliminar anuncios para siempre**. No es una suscripción y se puede restaurar mediante la misma cuenta del App Store.

La Aplicación es independiente y no se conecta a ninguna cuenta ni agencia gubernamental.
