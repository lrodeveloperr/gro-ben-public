# SNAP & EBT Grocery Tracker

Native Expo/React Native app for privately planning grocery-benefit purchases before checkout. Version 1.0.0 supports the 50 U.S. states, Washington, D.C., and Puerto Rico without requiring a card number, PIN, government login, or Publisher account.

## Implemented product

- Separate English and Puerto Rican Spanish language selection.
- Separate program modes for SNAP/EBT and Puerto Rico's Programa de Asistencia Nutricional (PAN; NAP in English).
- Program-specific EBT card and Tarjeta de la Familia labels.
- Multiple locally named cards, exact-cent tracked balances, benefit receipts, reversals, corrections, deletion, and undo.
- Cart, purchase history, learned item classifications, 150 English suggestions, and a Puerto Rico-localized 163-item catalog.
- All-time, monthly, and custom reports.
- Offline, on-device Excel (standard Open XML `.xlsx`) and U.S.-Letter PDF generation with native sharing.
- Transactional SQLite storage, SHA-256 integrity checks, and five rolling local recovery snapshots.
- Android backup disabled and the iOS SQLite directory excluded from device-cloud backup.
- No Publisher login, database, analytics SDK, or tracker-data server.

## Purchases and advertising

The free version uses Google Mobile Ads after UMP privacy handling and requests non-personalized ads.

- Android: optional monthly and annual auto-renewing ad-free subscription base plans.
- iOS: optional one-time, non-consumable **Remove ads forever** purchase.
- Store prices are read from Google Play or Apple; QA builds display the approved test values of $0.99/month, $6.99/year, and $12.99 lifetime.
- QA purchase buttons are explicitly marked **TEST MODE** and never charge money.
- Every ad format is removed while a valid ad-free entitlement is active.
- The Cards-screen banner has a dedicated non-overlapping area.
- Android rewarded-report ads are separately initiated and fail open when an ad cannot load or show.
- iOS report ads never condition access to reports or exports.
- Rewarded and interstitial creatives are discarded after 50 minutes and revalidated on foregrounding.

## Commands

```sh
npm run validate
npm run generate:notices
env __UNSAFE_EXPO_HOME_DIRECTORY=/tmp/snap-expo-home EXPO_PUBLIC_QA_PURCHASES=1 npx expo prebuild --clean --no-install
```

The `preview` EAS profile builds a directly installable Android APK with the QA application ID and official Google test ads. The `production` profile builds an Android App Bundle and disables simulated purchases.

## Production gates

A production configuration refuses to build unless all required live AdMob IDs are supplied and none is a Google test ID:

- `EXPO_PUBLIC_ANDROID_ADMOB_APP_ID`
- `EXPO_PUBLIC_IOS_ADMOB_APP_ID`
- `EXPO_PUBLIC_ANDROID_ADMOB_BANNER_ID`
- `EXPO_PUBLIC_IOS_ADMOB_BANNER_ID`
- `EXPO_PUBLIC_ANDROID_ADMOB_REWARDED_ID`
- `EXPO_PUBLIC_ANDROID_ADMOB_INTERSTITIAL_ID`
- `EXPO_PUBLIC_IOS_ADMOB_INTERSTITIAL_ID`

Production also requires store product configuration, signing credentials, store-console disclosures, physical-device testing, and a final signed-binary dependency audit. No production AdMob identifier or signing secret belongs in this source archive.
