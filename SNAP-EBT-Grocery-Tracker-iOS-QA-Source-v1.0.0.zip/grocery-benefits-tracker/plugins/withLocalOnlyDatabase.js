const { withAppDelegate } = require("@expo/config-plugins");

const CALL = "    excludeTrackerDatabaseFromBackup()";
const METHOD = `

  private func excludeTrackerDatabaseFromBackup() {
    guard let documentsDirectory = FileManager.default.urls(
      for: .documentDirectory,
      in: .userDomainMask
    ).first else { return }
    var sqliteDirectory = documentsDirectory.appendingPathComponent(
      "SQLite",
      isDirectory: true
    )
    try? FileManager.default.createDirectory(
      at: sqliteDirectory,
      withIntermediateDirectories: true
    )
    var resourceValues = URLResourceValues()
    resourceValues.isExcludedFromBackup = true
    try? sqliteDirectory.setResourceValues(resourceValues)
  }
`;

module.exports = function withLocalOnlyDatabase(config) {
  return withAppDelegate(config, (mod) => {
    if (mod.modResults.language !== "swift") {
      throw new Error("Local-only database protection requires a Swift AppDelegate.");
    }
    let contents = mod.modResults.contents;
    if (!contents.includes(CALL)) {
      const returnLine =
        "return super.application(application, didFinishLaunchingWithOptions: launchOptions)";
      if (!contents.includes(returnLine)) {
        throw new Error("Could not find the Expo AppDelegate launch return line.");
      }
      contents = contents.replace(returnLine, `${CALL}\n    ${returnLine}`);
    }
    if (!contents.includes("private func excludeTrackerDatabaseFromBackup")) {
      const reactNativeDelegate = contents.indexOf("\nclass ReactNativeDelegate");
      const appDelegateBrace = contents.lastIndexOf("}", reactNativeDelegate);
      if (reactNativeDelegate < 0 || appDelegateBrace < 0) {
        throw new Error("Could not find the end of the Expo AppDelegate.");
      }
      contents = `${contents.slice(0, appDelegateBrace)}${METHOD}${contents.slice(appDelegateBrace)}`;
    }
    mod.modResults.contents = contents;
    return mod;
  });
};
