import { StatusBar } from "expo-status-bar";
import * as StoreReview from "expo-store-review";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  AppState as NativeAppState,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";

import {
  AdPrivacyButton,
  InlineReportAd,
  WalletBanner,
  initializeAdsAndPrecache,
  revalidateAdsOnForeground,
  showNaturalBreakInterstitial,
  showRewardedReportAd,
} from "./src/ads";
import { useAdFreeEntitlement } from "./src/billing";
import { itemSuggestions } from "./src/catalog";
import {
  AD_CAP_MS,
  CARD_COLORS,
  EMPTY_STATE,
  MAX_CENTS,
  addRecentName,
  cleanName,
  formatCents,
  hasActiveAdPass,
  itemTotalCents,
  nameKey,
  parseCents,
  purchaseBalanceError,
  rememberClassification,
  synchronizeClassification,
  totalsFromItems,
  totalsFromPurchases,
  type AppState,
  type BalanceEntry,
  type BenefitCard,
  type CardColor,
  type Eligibility,
  type GroceryItem,
  type Language,
  type Program,
  type Purchase,
  type UndoSnapshot,
} from "./src/domain";
import { dateLabel, statusLabel, t } from "./src/i18n";
import { RELEASE_METADATA } from "./src/releaseMetadata";
import {
  cleanupTemporaryReports,
  shareExcelReport,
  sharePdfReport,
} from "./src/reporting";
import { deleteAppState, loadAppState, saveAppState } from "./src/storage";

type Tab = "cart" | "purchases" | "wallet" | "settings";
type Sheet =
  | "add-card"
  | "add-item"
  | "benefits"
  | "color"
  | "purchase-detail"
  | "item-detail"
  | "correction"
  | "reports"
  | "report-view"
  | "custom-report"
  | "success"
  | null;
type HistoryView = "purchases" | "items";
type ReportMode = "all-time" | "monthly" | "custom";
type ItemRecord = { purchase: Purchase; item: GroceryItem };

const palette = {
  canvas: "#F5F8F6",
  white: "#FFFFFF",
  ink: "#102D2A",
  green: "#0E765D",
  mint: "#DAF3E9",
  line: "#DCE5DF",
  muted: "#6C8079",
  orange: "#E98B55",
  orangeSoft: "#FAE9DF",
  slate: "#718197",
  dark: "#102D2A",
};

function id(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function monthKey(iso: string) {
  const date = new Date(iso);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function monthLabel(language: Language, key: string) {
  const [year = new Date().getFullYear(), month = 1] = key
    .split("-")
    .map(Number);
  return new Intl.DateTimeFormat(language === "es-PR" ? "es-PR" : "en-US", {
    month: "long",
    year: "numeric",
  }).format(new Date(year, month - 1, 1));
}

function programLabel(language: Language, program: Program | null) {
  if (program === "pan-pr")
    return language === "es-PR"
      ? "Programa de Asistencia Nutricional (PAN) — Puerto Rico"
      : "Nutrition Assistance Program (NAP) — Puerto Rico";
  return language === "es-PR" ? "SNAP / EBT" : "SNAP / EBT";
}

function programCardLabel(language: Language, program: Program | null) {
  if (program === "pan-pr")
    return language === "es-PR" ? "Tarjeta de la Familia" : "Family Card";
  return language === "es-PR" ? "Tarjeta EBT" : "EBT card";
}

function countLabel(
  language: Language,
  count: number,
  englishSingular: string,
  englishPlural: string,
  spanishSingular: string,
  spanishPlural: string,
) {
  if (language === "es-PR")
    return count === 1 ? spanishSingular : spanishPlural;
  return count === 1 ? englishSingular : englishPlural;
}

const CARD_COLOR_ES: Record<CardColor, string> = {
  emerald: "Esmeralda",
  ocean: "Océano",
  violet: "Violeta",
  berry: "Baya",
  coral: "Coral",
  sunset: "Atardecer",
  amber: "Ámbar",
  slate: "Pizarra",
  teal: "Verde azulado",
  indigo: "Índigo",
  rose: "Rosa",
  cocoa: "Cacao",
};

function BasketIcon({ size = 25 }: { size?: number }) {
  return (
    <Text accessibilityElementsHidden style={{ fontSize: size }}>
      🧺
    </Text>
  );
}

function CardGlyph({
  card,
  size = "small",
}: {
  card?: Pick<BenefitCard, "name" | "color">;
  size?: "small" | "large";
}) {
  const color = CARD_COLORS[card?.color || "emerald"];
  return (
    <View
      style={[
        styles.cardGlyph,
        { backgroundColor: color.from },
        size === "large" && styles.cardGlyphLarge,
      ]}
    >
      <View style={styles.cardStripe} />
      <View style={styles.cardChip} />
    </View>
  );
}

function StatusBadge({
  language,
  value,
}: {
  language: Language;
  value: Eligibility;
}) {
  const symbol =
    value === "eligible" ? "✓" : value === "not-eligible" ? "×" : "?";
  return (
    <View
      style={[
        styles.statusBadge,
        value === "eligible"
          ? styles.statusEligible
          : value === "not-eligible"
            ? styles.statusNotEligible
            : styles.statusUnsure,
      ]}
    >
      <Text style={styles.statusBadgeText}>{symbol}</Text>
    </View>
  );
}

function PrimaryButton({
  label,
  onPress,
  disabled,
  tone = "dark",
}: {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  tone?: "dark" | "green" | "danger" | "soft";
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.primaryButton,
        tone === "green" && styles.primaryGreen,
        tone === "danger" && styles.primaryDanger,
        tone === "soft" && styles.primarySoft,
        disabled && styles.disabled,
        pressed && styles.pressed,
      ]}
    >
      <Text
        style={[
          styles.primaryButtonText,
          tone === "soft" && styles.primarySoftText,
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

function SheetShell({
  visible,
  title,
  onClose,
  children,
}: {
  visible: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <SafeAreaView
        style={styles.sheetSafe}
        edges={["top", "bottom", "left", "right"]}
      >
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <View style={styles.sheetHeader}>
            <Text style={styles.sheetTitle}>{title}</Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close / Cerrar"
              onPress={onClose}
              style={styles.closeButton}
            >
              <Text style={styles.closeButtonText}>×</Text>
            </Pressable>
          </View>
          <ScrollView
            contentContainerStyle={styles.sheetContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {children}
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
}

function LanguageOnboarding({
  onChoose,
}: {
  onChoose: (language: Language) => void;
}) {
  return (
    <SafeAreaView
      style={styles.onboarding}
      edges={["top", "bottom", "left", "right"]}
    >
      <View style={styles.languageArt}>
        <View style={styles.languageBubble}>
          <Text style={styles.languageBubbleText}>EN</Text>
        </View>
        <Text style={styles.languagePlus}>＋</Text>
        <View style={[styles.languageBubble, styles.languageBubbleOrange]}>
          <Text style={styles.languageBubbleText}>ES</Text>
        </View>
      </View>
      <Text style={styles.kicker}>WELCOME · TE DAMOS LA BIENVENIDA</Text>
      <Text style={styles.onboardingTitle}>Choose your language</Text>
      <Text style={styles.onboardingBody}>
        Elige el idioma que prefieres. You can change it later in Settings.
      </Text>
      <Pressable style={styles.languageOption} onPress={() => onChoose("en")}>
        <View style={styles.languageCode}>
          <Text style={styles.languageCodeText}>EN</Text>
        </View>
        <View style={styles.grow}>
          <Text style={styles.optionTitle}>English</Text>
          <Text style={styles.optionNote}>United States</Text>
        </View>
        <Text style={styles.chevron}>›</Text>
      </Pressable>
      <Pressable
        style={styles.languageOption}
        onPress={() => onChoose("es-PR")}
      >
        <View style={[styles.languageCode, styles.languageCodeOrange]}>
          <Text style={styles.languageCodeOrangeText}>ES</Text>
        </View>
        <View style={styles.grow}>
          <Text style={styles.optionTitle}>Español</Text>
          <Text style={styles.optionNote}>Puerto Rico</Text>
        </View>
        <Text style={styles.chevron}>›</Text>
      </Pressable>
    </SafeAreaView>
  );
}

function ProgramOnboarding({
  language,
  onChoose,
  onBack,
}: {
  language: Language;
  onChoose: (program: Program) => void;
  onBack: () => void;
}) {
  return (
    <SafeAreaView
      style={styles.onboarding}
      edges={["top", "bottom", "left", "right"]}
    >
      <View style={styles.termsArt}>
        <Text style={styles.termsCheck}>▣</Text>
      </View>
      <Text style={styles.kicker}>
        {language === "es-PR" ? "ELIGE TU PROGRAMA" : "CHOOSE YOUR PROGRAM"}
      </Text>
      <Text style={styles.onboardingTitle}>
        {language === "es-PR" ? "¿Qué tarjeta registras?" : "Which card do you track?"}
      </Text>
      <Text style={styles.onboardingBody}>
        {language === "es-PR"
          ? "Esto solo cambia las etiquetas del registro. La aplicación no se conecta con ningún programa ni tarjeta oficial."
          : "This only changes tracker labels. The app never connects to an official program or card."}
      </Text>
      <Pressable
        style={styles.languageOption}
        onPress={() => onChoose("snap-ebt")}
      >
        <View style={styles.languageCode}>
          <Text style={styles.languageCodeText}>EBT</Text>
        </View>
        <View style={styles.grow}>
          <Text style={styles.optionTitle}>SNAP / EBT</Text>
          <Text style={styles.optionNote}>
            {language === "es-PR" ? "Estados Unidos" : "United States"}
          </Text>
        </View>
        <Text style={styles.chevron}>›</Text>
      </Pressable>
      <Pressable
        style={styles.languageOption}
        onPress={() => onChoose("pan-pr")}
      >
        <View style={[styles.languageCode, styles.languageCodeOrange]}>
          <Text style={styles.languageCodeOrangeText}>
            {language === "es-PR" ? "PAN" : "NAP"}
          </Text>
        </View>
        <View style={styles.grow}>
          <Text style={styles.optionTitle}>
            {language === "es-PR"
              ? "Programa de Asistencia Nutricional (PAN)"
              : "Nutrition Assistance Program (NAP)"}
          </Text>
          <Text style={styles.optionNote}>
            {language === "es-PR"
              ? "Puerto Rico · Tarjeta de la Familia"
              : "Puerto Rico · Family Card"}
          </Text>
        </View>
        <Text style={styles.chevron}>›</Text>
      </Pressable>
      <Pressable onPress={onBack} style={styles.linkButton}>
        <Text style={styles.linkButtonText}>
          {language === "es-PR" ? "Cambiar idioma" : "Change language"}
        </Text>
      </Pressable>
    </SafeAreaView>
  );
}

function TermsOnboarding({
  language,
  onBack,
  onAgree,
}: {
  language: Language;
  onBack: () => void;
  onAgree: () => void;
}) {
  const [checked, setChecked] = useState(false);
  return (
    <SafeAreaView
      style={styles.onboarding}
      edges={["top", "bottom", "left", "right"]}
    >
      <View style={styles.termsArt}>
        <Text style={styles.termsCheck}>✓</Text>
      </View>
      <Text style={styles.kicker}>
        {t(language, "beforeStart").toLocaleUpperCase()}
      </Text>
      <Text style={styles.onboardingTitle}>{t(language, "choices")}</Text>
      <Text style={styles.onboardingBody}>{t(language, "independence")}</Text>
      <View style={styles.legalRow}>
        <Pressable
          style={styles.legalTile}
          onPress={() => Linking.openURL(RELEASE_METADATA.termsUrl)}
        >
          <Text style={styles.legalGlyph}>§</Text>
          <Text style={styles.legalTileText}>{t(language, "terms")}</Text>
        </Pressable>
        <Pressable
          style={styles.legalTile}
          onPress={() => Linking.openURL(RELEASE_METADATA.privacyPolicyUrl)}
        >
          <Text style={styles.legalGlyph}>◉</Text>
          <Text style={styles.legalTileText}>{t(language, "privacy")}</Text>
        </Pressable>
      </View>
      <Pressable
        accessibilityRole="checkbox"
        accessibilityState={{ checked }}
        onPress={() => setChecked((value) => !value)}
        style={styles.agreement}
      >
        <View style={[styles.checkbox, checked && styles.checkboxOn]}>
          {checked ? <Text style={styles.checkboxText}>✓</Text> : null}
        </View>
        <Text style={styles.agreementText}>{t(language, "agreement")}</Text>
      </Pressable>
      <PrimaryButton
        label={t(language, "agree")}
        disabled={!checked}
        onPress={onAgree}
      />
      <Pressable onPress={onBack} style={styles.linkButton}>
        <Text style={styles.linkButtonText}>
          {language === "es-PR" ? "Cambiar programa" : "Change program"}
        </Text>
      </Pressable>
    </SafeAreaView>
  );
}

function AppContent() {
  const [state, setState] = useState<AppState>(EMPTY_STATE);
  const [hydrated, setHydrated] = useState(false);
  const [tab, setTab] = useState<Tab>("cart");
  const [sheet, setSheet] = useState<Sheet>(null);
  const [undo, setUndo] = useState<UndoSnapshot | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [newCardName, setNewCardName] = useState("");
  const [newCardBalance, setNewCardBalance] = useState("");
  const [targetCardId, setTargetCardId] = useState<string | null>(null);
  const [benefitsAmount, setBenefitsAmount] = useState("");
  const [itemName, setItemName] = useState("");
  const [itemPrice, setItemPrice] = useState("");
  const [itemQuantity, setItemQuantity] = useState(1);
  const [itemStatus, setItemStatus] = useState<Eligibility | "">("");
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [historySearch, setHistorySearch] = useState("");
  const [historyView, setHistoryView] = useState<HistoryView>("purchases");
  const [historyStatus, setHistoryStatus] = useState<Eligibility | "all">(
    "all",
  );
  const [historyCard, setHistoryCard] = useState("all");
  const [selectedPurchase, setSelectedPurchase] = useState<Purchase | null>(
    null,
  );
  const [selectedItem, setSelectedItem] = useState<ItemRecord | null>(null);
  const [purchaseDraft, setPurchaseDraft] = useState<Purchase | null>(null);
  const [reportMode, setReportMode] = useState<ReportMode>("all-time");
  const [reportPurchases, setReportPurchases] = useState<Purchase[]>([]);
  const [selectedMonth, setSelectedMonth] = useState(
    monthKey(new Date().toISOString()),
  );
  const [exportRetry, setExportRetry] = useState<{
    key: string;
    until: number;
  } | null>(null);
  const [pendingRating, setPendingRating] = useState(false);
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");
  const [customSearch, setCustomSearch] = useState("");
  const [customStores, setCustomStores] = useState<string[] | null>(null);
  const [customCards, setCustomCards] = useState<string[] | null>(null);
  const [customItems, setCustomItems] = useState<string[] | null>(null);
  const [customStatuses, setCustomStatuses] = useState<Eligibility[]>([
    "eligible",
    "not-eligible",
    "unsure",
  ]);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const language: Language = state.language || "en";
  const billing = useAdFreeEntitlement(language);
  const activeCard =
    state.cards.find((card) => card.id === state.activeCardId) || null;
  const cartTotals = useMemo(
    () => totalsFromItems(state.draftItems),
    [state.draftItems],
  );
  const allTotals = useMemo(
    () => totalsFromPurchases(state.purchases),
    [state.purchases],
  );
  const allItemRecords = useMemo(
    () =>
      state.purchases.flatMap((purchase) =>
        purchase.items.map((item) => ({ purchase, item })),
      ),
    [state.purchases],
  );
  const uniqueStores = useMemo(
    () => [
      ...new Set(
        [
          ...state.savedStores,
          ...state.purchases.map((purchase) => purchase.store),
        ].filter(Boolean),
      ),
    ],
    [state.purchases, state.savedStores],
  );
  const uniqueItemNames = useMemo(
    () => [...new Set(allItemRecords.map(({ item }) => item.name))].sort(),
    [allItemRecords],
  );
  const months = useMemo(
    () =>
      [
        ...new Set([
          monthKey(new Date().toISOString()),
          ...state.purchases.map((purchase) => monthKey(purchase.completedAt)),
        ]),
      ]
        .sort()
        .reverse(),
    [state.purchases],
  );

  useEffect(() => {
    cleanupTemporaryReports();
    loadAppState()
      .then((saved) => {
        if (saved) setState(saved);
        setHydrated(true);
      })
      .catch(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(
      () =>
        saveAppState(state).catch(() =>
          setMessage(
            language === "es-PR"
              ? "No se pudieron guardar los cambios."
              : "Changes could not be saved.",
          ),
        ),
      150,
    );
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, [hydrated, language, state]);

  useEffect(() => {
    if (
      hydrated &&
      billing.entitlementReady &&
      state.acceptedTermsAt &&
      !billing.isAdFree
    )
      initializeAdsAndPrecache().catch(() => undefined);
  }, [
    billing.entitlementReady,
    billing.isAdFree,
    hydrated,
    state.acceptedTermsAt,
  ]);

  useEffect(() => {
    if (!state.acceptedTermsAt || billing.isAdFree) return;
    const subscription = NativeAppState.addEventListener("change", (status) => {
      if (status === "active") revalidateAdsOnForeground();
    });
    return () => subscription.remove();
  }, [billing.isAdFree, state.acceptedTermsAt]);

  useEffect(() => {
    if (billing.message) setMessage(billing.message.text);
  }, [billing.message]);

  function patchState(patch: Partial<AppState>) {
    setState((current) => ({ ...current, ...patch }));
  }

  function captureUndo(label: string) {
    setUndo({
      label,
      cards: state.cards,
      purchases: state.purchases,
      draftItems: state.draftItems,
      draftStore: state.draftStore,
      balanceEntries: state.balanceEntries,
    });
  }

  function undoLast() {
    if (!undo) return;
    patchState({
      cards: undo.cards,
      purchases: undo.purchases,
      draftItems: undo.draftItems,
      draftStore: undo.draftStore,
      balanceEntries: undo.balanceEntries,
    });
    setUndo(null);
  }

  function resetItemForm() {
    setItemName("");
    setItemPrice("");
    setItemQuantity(1);
    setItemStatus("");
    setEditingItemId(null);
  }

  function openAddItem(item?: GroceryItem) {
    if (item) {
      setEditingItemId(item.id);
      setItemName(item.name);
      setItemPrice((item.priceCents / 100).toFixed(2));
      setItemQuantity(item.quantity);
      setItemStatus(item.eligibility);
    } else resetItemForm();
    setSheet("add-item");
  }

  const suggestions = useMemo(
    () =>
      itemSuggestions(
        language,
        state.recentItemNames,
        state.purchases,
        state.draftItems,
        itemName,
      ),
    [
      itemName,
      language,
      state.draftItems,
      state.purchases,
      state.recentItemNames,
    ],
  );

  function saveItem() {
    const name = cleanName(itemName);
    const priceCents = parseCents(itemPrice);
    if (!name || priceCents === null || priceCents <= 0 || !itemStatus) return;
    if (priceCents * itemQuantity > MAX_CENTS) {
      Alert.alert(
        language === "es-PR"
          ? "Total del artículo demasiado alto"
          : "Amount is too high",
        language === "es-PR"
          ? "El total de un artículo no puede exceder $999,999.99."
          : "An item total cannot exceed $999,999.99.",
      );
      return;
    }
    captureUndo(
      editingItemId
        ? language === "es-PR"
          ? "Artículo corregido"
          : "Item corrected"
        : language === "es-PR"
          ? "Artículo añadido"
          : "Item added",
    );
    const next: GroceryItem = {
      id: editingItemId || id("item"),
      name,
      priceCents,
      quantity: itemQuantity,
      eligibility: itemStatus,
      chargedEligible: itemStatus === "eligible",
    };
    patchState({
      draftItems: editingItemId
        ? state.draftItems.map((item) =>
            item.id === editingItemId ? next : item,
          )
        : [...state.draftItems, next],
      recentItemNames: addRecentName(state.recentItemNames, name),
    });
    resetItemForm();
    setSheet(null);
    setMessage("");
  }

  function addCard() {
    const name = cleanName(newCardName);
    const balanceCents = parseCents(newCardBalance);
    if (
      !name ||
      balanceCents === null ||
      state.cards.some(
        (card) => card.name.toLocaleLowerCase() === name.toLocaleLowerCase(),
      )
    )
      return;
    captureUndo(language === "es-PR" ? "Tarjeta añadida" : "Card added");
    const colors = Object.keys(CARD_COLORS) as CardColor[];
    const card: BenefitCard = {
      id: id("card"),
      name,
      balanceCents,
      color: colors[state.cards.length % colors.length] || "emerald",
      createdAt: new Date().toISOString(),
    };
    patchState({ cards: [...state.cards, card], activeCardId: card.id });
    setNewCardName("");
    setNewCardBalance("");
    setSheet(null);
  }

  function recordBenefits() {
    const amountCents = parseCents(benefitsAmount);
    if (!targetCardId || amountCents === null || amountCents <= 0) return;
    const targetCard = state.cards.find((card) => card.id === targetCardId);
    if (!targetCard || targetCard.balanceCents + amountCents > MAX_CENTS) {
      Alert.alert(
        language === "es-PR" ? "Balance demasiado alto" : "Amount is too high",
        language === "es-PR"
          ? "El balance registrado no puede exceder $999,999.99."
          : "The tracked balance cannot exceed $999,999.99.",
      );
      return;
    }
    captureUndo(
      language === "es-PR" ? "Beneficios registrados" : "Benefits recorded",
    );
    const entry: BalanceEntry = {
      id: id("benefits"),
      cardId: targetCardId,
      amountCents,
      createdAt: new Date().toISOString(),
      reversedAt: null,
    };
    patchState({
      cards: state.cards.map((card) =>
        card.id === targetCardId
          ? { ...card, balanceCents: card.balanceCents + amountCents }
          : card,
      ),
      balanceEntries: [entry, ...state.balanceEntries],
    });
    setBenefitsAmount("");
    setTargetCardId(null);
    setSheet(null);
  }

  function reverseEntry(entry: BalanceEntry) {
    const card = state.cards.find((value) => value.id === entry.cardId);
    if (!card || card.balanceCents < entry.amountCents) {
      Alert.alert(
        t(language, "reverse"),
        language === "es-PR"
          ? "No se puede revertir porque el balance quedaría por debajo de $0.00."
          : "This cannot be reversed because the balance would fall below $0.00.",
      );
      return;
    }
    captureUndo(language === "es-PR" ? "Entrada revertida" : "Entry reversed");
    patchState({
      cards: state.cards.map((value) =>
        value.id === card.id
          ? { ...value, balanceCents: value.balanceCents - entry.amountCents }
          : value,
      ),
      balanceEntries: state.balanceEntries.map((value) =>
        value.id === entry.id
          ? { ...value, reversedAt: new Date().toISOString() }
          : value,
      ),
    });
  }

  function completePurchase() {
    if (!activeCard || state.draftItems.length === 0) return;
    const error = purchaseBalanceError(
      activeCard.balanceCents,
      cartTotals.eligibleCents,
      language,
    );
    if (error) {
      setMessage(error);
      return;
    }
    captureUndo(language === "es-PR" ? "Compra guardada" : "Purchase saved");
    const completedAt = new Date().toISOString();
    const store =
      cleanName(state.draftStore) ||
      (language === "es-PR" ? "Tienda no especificada" : "Store not specified");
    const items = state.draftItems.map((item) => ({
      ...item,
      chargedEligible: item.eligibility === "eligible",
    }));
    const purchase: Purchase = {
      id: id("purchase"),
      store,
      completedAt,
      items,
      cardId: activeCard.id,
      cardName: activeCard.name,
      eligibleCents: cartTotals.eligibleCents,
      notEligibleCents: cartTotals.notEligibleCents,
      unsureCents: cartTotals.unsureCents,
      chargedBenefitCents: cartTotals.eligibleCents,
      balanceBeforeCents: activeCard.balanceCents,
      balanceAfterCents: activeCard.balanceCents - cartTotals.eligibleCents,
      correctedAt: null,
    };
    const shouldRate = state.purchases.length === 2 && !state.ratingPrompted;
    patchState({
      cards: state.cards.map((card) =>
        card.id === activeCard.id
          ? {
              ...card,
              balanceCents: card.balanceCents - cartTotals.eligibleCents,
            }
          : card,
      ),
      purchases: [purchase, ...state.purchases],
      draftItems: [],
      draftStore: "",
      savedStores:
        store.includes("specified") || store.includes("especificada")
          ? state.savedStores
          : [
              store,
              ...state.savedStores.filter(
                (value) =>
                  value.toLocaleLowerCase() !== store.toLocaleLowerCase(),
              ),
            ],
      ratingPrompted: state.ratingPrompted || shouldRate,
    });
    setSelectedPurchase(purchase);
    setPendingRating(shouldRate);
    setSheet("success");
    setMessage("");
  }

  async function closeSuccess(viewHistory: boolean) {
    setSheet(null);
    if (viewHistory) setTab("purchases");
    if (pendingRating) {
      setPendingRating(false);
      setTimeout(async () => {
        if (await StoreReview.hasAction()) await StoreReview.requestReview();
      }, 400);
    }
  }

  function clonePurchase(purchase: Purchase) {
    const apply = () => {
      captureUndo(language === "es-PR" ? "Carrito copiado" : "Cart copied");
      patchState({
        draftStore:
          purchase.store.includes("specified") ||
          purchase.store.includes("especificada")
            ? ""
            : purchase.store,
        draftItems: purchase.items.map((item) => ({
          ...item,
          id: id("clone"),
          chargedEligible: item.eligibility === "eligible",
        })),
      });
      setTab("cart");
      setSheet(null);
    };
    if (state.draftItems.length || state.draftStore)
      Alert.alert(
        t(language, "clone"),
        language === "es-PR"
          ? "Esto reemplazará la tienda y los artículos actuales. Los precios copiados pueden haber cambiado."
          : "This replaces the current store and items. Copied prices may have changed.",
        [
          { text: t(language, "cancel"), style: "cancel" },
          {
            text:
              language === "es-PR"
                ? "Reemplazar y copiar"
                : "Replace and copy",
            onPress: apply,
          },
        ],
      );
    else apply();
  }

  const filteredPurchases = useMemo(() => {
    const query = historySearch.trim().toLocaleLowerCase();
    return state.purchases.filter((purchase) => {
      const queryMatch =
        !query ||
        purchase.store.toLocaleLowerCase().includes(query) ||
        (purchase.cardName || "").toLocaleLowerCase().includes(query) ||
        purchase.items.some((item) =>
          item.name.toLocaleLowerCase().includes(query),
        );
      const statusMatch =
        historyStatus === "all" ||
        purchase.items.some((item) => item.eligibility === historyStatus);
      const cardMatch =
        historyCard === "all" ||
        (historyCard === "none"
          ? !purchase.cardId
          : purchase.cardId === historyCard);
      return queryMatch && statusMatch && cardMatch;
    });
  }, [historyCard, historySearch, historyStatus, state.purchases]);

  const filteredItems = useMemo(
    () =>
      allItemRecords.filter(({ purchase, item }) => {
        const query = historySearch.trim().toLocaleLowerCase();
        return (
          (!query ||
            item.name.toLocaleLowerCase().includes(query) ||
            purchase.store.toLocaleLowerCase().includes(query) ||
            (purchase.cardName || "").toLocaleLowerCase().includes(query)) &&
          (historyStatus === "all" || item.eligibility === historyStatus) &&
          (historyCard === "all" ||
            (historyCard === "none"
              ? !purchase.cardId
              : purchase.cardId === historyCard))
        );
      }),
    [allItemRecords, historyCard, historySearch, historyStatus],
  );

  const visibleTotals = useMemo(
    () =>
      historyView === "purchases"
        ? totalsFromPurchases(filteredPurchases)
        : totalsFromItems(filteredItems.map(({ item }) => item)),
    [filteredItems, filteredPurchases, historyView],
  );

  function openPurchaseDetail(purchase: Purchase) {
    const views = state.historyDetailViews + 1;
    patchState({ historyDetailViews: views });
    setSelectedPurchase(purchase);
    setSelectedItem(null);
    setSheet("purchase-detail");
  }

  function openItemDetail(record: ItemRecord) {
    const views = state.historyDetailViews + 1;
    patchState({ historyDetailViews: views });
    setSelectedItem(record);
    setSelectedPurchase(null);
    setSheet("item-detail");
  }

  async function closeDetail() {
    const shouldShow =
      !billing.isAdFree &&
      state.historyDetailViews > 0 &&
      state.historyDetailViews % 3 === 0 &&
      !hasActiveAdPass(state.lastAdAt);
    setSheet(null);
    setSelectedPurchase(null);
    setSelectedItem(null);
    if (shouldShow)
      setTimeout(async () => {
        const shown = await showNaturalBreakInterstitial();
        if (shown) patchState({ lastAdAt: Date.now() });
      }, 300);
  }

  function changeHistoricalClassification(
    record: ItemRecord,
    eligibility: Eligibility,
  ) {
    captureUndo(
      language === "es-PR"
        ? "Clasificación actualizada"
        : "Classification updated",
    );
    const purchases = synchronizeClassification(
      state.purchases,
      record.item.name,
      eligibility,
    );
    patchState({ purchases });
    const nextPurchase =
      purchases.find((purchase) => purchase.id === record.purchase.id) ||
      record.purchase;
    const nextItem =
      nextPurchase.items.find((item) => item.id === record.item.id) ||
      record.item;
    setSelectedItem({ purchase: nextPurchase, item: nextItem });
    setMessage(t(language, "reportOnly"));
  }

  function saveCorrection() {
    if (!purchaseDraft) return;
    const original = state.purchases.find(
      (purchase) => purchase.id === purchaseDraft.id,
    );
    if (!original) return;
    const reportTotals = totalsFromItems(purchaseDraft.items);
    const newCharged = purchaseDraft.items
      .filter((item) => item.chargedEligible ?? false)
      .reduce((sum, item) => sum + itemTotalCents(item), 0);
    const card = state.cards.find((value) => value.id === original.cardId);
    const nextBalance = card
      ? card.balanceCents + original.chargedBenefitCents - newCharged
      : null;
    if (
      reportTotals.totalCents > MAX_CENTS ||
      newCharged > MAX_CENTS ||
      (nextBalance !== null && nextBalance > MAX_CENTS)
    ) {
      setMessage(
        language === "es-PR"
          ? "La corrección supera el máximo de $999,999.99."
          : "The correction exceeds the $999,999.99 maximum.",
      );
      return;
    }
    if (nextBalance !== null && nextBalance < 0) {
      setMessage(
        language === "es-PR"
          ? "La corrección dejaría el balance por debajo de $0.00."
          : "The correction would put the tracked balance below $0.00.",
      );
      return;
    }
    captureUndo(
      language === "es-PR" ? "Compra corregida" : "Purchase corrected",
    );
    const corrected: Purchase = {
      ...purchaseDraft,
      ...reportTotals,
      chargedBenefitCents: newCharged,
      correctedAt: new Date().toISOString(),
    };
    patchState({
      purchases: state.purchases.map((purchase) =>
        purchase.id === corrected.id ? corrected : purchase,
      ),
      cards:
        nextBalance === null
          ? state.cards
          : state.cards.map((value) =>
              value.id === card?.id
                ? { ...value, balanceCents: nextBalance }
                : value,
            ),
    });
    setSelectedPurchase(corrected);
    setPurchaseDraft(null);
    setMessage("");
    setSheet("purchase-detail");
  }

  function deletePurchase(purchase: Purchase) {
    Alert.alert(
      t(language, "removePurchase"),
      language === "es-PR"
        ? "La compra se eliminará y el cargo registrado se devolverá a la tarjeta si todavía existe."
        : "The purchase will be deleted and its recorded charge restored if the card still exists.",
      [
        { text: t(language, "cancel"), style: "cancel" },
        {
          text: t(language, "delete"),
          style: "destructive",
          onPress: () => {
            const card = state.cards.find(
              (value) => value.id === purchase.cardId,
            );
            if (
              card &&
              card.balanceCents + purchase.chargedBenefitCents > MAX_CENTS
            ) {
              setMessage(
                language === "es-PR"
                  ? "No se puede restaurar el cargo porque el balance superaría $999,999.99."
                  : "The charge cannot be restored because the balance would exceed $999,999.99.",
              );
              return;
            }
            captureUndo(
              language === "es-PR" ? "Compra eliminada" : "Purchase deleted",
            );
            patchState({
              purchases: state.purchases.filter(
                (value) => value.id !== purchase.id,
              ),
              cards: state.cards.map((card) =>
                card.id === purchase.cardId
                  ? {
                      ...card,
                      balanceCents:
                        card.balanceCents + purchase.chargedBenefitCents,
                    }
                  : card,
              ),
            });
            setSheet(null);
            setSelectedPurchase(null);
          },
        },
      ],
    );
  }

  function runWithRewarded(
    action: () => void | Promise<void>,
    options: { requiredAds?: 1 | 2; retryKey?: string } = {},
    progressOverride?: 0 | 1,
  ) {
    if (billing.isAdFree) {
      void action();
      return;
    }
    if (Platform.OS === "ios") {
      void (async () => {
        if (!hasActiveAdPass(state.lastAdAt)) {
          const shown = await showNaturalBreakInterstitial();
          if (shown) patchState({ lastAdAt: Date.now() });
        }
        await action();
      })();
      return;
    }
    if (
      options.retryKey &&
      exportRetry?.key === options.retryKey &&
      exportRetry.until > Date.now()
    ) {
      void action();
      return;
    }
    const requiredAds = options.requiredAds || 1;
    const progress =
      requiredAds === 2
        ? progressOverride ?? state.allTimeAdProgress
        : 0;
    Alert.alert(
      requiredAds === 2
        ? progress === 1
          ? language === "es-PR" ? "1 de 2 completado" : "1 of 2 complete"
          : language === "es-PR" ? "Se requieren 2 anuncios" : "2 ads required"
        : language === "es-PR" ? "Ver un anuncio" : "Watch an ad",
      requiredAds === 2
        ? language === "es-PR"
          ? `Completa ${progress === 1 ? "el segundo" : "el primero"} de dos anuncios recompensados para abrir el informe. Cada anuncio se inicia por separado y puedes elegir “Ahora no”.`
          : `Complete ${progress === 1 ? "the second" : "the first"} of two rewarded ads to open the report. Each ad starts separately, and you may choose Not now.`
        : language === "es-PR"
          ? "Mira un anuncio para abrir este informe o generar este archivo. Puedes elegir “Ahora no”."
          : "Watch an ad to open this report or generate this file. You can choose Not now.",
      [
        { text: t(language, "notNow"), style: "cancel" },
        {
          text: language === "es-PR" ? "Ver anuncio" : "Watch ad",
          onPress: async () => {
            setBusy(true);
            const result = await showRewardedReportAd();
            setBusy(false);
            if (result === "dismissed") return;
            if (result === "earned" && requiredAds === 2 && progress === 0) {
              patchState({ allTimeAdProgress: 1 });
              Alert.alert(
                language === "es-PR" ? "1 de 2 completado" : "1 of 2 complete",
                language === "es-PR"
                  ? "El primer anuncio cuenta. El segundo no comenzará automáticamente."
                  : "The first ad counts. The second will not start automatically.",
                [
                  { text: t(language, "notNow"), style: "cancel" },
                  {
                    text:
                      language === "es-PR"
                        ? "Ver segundo anuncio"
                        : "Watch second ad",
                    onPress: () =>
                      runWithRewarded(action, options, 1),
                  },
                ],
              );
              return;
            }
            if (result === "earned" && requiredAds === 2)
              patchState({ allTimeAdProgress: 0 });
            if (result === "unavailable") {
              Alert.alert(
                language === "es-PR"
                  ? "Anuncio no disponible"
                  : "Ad unavailable",
                t(language, "adUnavailable"),
              );
            }
            await action();
          },
        },
      ],
    );
  }

  function openReport(mode: ReportMode) {
    const values =
      mode === "all-time"
        ? state.purchases
        : mode === "monthly"
          ? state.purchases.filter(
              (purchase) => monthKey(purchase.completedAt) === selectedMonth,
            )
          : customReportPurchases;
    runWithRewarded(
      () => {
        setReportMode(mode);
        setReportPurchases(values);
        setSheet("report-view");
      },
      { requiredAds: mode === "all-time" ? 2 : 1 },
    );
  }

  const customReportPurchases = useMemo(
    () =>
      state.purchases.flatMap((purchase) => {
        const date = purchase.completedAt.slice(0, 10);
        if (customFrom && date < customFrom) return [];
        if (customTo && date > customTo) return [];
        if (customStores !== null && !customStores.includes(purchase.store))
          return [];
        if (
          customCards !== null &&
          !customCards.includes(purchase.cardId || "none")
        )
          return [];
        const items = purchase.items.filter(
          (item) =>
            customStatuses.includes(item.eligibility) &&
            (customItems === null || customItems.includes(item.name)) &&
            (!customSearch ||
              item.name
                .toLocaleLowerCase()
                .includes(customSearch.toLocaleLowerCase()) ||
              purchase.store
                .toLocaleLowerCase()
                .includes(customSearch.toLocaleLowerCase())),
        );
        if (!items.length) return [];
        const totals = totalsFromItems(items);
        return [
          {
            ...purchase,
            items,
            eligibleCents: totals.eligibleCents,
            notEligibleCents: totals.notEligibleCents,
            unsureCents: totals.unsureCents,
          },
        ];
      }),
    [
      customCards,
      customFrom,
      customItems,
      customSearch,
      customStatuses,
      customStores,
      customTo,
      state.purchases,
    ],
  );

  async function exportReport(
    format: "excel" | "pdf",
    purchases: Purchase[],
    mode: ReportMode,
  ) {
    setBusy(true);
    setMessage("");
    const title =
      mode === "all-time"
        ? t(language, "allTime")
        : mode === "monthly"
          ? t(language, "monthly")
          : t(language, "custom");
    const scope =
      mode === "monthly"
        ? monthLabel(language, selectedMonth)
        : mode === "custom"
          ? t(language, "custom")
          : language === "es-PR"
            ? "Todas las compras registradas"
            : "All recorded purchases";
    try {
      if (format === "excel")
        await shareExcelReport({
          purchases,
          language,
          title,
          scope,
          partial: mode === "custom",
        });
      else
        await sharePdfReport({
          purchases,
          language,
          title,
          scope,
          partial: mode === "custom",
        });
      setExportRetry(null);
      if (
        Platform.OS === "ios" &&
        !billing.isAdFree &&
        !hasActiveAdPass(state.lastAdAt)
      ) {
        const shown = await showNaturalBreakInterstitial();
        if (shown) patchState({ lastAdAt: Date.now() });
      }
    } catch {
      setExportRetry({
        key: `${mode}:${format}`,
        until: Date.now() + AD_CAP_MS,
      });
      setMessage(t(language, "exportFailed"));
    } finally {
      setBusy(false);
    }
  }

  function requestCustomExport(format: "excel" | "pdf") {
    if (Platform.OS === "ios" || billing.isAdFree) {
      void exportReport(format, customReportPurchases, "custom");
      return;
    }
    runWithRewarded(
      () => exportReport(format, customReportPurchases, "custom"),
      { retryKey: `custom:${format}` },
    );
  }

  function deleteAllData() {
    Alert.alert(
      t(language, "startOver"),
      language === "es-PR"
        ? "Esto elimina permanentemente tus tarjetas, balances, carritos, compras e historial locales. Conserva el idioma, el programa, las preferencias y las compras sin anuncios. Los archivos que ya compartiste no se eliminan."
        : "This permanently deletes local cards, balances, carts, purchases, and history. It keeps language, program, preferences, and ad-free purchases. Files you already shared are not deleted.",
      [
        { text: t(language, "cancel"), style: "cancel" },
        {
          text: t(language, "delete"),
          style: "destructive",
          onPress: async () => {
            await deleteAppState();
            setState({
              ...EMPTY_STATE,
              language: state.language,
              program: state.program,
              acceptedTermsAt: state.acceptedTermsAt,
              ratingPrompted: state.ratingPrompted,
            });
            setTab("cart");
            setSheet(null);
            setUndo(null);
          },
        },
      ],
    );
  }

  if (!hydrated || !billing.entitlementReady)
    return (
      <SafeAreaView style={styles.loading}>
        <BasketIcon size={48} />
        <Text style={styles.loadingTitle}>SNAP & EBT Grocery Tracker</Text>
      </SafeAreaView>
    );
  if (!state.language)
    return (
      <LanguageOnboarding
        onChoose={(value) => patchState({ language: value })}
      />
    );
  if (!state.program)
    return (
      <ProgramOnboarding
        language={language}
        onChoose={(program) => patchState({ program })}
        onBack={() => patchState({ language: null })}
      />
    );
  if (!state.acceptedTermsAt)
    return (
      <TermsOnboarding
        language={language}
        onBack={() => patchState({ program: null })}
        onAgree={() =>
          patchState({ acceptedTermsAt: new Date().toISOString() })
        }
      />
    );

  const reportTotals = totalsFromPurchases(reportPurchases);
  const cardForBenefits =
    state.cards.find((card) => card.id === targetCardId) || null;
  const filteredStores = uniqueStores
    .filter(
      (store) =>
        !state.draftStore ||
        store
          .toLocaleLowerCase()
          .includes(state.draftStore.toLocaleLowerCase()),
    )
    .slice(0, 4);

  return (
    <SafeAreaView
      style={styles.safe}
      edges={["top", "bottom", "left", "right"]}
    >
      <StatusBar style="dark" />
      <View style={styles.appHeader}>
        <View>
          <Text style={styles.brand}>SNAP & EBT GROCERY TRACKER</Text>
          <Text style={styles.pageTitle}>
            {tab === "cart"
              ? t(language, "currentCart")
              : tab === "purchases"
                ? t(language, "purchases")
                : tab === "wallet"
                  ? t(language, "wallet")
                  : t(language, "settings")}
          </Text>
        </View>
        {tab === "purchases" ? (
          <Pressable
            style={styles.reportButton}
            onPress={() => setSheet("reports")}
          >
            <Text style={styles.reportButtonText}>
              ▥ {t(language, "report")}
            </Text>
          </Pressable>
        ) : null}
      </View>
      {message ? (
        <View style={styles.message}>
          <Text style={styles.messageText}>{message}</Text>
          <Pressable onPress={() => setMessage("")}>
            <Text style={styles.messageClose}>×</Text>
          </Pressable>
        </View>
      ) : null}

      {tab === "cart" ? (
        <ScrollView
          contentContainerStyle={styles.screen}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.sectionLabel}>
            {programCardLabel(language, state.program)}
          </Text>
          {state.cards.length ? (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cardSwitcher}
            >
              {state.cards.map((card) => (
                <Pressable
                  key={card.id}
                  onPress={() => patchState({ activeCardId: card.id })}
                  style={[
                    styles.cardChipButton,
                    card.id === state.activeCardId && styles.cardChipActive,
                  ]}
                >
                  <CardGlyph card={card} />
                  <View>
                    <Text numberOfLines={1} style={styles.cardChipName}>
                      {card.name}
                    </Text>
                    <Text style={styles.cardChipBalance}>
                      {formatCents(card.balanceCents, language)}
                    </Text>
                  </View>
                  {card.id === state.activeCardId ? (
                    <Text style={styles.cardCheck}>✓</Text>
                  ) : null}
                </Pressable>
              ))}
            </ScrollView>
          ) : (
            <Pressable
              onPress={() => setSheet("add-card")}
              style={styles.firstCard}
            >
              <CardGlyph size="large" />
              <View style={styles.grow}>
                <Text style={styles.firstCardTitle}>
                  {language === "es-PR"
                    ? `Añade tu primera ${programCardLabel(language, state.program)}`
                    : `Add your first ${programCardLabel(language, state.program)}`}
                </Text>
              </View>
              <Text style={styles.firstCardAdd}>＋</Text>
            </Pressable>
          )}
          {activeCard ? (
            <View
              style={[
                styles.balanceCard,
                { backgroundColor: CARD_COLORS[activeCard.color].from },
              ]}
            >
              <View style={styles.balanceTop}>
                <Text style={styles.balanceCardName}>{activeCard.name}</Text>
                <Pressable
                  onPress={() => {
                    setTargetCardId(activeCard.id);
                    setBenefitsAmount("");
                    setSheet("benefits");
                  }}
                  style={styles.balanceAction}
                >
                  <Text style={styles.balanceActionText}>
                    {t(language, "recordBenefits")}
                  </Text>
                </Pressable>
              </View>
              <Text style={styles.balanceLabel}>
                {t(language, "trackedBalance").toLocaleUpperCase()}
              </Text>
              <Text style={styles.balanceValue}>
                {formatCents(activeCard.balanceCents, language)}
              </Text>
              <View style={styles.balanceBar}>
                <View
                  style={[
                    styles.balanceBarFill,
                    {
                      width: `${Math.min(100, activeCard.balanceCents ? (cartTotals.eligibleCents / activeCard.balanceCents) * 100 : 0)}%`,
                    },
                  ]}
                />
              </View>
              <View style={styles.balanceFoot}>
                <Text style={styles.balanceFootText}>
                  {t(language, "benefitsUsed")}
                </Text>
                <Text style={styles.balanceFootStrong}>
                  {formatCents(cartTotals.eligibleCents, language)}
                </Text>
              </View>
            </View>
          ) : null}
          <View style={styles.storeBlock}>
            <View style={styles.labelRow}>
              <Text style={styles.fieldLabel}>{t(language, "storeName")}</Text>
              <Text style={styles.optional}>{t(language, "optional")}</Text>
            </View>
            <TextInput
              value={state.draftStore}
              onChangeText={(draftStore) => patchState({ draftStore })}
              placeholder={t(language, "storePlaceholder")}
              placeholderTextColor="#93A29D"
              style={styles.input}
              maxLength={80}
            />
            {state.draftStore && filteredStores.length ? (
              <View style={styles.suggestions}>
                {filteredStores.map((store) => (
                  <Pressable
                    key={store}
                    onPress={() => patchState({ draftStore: store })}
                    style={styles.suggestion}
                  >
                    <Text style={styles.storeDot}>●</Text>
                    <Text style={styles.suggestionText}>{store}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
          </View>
          {activeCard && state.purchases[0] ? (
            <Pressable
              onPress={() => clonePurchase(state.purchases[0]!)}
              style={styles.cloneButton}
            >
              <Text style={styles.cloneGlyph}>↻</Text>
              <View style={styles.grow}>
                <Text style={styles.cloneTitle}>{t(language, "clone")}</Text>
                <Text style={styles.cloneNote}>
                  {language === "es-PR"
                    ? "Reutiliza la tienda y los artículos"
                    : "Reuse its store and groceries"}
                </Text>
              </View>
              <Text style={styles.chevron}>›</Text>
            </Pressable>
          ) : null}
          <View style={styles.statRow}>
            <View style={styles.stat}>
              <View
                style={[styles.statDot, { backgroundColor: palette.green }]}
              />
              <Text style={styles.statLabel}>
                {t(language, "eligible").toLocaleUpperCase()}
              </Text>
              <Text style={styles.statValue}>
                {formatCents(cartTotals.eligibleCents, language)}
              </Text>
            </View>
            <View style={styles.stat}>
              <View
                style={[styles.statDot, { backgroundColor: palette.orange }]}
              />
              <Text style={styles.statLabel}>
                {t(language, "notEligible").toLocaleUpperCase()}
              </Text>
              <Text style={styles.statValue}>
                {formatCents(cartTotals.notEligibleCents, language)}
              </Text>
            </View>
            <View style={styles.stat}>
              <View
                style={[styles.statDot, { backgroundColor: palette.slate }]}
              />
              <Text style={styles.statLabel}>
                {t(language, "unsure").toLocaleUpperCase()}
              </Text>
              <Text style={styles.statValue}>
                {formatCents(cartTotals.unsureCents, language)}
              </Text>
            </View>
          </View>
          <View style={styles.listHeader}>
            <Text style={styles.sectionLabel}>{t(language, "itemCount")}</Text>
            <Text style={styles.listCount}>{cartTotals.itemCount}</Text>
          </View>
          {state.draftItems.length ? (
            state.draftItems.map((item) => (
              <View key={item.id} style={styles.itemRow}>
                <StatusBadge language={language} value={item.eligibility} />
                <Pressable
                  style={styles.grow}
                  onPress={() => openAddItem(item)}
                  accessibilityRole="button"
                  accessibilityLabel={`${item.name}. ${t(language, "correct")}`}
                >
                  <Text style={styles.itemName}>{item.name}</Text>
                  <Text style={styles.itemMeta}>
                    {item.quantity} × {formatCents(item.priceCents, language)} ·{" "}
                    {statusLabel(language, item.eligibility)}
                  </Text>
                </Pressable>
                <Text style={styles.itemTotal}>
                  {formatCents(itemTotalCents(item), language)}
                </Text>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={`${t(language, "delete")} ${item.name}`}
                  onPress={() => {
                    captureUndo(
                      language === "es-PR"
                        ? "Artículo eliminado"
                        : "Item removed",
                    );
                    patchState({
                      draftItems: state.draftItems.filter(
                        (value) => value.id !== item.id,
                      ),
                    });
                  }}
                  style={styles.minusButton}
                >
                  <Text style={styles.minusText}>−</Text>
                </Pressable>
              </View>
            ))
          ) : (
            <View style={styles.empty}>
              <BasketIcon size={47} />
              <Text style={styles.emptyTitle}>{t(language, "emptyCart")}</Text>
              <Text style={styles.emptyNote}>
                {t(language, "emptyCartNote")}
              </Text>
            </View>
          )}
          {state.draftItems.some((item) => item.id.startsWith("clone")) ? (
            <Text style={styles.cloneWarning}>
              {language === "es-PR"
                ? "Los precios copiados pueden haber cambiado. Revisa cada artículo antes de guardar."
                : "Copied prices may have changed. Review each item before saving."}
            </Text>
          ) : null}
          <View style={styles.bottomSpace} />
        </ScrollView>
      ) : null}

      {tab === "purchases" ? (
        <ScrollView
          contentContainerStyle={styles.screen}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.historySummary}>
            <View style={styles.summaryCell}>
              <Text style={styles.historyNumber}>
                {historyView === "purchases"
                  ? filteredPurchases.length
                  : new Set(filteredItems.map(({ purchase }) => purchase.id))
                      .size}
              </Text>
              <Text style={styles.historyLabel}>
                {countLabel(
                  language,
                  historyView === "purchases"
                    ? filteredPurchases.length
                    : new Set(filteredItems.map(({ purchase }) => purchase.id)).size,
                  "PURCHASE",
                  "PURCHASES",
                  "COMPRA",
                  "COMPRAS",
                )}
              </Text>
            </View>
            <View style={styles.summaryCell}>
              <Text style={styles.historyNumber}>
                {formatCents(visibleTotals.eligibleCents, language)}
              </Text>
              <Text style={styles.historyLabel}>
                {t(language, "benefitsUsed").toLocaleUpperCase()}
              </Text>
            </View>
            <View style={styles.summaryCell}>
              <Text style={styles.historyNumber}>
                {visibleTotals.itemCount}
              </Text>
              <Text style={styles.historyLabel}>
                {countLabel(
                  language,
                  visibleTotals.itemCount,
                  "ITEM",
                  "ITEMS",
                  "ARTÍCULO",
                  "ARTÍCULOS",
                )}
              </Text>
            </View>
          </View>
          <View style={styles.searchRow}>
            <Text style={styles.searchGlyph}>⌕</Text>
            <TextInput
              style={styles.searchInput}
              value={historySearch}
              onChangeText={setHistorySearch}
              placeholder={t(language, "search")}
              placeholderTextColor="#8D9B96"
            />
          </View>
          <View style={styles.segment}>
            <Pressable
              onPress={() => setHistoryView("purchases")}
              style={[
                styles.segmentButton,
                historyView === "purchases" && styles.segmentOn,
              ]}
            >
              <Text
                style={[
                  styles.segmentText,
                  historyView === "purchases" && styles.segmentTextOn,
                ]}
              >
                {t(language, "purchases")}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setHistoryView("items")}
              style={[
                styles.segmentButton,
                historyView === "items" && styles.segmentOn,
              ]}
            >
              <Text
                style={[
                  styles.segmentText,
                  historyView === "items" && styles.segmentTextOn,
                ]}
              >
                {t(language, "itemCount")}
              </Text>
            </Pressable>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filterRow}
          >
            {(["all", "eligible", "not-eligible", "unsure"] as const).map(
              (value) => (
                <Pressable
                  key={value}
                  onPress={() => setHistoryStatus(value)}
                  style={[
                    styles.filterChip,
                    historyStatus === value && styles.filterChipOn,
                  ]}
                >
                  <Text
                    style={[
                      styles.filterChipText,
                      historyStatus === value && styles.filterChipTextOn,
                    ]}
                  >
                    {value === "all"
                      ? t(language, "allStatus")
                      : statusLabel(language, value)}
                  </Text>
                </Pressable>
              ),
            )}
            {state.cards.map((card) => (
              <Pressable
                key={card.id}
                onPress={() =>
                  setHistoryCard(historyCard === card.id ? "all" : card.id)
                }
                style={[
                  styles.filterChip,
                  historyCard === card.id && styles.filterChipOn,
                ]}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    historyCard === card.id && styles.filterChipTextOn,
                  ]}
                >
                  {card.name}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
          {historyView === "purchases"
            ? filteredPurchases.map((purchase) => (
                <Pressable
                  key={purchase.id}
                  onPress={() => openPurchaseDetail(purchase)}
                  style={styles.historyCard}
                >
                  <View style={styles.storeBadge}>
                    <Text style={styles.storeBadgeText}>
                      {purchase.store.slice(0, 1).toLocaleUpperCase()}
                    </Text>
                  </View>
                  <View style={styles.grow}>
                    <Text style={styles.historyStore}>{purchase.store}</Text>
                    <Text style={styles.historyMeta}>
                      {dateLabel(language, purchase.completedAt)} ·{" "}
                      {purchase.items.reduce(
                        (sum, item) => sum + item.quantity,
                        0,
                      )}{" "}
                      {t(language, "itemCount").toLocaleLowerCase()}
                    </Text>
                    <Text style={styles.historyCardName}>
                      {purchase.cardName || t(language, "noCard")}
                    </Text>
                  </View>
                  <View>
                    <Text style={styles.historyAmount}>
                      {formatCents(
                        purchase.eligibleCents +
                          purchase.notEligibleCents +
                          purchase.unsureCents,
                        language,
                      )}
                    </Text>
                    <Text style={styles.historyBenefit}>
                      {formatCents(purchase.eligibleCents, language)}
                    </Text>
                  </View>
                  <Text style={styles.chevron}>›</Text>
                </Pressable>
              ))
            : filteredItems.map((record) => (
                <Pressable
                  key={`${record.purchase.id}-${record.item.id}`}
                  onPress={() => openItemDetail(record)}
                  style={styles.historyCard}
                >
                  <StatusBadge
                    language={language}
                    value={record.item.eligibility}
                  />
                  <View style={styles.grow}>
                    <Text style={styles.historyStore}>{record.item.name}</Text>
                    <Text style={styles.historyMeta}>
                      {record.purchase.store} ·{" "}
                      {dateLabel(language, record.purchase.completedAt)}
                    </Text>
                    <Text style={styles.historyCardName}>
                      {record.purchase.cardName || t(language, "noCard")}
                    </Text>
                  </View>
                  <View>
                    <Text style={styles.historyAmount}>
                      {formatCents(itemTotalCents(record.item), language)}
                    </Text>
                    <Text style={styles.historyBenefit}>
                      {record.item.quantity} ×{" "}
                      {formatCents(record.item.priceCents, language)}
                    </Text>
                  </View>
                  <Text style={styles.chevron}>›</Text>
                </Pressable>
              ))}
          {(historyView === "purchases"
            ? filteredPurchases.length
            : filteredItems.length) === 0 ? (
            <View style={styles.empty}>
              <Text style={styles.emptySearch}>⌕</Text>
              <Text style={styles.emptyTitle}>{t(language, "noHistory")}</Text>
            </View>
          ) : null}
          <View style={styles.bottomSpace} />
        </ScrollView>
      ) : null}

      {tab === "wallet" ? (
        <ScrollView
          contentContainerStyle={styles.screen}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.settingsSection}>
            <View style={styles.settingsHeading}>
              <View>
                <Text style={styles.settingsTitle}>
                  {programCardLabel(language, state.program)}
                </Text>
                <Text style={styles.settingsNote}>
                  {language === "es-PR"
                    ? "Añade, selecciona, registra beneficios o elimina tarjetas."
                    : "Add, select, record benefits received, or delete cards."}
                </Text>
              </View>
              {state.cards.length ? (
                <Text style={styles.countBubble}>{state.cards.length}</Text>
              ) : null}
            </View>
            {state.cards.map((card) => (
              <View
                key={card.id}
                style={[
                  styles.settingsCard,
                  card.id === state.activeCardId && styles.settingsCardActive,
                ]}
              >
                <Pressable
                  onPress={() => patchState({ activeCardId: card.id })}
                  style={styles.settingsCardMain}
                >
                  <CardGlyph card={card} />
                  <View style={styles.grow}>
                    <Text style={styles.settingsCardName}>{card.name}</Text>
                    <Text style={styles.settingsCardBalance}>
                      {formatCents(card.balanceCents, language)}
                    </Text>
                  </View>
                  {card.id === state.activeCardId ? (
                    <Text style={styles.cardCheck}>✓</Text>
                  ) : null}
                </Pressable>
                <View style={styles.settingsActions}>
                  <Pressable
                    onPress={() => {
                      setTargetCardId(card.id);
                      setSheet("benefits");
                    }}
                  >
                    <Text style={styles.settingsActionText}>
                      ＋ {t(language, "recordBenefits")}
                    </Text>
                  </Pressable>
                  <Pressable
                    onPress={() => {
                      setTargetCardId(card.id);
                      setSheet("color");
                    }}
                  >
                    <Text style={styles.settingsActionText}>
                      ◉ {t(language, "color")}
                    </Text>
                  </Pressable>
                  <Pressable
                    onPress={() =>
                      Alert.alert(
                        t(language, "delete"),
                        language === "es-PR"
                          ? "Las compras anteriores conservarán el nombre de la tarjeta."
                          : "Past purchases will retain the card name.",
                        [
                          { text: t(language, "cancel"), style: "cancel" },
                          {
                            text: t(language, "delete"),
                            style: "destructive",
                            onPress: () => {
                              captureUndo(
                                language === "es-PR"
                                  ? "Tarjeta eliminada"
                                  : "Card deleted",
                              );
                              const cards = state.cards.filter(
                                (value) => value.id !== card.id,
                              );
                              patchState({
                                cards,
                                activeCardId:
                                  state.activeCardId === card.id
                                    ? cards[0]?.id || null
                                    : state.activeCardId,
                              });
                            },
                          },
                        ],
                      )
                    }
                  >
                    <Text style={styles.deleteText}>
                      {t(language, "delete")}
                    </Text>
                  </Pressable>
                </View>
              </View>
            ))}
            <PrimaryButton
              label={`＋ ${t(language, "addCard")}`}
              tone="soft"
              onPress={() => setSheet("add-card")}
            />
          </View>
          {state.balanceEntries.length ? (
            <View style={styles.settingsSection}>
              <Text style={styles.settingsTitle}>
                {t(language, "activity")}
              </Text>
              {state.balanceEntries.slice(0, 20).map((entry) => {
                const card = state.cards.find(
                  (value) => value.id === entry.cardId,
                );
                return (
                  <View
                    key={entry.id}
                    style={[
                      styles.activityRow,
                      entry.reversedAt && styles.activityReversed,
                    ]}
                  >
                    <View style={styles.grow}>
                      <Text style={styles.activityCard}>
                        {card?.name ||
                          (language === "es-PR"
                            ? "Tarjeta eliminada"
                            : "Deleted card")}
                      </Text>
                      <Text style={styles.activityDate}>
                        {dateLabel(language, entry.createdAt)}
                        {entry.reversedAt
                          ? ` · ${language === "es-PR" ? "Revertida" : "Reversed"}`
                          : ""}
                      </Text>
                    </View>
                    <Text style={styles.activityAmount}>
                      {formatCents(entry.amountCents, language)}
                    </Text>
                    {!entry.reversedAt ? (
                      <Pressable
                        onPress={() => reverseEntry(entry)}
                        style={styles.reverseButton}
                      >
                        <Text style={styles.reverseText}>
                          {t(language, "reverse")}
                        </Text>
                      </Pressable>
                    ) : null}
                  </View>
                );
              })}
            </View>
          ) : null}
          <View style={styles.bottomSpace} />
        </ScrollView>
      ) : null}
      {tab === "wallet" && !billing.isAdFree ? (
        <WalletBanner language={language} />
      ) : null}

      {tab === "settings" ? (
        <ScrollView
          contentContainerStyle={styles.screen}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.settingsSection}>
            <Text style={styles.settingsTitle}>{t(language, "language")}</Text>
            <Text style={styles.settingsNote}>
              {t(language, "languageSaved")}
            </Text>
            <View style={styles.languageSettings}>
              <Pressable
                onPress={() => patchState({ language: "en" })}
                style={[
                  styles.languageSetting,
                  language === "en" && styles.languageSettingOn,
                ]}
              >
                <Text style={styles.languageSettingCode}>EN</Text>
                <Text style={styles.languageSettingText}>English</Text>
                {language === "en" ? (
                  <Text style={styles.cardCheck}>✓</Text>
                ) : null}
              </Pressable>
              <Pressable
                onPress={() => patchState({ language: "es-PR" })}
                style={[
                  styles.languageSetting,
                  language === "es-PR" && styles.languageSettingOn,
                ]}
              >
                <Text style={styles.languageSettingCode}>ES</Text>
                <Text style={styles.languageSettingText}>
                  Español (Puerto Rico)
                </Text>
                {language === "es-PR" ? (
                  <Text style={styles.cardCheck}>✓</Text>
                ) : null}
              </Pressable>
            </View>
          </View>

          <View style={styles.settingsSection}>
            <Text style={styles.settingsTitle}>
              {language === "es-PR" ? "Programa" : "Program"}
            </Text>
            <Text style={styles.settingsNote}>
              {language === "es-PR"
                ? "Cambia únicamente las etiquetas del registro."
                : "This changes tracker labels only."}
            </Text>
            {(["snap-ebt", "pan-pr"] as Program[]).map((program) => (
              <Pressable
                key={program}
                onPress={() => patchState({ program })}
                style={[
                  styles.languageSetting,
                  state.program === program && styles.languageSettingOn,
                ]}
              >
                <Text style={styles.languageSettingCode}>
                  {program === "pan-pr"
                    ? language === "es-PR"
                      ? "PAN"
                      : "NAP"
                    : "EBT"}
                </Text>
                <Text style={styles.languageSettingText}>
                  {programLabel(language, program)}
                </Text>
                {state.program === program ? (
                  <Text style={styles.cardCheck}>✓</Text>
                ) : null}
              </Pressable>
            ))}
          </View>

          <View style={styles.settingsSection}>
            <View style={styles.settingsHeading}>
              <View style={styles.grow}>
                <Text style={styles.settingsTitle}>
                  {language === "es-PR" ? "Versión sin anuncios" : "Ad-free version"}
                </Text>
                <Text style={styles.settingsNote}>
                  {billing.isAdFree
                    ? language === "es-PR"
                      ? "Todos los anuncios están desactivados."
                      : "All ads are turned off."
                    : language === "es-PR"
                      ? "La versión gratis mantiene todas las funciones."
                      : "The free version keeps every feature."}
                </Text>
              </View>
              {billing.qaMode ? (
                <Text style={styles.qaBadge}>
                  {language === "es-PR" ? "PRUEBA" : "TEST"}
                </Text>
              ) : null}
            </View>
            {billing.isAdFree ? (
              <View style={styles.purchaseActive}>
                <Text style={styles.purchaseActiveMark}>✓</Text>
                <View style={styles.grow}>
                  <Text style={styles.purchaseActiveTitle}>
                    {language === "es-PR" ? "Sin anuncios activo" : "Ad-free is active"}
                  </Text>
                  <Text style={styles.settingsNote}>
                    {Platform.OS === "android"
                      ? billing.activePlanId === "annual"
                        ? language === "es-PR" ? "Plan anual" : "Annual plan"
                        : language === "es-PR" ? "Plan mensual" : "Monthly plan"
                      : language === "es-PR" ? "Compra para siempre" : "Lifetime purchase"}
                  </Text>
                </View>
              </View>
            ) : Platform.OS === "android" ? (
              <>
                <Pressable
                  disabled={billing.busy}
                  onPress={() => void billing.buyAndroidPlan("monthly")}
                  style={styles.planCard}
                >
                  <View style={styles.grow}>
                    <Text style={styles.planTitle}>
                      {language === "es-PR" ? "Plan mensual sin anuncios" : "Monthly ad-free plan"}
                    </Text>
                    <Text style={styles.planNote}>
                      {language === "es-PR" ? "Se renueva automáticamente cada mes" : "Automatically renews every month"}
                    </Text>
                  </View>
                  <Text style={styles.planPrice}>
                    {billing.monthlyPrice || (language === "es-PR" ? "No disponible" : "Unavailable")}
                  </Text>
                </Pressable>
                <Pressable
                  disabled={billing.busy}
                  onPress={() => void billing.buyAndroidPlan("annual")}
                  style={[styles.planCard, styles.planCardFeatured]}
                >
                  <View style={styles.grow}>
                    <Text style={styles.planTitle}>
                      {language === "es-PR" ? "Plan anual sin anuncios" : "Annual ad-free plan"}
                    </Text>
                    <Text style={styles.planNote}>
                      {language === "es-PR" ? "Se renueva automáticamente cada año" : "Automatically renews every year"}
                    </Text>
                  </View>
                  <Text style={styles.planPrice}>
                    {billing.annualPrice || (language === "es-PR" ? "No disponible" : "Unavailable")}
                  </Text>
                </Pressable>
                <Text style={styles.purchaseDisclosure}>
                  {language === "es-PR"
                    ? "El pago se cobra a tu cuenta de Google Play. La suscripción se renueva automáticamente hasta que la canceles en Google Play. Si vence, vuelven los anuncios; tus datos y funciones permanecen."
                    : "Payment is charged to your Google Play account. The subscription renews automatically until canceled in Google Play. If it expires, ads return; your data and features remain."}
                </Text>
              </>
            ) : (
              <>
                <Pressable
                  disabled={billing.busy}
                  onPress={() => void billing.buyIosLifetime()}
                  style={[styles.planCard, styles.planCardFeatured]}
                >
                  <View style={styles.grow}>
                    <Text style={styles.planTitle}>
                      {language === "es-PR" ? "Eliminar anuncios para siempre" : "Remove ads forever"}
                    </Text>
                    <Text style={styles.planNote}>
                      {language === "es-PR" ? "Compra única. No es una suscripción." : "One-time purchase. Not a subscription."}
                    </Text>
                  </View>
                  <Text style={styles.planPrice}>
                    {billing.lifetimePrice || (language === "es-PR" ? "No disponible" : "Unavailable")}
                  </Text>
                </Pressable>
                <Text style={styles.purchaseDisclosure}>
                  {language === "es-PR"
                    ? "El pago se cobra a tu cuenta del App Store. La compra se puede restaurar en otros dispositivos Apple que usen la misma cuenta."
                    : "Payment is charged to your App Store account. The purchase can be restored on other Apple devices using the same account."}
                </Text>
              </>
            )}
            <View style={styles.purchaseActions}>
              <Pressable
                disabled={billing.busy}
                onPress={() => void billing.restore()}
                style={styles.purchaseLink}
              >
                <Text style={styles.purchaseLinkText}>
                  {language === "es-PR" ? "Restaurar compra" : "Restore purchase"}
                </Text>
              </Pressable>
              {Platform.OS === "android" && billing.isAdFree && !billing.qaMode ? (
                <Pressable
                  onPress={() => void billing.manageAndroidSubscription()}
                  style={styles.purchaseLink}
                >
                  <Text style={styles.purchaseLinkText}>
                    {language === "es-PR" ? "Administrar o cancelar en Google Play" : "Manage or cancel in Google Play"}
                  </Text>
                </Pressable>
              ) : null}
              {billing.qaMode && billing.isAdFree ? (
                <Pressable
                  onPress={() => void billing.resetQaPurchase()}
                  style={styles.purchaseLink}
                >
                  <Text style={styles.purchaseLinkText}>
                    {language === "es-PR" ? "Restablecer prueba gratis" : "Reset free test state"}
                  </Text>
                </Pressable>
              ) : null}
            </View>
            {billing.qaMode ? (
              <Text style={styles.qaNotice}>
                {language === "es-PR"
                  ? "MODO DE PRUEBA: estos botones simulan la compra. No se hará ningún cobro."
                  : "TEST MODE: these buttons simulate purchase access. No charge will be made."}
              </Text>
            ) : null}
          </View>

          <View style={styles.settingsSection}>
            <Text style={styles.settingsTitle}>{t(language, "legal")}</Text>
            <Pressable
              onPress={() => Linking.openURL(RELEASE_METADATA.privacyPolicyUrl)}
              style={styles.legalSetting}
            >
              <Text style={styles.legalSettingGlyph}>◉</Text>
              <Text style={styles.legalSettingText}>
                {t(language, "privacy")}
              </Text>
              <Text style={styles.chevron}>↗</Text>
            </Pressable>
            <Pressable
              onPress={() => Linking.openURL(RELEASE_METADATA.termsUrl)}
              style={styles.legalSetting}
            >
              <Text style={styles.legalSettingGlyph}>§</Text>
              <Text style={styles.legalSettingText}>
                {t(language, "terms")}
              </Text>
              <Text style={styles.chevron}>↗</Text>
            </Pressable>
            <Pressable
              onPress={() => Linking.openURL(RELEASE_METADATA.supportUrl)}
              style={styles.legalSetting}
            >
              <Text style={styles.legalSettingGlyph}>?</Text>
              <Text style={styles.legalSettingText}>
                {t(language, "support")}
              </Text>
              <Text style={styles.chevron}>↗</Text>
            </Pressable>
            {!billing.isAdFree ? <AdPrivacyButton language={language} /> : null}
            {!billing.isAdFree ? (
              <Pressable
                onPress={() =>
                  void Linking.openURL(
                    `mailto:${RELEASE_METADATA.monitoredSupportEmail}?subject=${encodeURIComponent(
                      language === "es-PR"
                        ? "Informar un anuncio — SNAP & EBT Grocery Tracker"
                        : "Report an ad — SNAP & EBT Grocery Tracker",
                    )}`,
                  )
                }
                style={styles.legalSetting}
              >
                <Text style={styles.legalSettingGlyph}>!</Text>
                <Text style={styles.legalSettingText}>
                  {language === "es-PR" ? "Informar un anuncio" : "Report an ad"}
                </Text>
                <Text style={styles.chevron}>↗</Text>
              </Pressable>
            ) : null}
            <Pressable
              onPress={deleteAllData}
              style={[styles.legalSetting, styles.deleteData]}
            >
              <Text style={[styles.legalSettingGlyph, styles.deleteGlyph]}>
                ×
              </Text>
              <Text style={[styles.legalSettingText, styles.deleteText]}>
                {t(language, "deleteData")}
              </Text>
              <Text style={styles.chevron}>›</Text>
            </Pressable>
          </View>
          <Text style={styles.independenceNote}>
            {t(language, "independence")}
          </Text>
          <View style={styles.bottomSpace} />
        </ScrollView>
      ) : null}

      {tab === "cart" ? (
        <View style={styles.cartActions}>
          <PrimaryButton
            label={`＋ ${t(language, "addItem")}`}
            tone="soft"
            onPress={() => openAddItem()}
          />
          <PrimaryButton
            label={t(language, "savePurchase")}
            disabled={!activeCard || state.draftItems.length === 0 || busy}
            onPress={completePurchase}
          />
        </View>
      ) : null}
      <View style={styles.tabBar}>
        <Pressable onPress={() => setTab("cart")} style={styles.tab}>
          <BasketIcon />
          <Text style={[styles.tabText, tab === "cart" && styles.tabTextOn]}>
            {t(language, "cart")}
          </Text>
        </Pressable>
        <Pressable onPress={() => setTab("purchases")} style={styles.tab}>
          <Text
            style={[styles.tabGlyph, tab === "purchases" && styles.tabTextOn]}
          >
            ◷
          </Text>
          <Text
            style={[styles.tabText, tab === "purchases" && styles.tabTextOn]}
          >
            {t(language, "purchases")}
          </Text>
        </Pressable>
        <Pressable onPress={() => setTab("wallet")} style={styles.tab}>
          <Text
            style={[styles.tabGlyph, tab === "wallet" && styles.tabTextOn]}
          >
            ▰
          </Text>
          <Text
            style={[styles.tabText, tab === "wallet" && styles.tabTextOn]}
          >
            {t(language, "wallet")}
          </Text>
        </Pressable>
        <Pressable onPress={() => setTab("settings")} style={styles.tab}>
          <Text
            style={[styles.tabGlyph, tab === "settings" && styles.tabTextOn]}
          >
            ⚙
          </Text>
          <Text
            style={[styles.tabText, tab === "settings" && styles.tabTextOn]}
          >
            {t(language, "settings")}
          </Text>
        </Pressable>
      </View>
      {undo ? (
        <View style={styles.undoToast}>
          <View style={styles.grow}>
            <Text style={styles.undoLabel}>{undo.label}</Text>
            <Text style={styles.undoNote}>
              {language === "es-PR" ? "Guardado localmente" : "Saved locally"}
            </Text>
          </View>
          <Pressable onPress={undoLast} style={styles.undoButton}>
            <Text style={styles.undoButtonText}>{t(language, "undo")}</Text>
          </Pressable>
          <Pressable onPress={() => setUndo(null)} style={styles.undoClose}>
            <Text style={styles.undoCloseText}>×</Text>
          </Pressable>
        </View>
      ) : null}

      <SheetShell
        visible={sheet === "add-card"}
        title={t(language, "addCard")}
        onClose={() => setSheet(null)}
      >
        <View style={styles.formArt}>
          <CardGlyph size="large" />
        </View>
        <Text style={styles.formLabel}>{t(language, "cardName")}</Text>
        <TextInput
          value={newCardName}
          onChangeText={setNewCardName}
          style={styles.input}
          placeholder={
            language === "es-PR"
              ? "p. ej., Tarjeta del hogar"
              : "e.g. Household card"
          }
          maxLength={40}
        />
        <Text style={styles.formLabel}>{t(language, "currentBalance")}</Text>
        <TextInput
          value={newCardBalance}
          onChangeText={setNewCardBalance}
          style={styles.input}
          placeholder="0.00"
          inputMode="decimal"
        />
        <PrimaryButton
          label={t(language, "addCard")}
          disabled={
            !cleanName(newCardName) || parseCents(newCardBalance) === null
          }
          onPress={addCard}
        />
      </SheetShell>

      <SheetShell
        visible={sheet === "add-item"}
        title={t(language, "addItem")}
        onClose={() => {
          resetItemForm();
          setSheet(null);
        }}
      >
        <Text style={styles.formLabel}>{t(language, "itemName")}</Text>
        <TextInput
          value={itemName}
          onChangeText={(value) => {
            setItemName(value);
            setItemStatus(rememberClassification(state.purchases, value) || "");
          }}
          style={styles.input}
          placeholder={t(language, "itemPlaceholder")}
          maxLength={100}
          autoFocus
        />
        {suggestions.length ? (
          <View style={styles.itemSuggestions}>
            {suggestions.map((option) => (
              <Pressable
                key={`${option.source}-${option.name}`}
                onPress={() => {
                  setItemName(option.name);
                  setItemStatus(
                    rememberClassification(state.purchases, option.name) || "",
                  );
                }}
                style={styles.itemSuggestion}
              >
                <Text style={styles.suggestionText}>{option.name}</Text>
                <Text style={styles.suggestionSource}>
                  {option.source === "recent"
                    ? language === "es-PR"
                      ? "RECIENTE"
                      : "RECENT"
                    : option.source === "history"
                      ? language === "es-PR"
                        ? "HISTORIAL"
                        : "HISTORY"
                      : language === "es-PR"
                        ? "COMÚN"
                        : "COMMON"}
                </Text>
              </Pressable>
            ))}
          </View>
        ) : null}
        <View style={styles.twoColumns}>
          <View style={styles.grow}>
            <Text style={styles.formLabel}>{t(language, "unitPrice")}</Text>
            <TextInput
              value={itemPrice}
              onChangeText={setItemPrice}
              style={styles.input}
              placeholder="0.00"
              inputMode="decimal"
            />
          </View>
          <View style={styles.quantityBlock}>
            <Text style={styles.formLabel}>{t(language, "quantity")}</Text>
            <View style={styles.stepper}>
              <Pressable
                disabled={itemQuantity <= 1}
                onPress={() =>
                  setItemQuantity((value) => Math.max(1, value - 1))
                }
              >
                <Text style={styles.stepperButton}>−</Text>
              </Pressable>
              <Text style={styles.stepperValue}>{itemQuantity}</Text>
              <Pressable
                onPress={() =>
                  setItemQuantity((value) => Math.min(99, value + 1))
                }
              >
                <Text style={styles.stepperButton}>＋</Text>
              </Pressable>
            </View>
          </View>
        </View>
        <Text style={styles.formLabel}>{t(language, "classification")}</Text>
        <View style={styles.statusOptions}>
          {(["eligible", "not-eligible", "unsure"] as Eligibility[]).map(
            (value) => (
              <Pressable
                key={value}
                accessibilityRole="radio"
                accessibilityState={{ selected: itemStatus === value }}
                onPress={() => setItemStatus(value)}
                style={[
                  styles.statusOption,
                  itemStatus === value && styles.statusOptionOn,
                ]}
              >
                <StatusBadge language={language} value={value} />
                <Text style={styles.statusOptionText}>
                  {statusLabel(language, value)}
                </Text>
              </Pressable>
            ),
          )}
        </View>
        <PrimaryButton
          label={
            editingItemId ? t(language, "correct") : t(language, "saveItem")
          }
          disabled={
            !cleanName(itemName) || !parseCents(itemPrice) || !itemStatus
          }
          onPress={saveItem}
        />
      </SheetShell>

      <SheetShell
        visible={sheet === "benefits" && Boolean(cardForBenefits)}
        title={t(language, "recordBenefits")}
        onClose={() => setSheet(null)}
      >
        {cardForBenefits ? (
          <>
            <View style={styles.cardFormHeading}>
              <CardGlyph card={cardForBenefits} size="large" />
              <View>
                <Text style={styles.cardFormName}>{cardForBenefits.name}</Text>
                <Text style={styles.cardFormBalance}>
                  {t(language, "currentBalance")}{" "}
                  {formatCents(cardForBenefits.balanceCents, language)}
                </Text>
              </View>
            </View>
            <Text style={styles.formLabel}>
              {t(language, "amountReceived")}
            </Text>
            <TextInput
              value={benefitsAmount}
              onChangeText={setBenefitsAmount}
              style={styles.input}
              placeholder="0.00"
              inputMode="decimal"
              autoFocus
            />
            <View style={styles.previewBalance}>
              <Text style={styles.previewLabel}>
                {t(language, "updateBalance")}
              </Text>
              <Text style={styles.previewValue}>
                {formatCents(
                  cardForBenefits.balanceCents +
                    (parseCents(benefitsAmount) || 0),
                  language,
                )}
              </Text>
            </View>
            <Text style={styles.clarification}>
              {t(language, "localClarification")}
            </Text>
            <PrimaryButton
              label={t(language, "updateBalance")}
              disabled={!parseCents(benefitsAmount)}
              onPress={recordBenefits}
            />
          </>
        ) : null}
      </SheetShell>

      <SheetShell
        visible={sheet === "color"}
        title={t(language, "color")}
        onClose={() => setSheet(null)}
      >
        <Text style={styles.sheetLead}>
          {language === "es-PR"
            ? "Elige el color que quieres ver en toda la aplicación."
            : "Choose the color you want to see throughout the app."}
        </Text>
        <View style={styles.colorGrid}>
          {(Object.keys(CARD_COLORS) as CardColor[]).map((color) => (
            <Pressable
              key={color}
              onPress={() => {
                patchState({
                  cards: state.cards.map((card) =>
                    card.id === targetCardId ? { ...card, color } : card,
                  ),
                });
                setSheet(null);
              }}
              style={styles.colorOption}
            >
              <View
                style={[
                  styles.colorSwatch,
                  { backgroundColor: CARD_COLORS[color].from },
                ]}
              />
              <Text style={styles.colorName}>
                {language === "es-PR"
                  ? CARD_COLOR_ES[color]
                  : CARD_COLORS[color].label}
              </Text>
            </Pressable>
          ))}
        </View>
      </SheetShell>

      <SheetShell
        visible={sheet === "success"}
        title={t(language, "purchaseSaved")}
        onClose={() => closeSuccess(false)}
      >
        <View style={styles.successArt}>
          <Text style={styles.successMark}>✓</Text>
        </View>
        {selectedPurchase ? (
          <>
            <Text style={styles.successStore}>{selectedPurchase.store}</Text>
            <Text style={styles.successTotal}>
              {formatCents(
                selectedPurchase.eligibleCents +
                  selectedPurchase.notEligibleCents +
                  selectedPurchase.unsureCents,
                language,
              )}
            </Text>
            <Text style={styles.successNote}>
              {language === "es-PR"
                ? "Añadida al historial de compras · Guardada localmente"
                : "Added to Purchase History · Saved locally"}
            </Text>
          </>
        ) : null}
        <PrimaryButton
          label={
            language === "es-PR"
              ? "Ver historial de compras"
              : "View Purchase History"
          }
          onPress={() => closeSuccess(true)}
        />
        <Pressable
          onPress={() => closeSuccess(false)}
          style={styles.linkButton}
        >
          <Text style={styles.linkButtonText}>{t(language, "done")}</Text>
        </Pressable>
      </SheetShell>

      <SheetShell
        visible={sheet === "purchase-detail" && Boolean(selectedPurchase)}
        title={
          language === "es-PR" ? "Detalles de la compra" : "Purchase details"
        }
        onClose={closeDetail}
      >
        {selectedPurchase ? (
          <>
            <View style={styles.detailHero}>
              <View style={styles.storeBadgeLarge}>
                <Text style={styles.storeBadgeLargeText}>
                  {selectedPurchase.store.slice(0, 1)}
                </Text>
              </View>
              <Text style={styles.detailStore}>{selectedPurchase.store}</Text>
              <Text style={styles.detailDate}>
                {dateLabel(language, selectedPurchase.completedAt)}
              </Text>
            </View>
            <View style={styles.detailStats}>
              <View style={styles.detailStatCell}>
                <Text style={styles.detailLabel}>
                  {t(language, "benefitsUsed")}
                </Text>
                <Text style={styles.detailStatValue}>
                  {formatCents(selectedPurchase.eligibleCents, language)}
                </Text>
              </View>
              <View style={styles.detailStatCell}>
                <Text style={styles.detailLabel}>
                  {t(language, "notEligible")}
                </Text>
                <Text style={styles.detailStatValue}>
                  {formatCents(selectedPurchase.notEligibleCents, language)}
                </Text>
              </View>
              <View style={styles.detailStatCell}>
                <Text style={styles.detailLabel}>{t(language, "unsure")}</Text>
                <Text style={styles.detailStatValue}>
                  {formatCents(selectedPurchase.unsureCents, language)}
                </Text>
              </View>
            </View>
            <View style={styles.detailCardLine}>
              <CardGlyph
                card={state.cards.find(
                  (card) => card.id === selectedPurchase.cardId,
                )}
              />
              <View>
                <Text style={styles.detailCardName}>
                  {selectedPurchase.cardName || t(language, "noCard")}
                </Text>
                <Text style={styles.detailCardMeta}>{t(language, "card")}</Text>
              </View>
            </View>
            {selectedPurchase.items.map((item) => (
              <View key={item.id} style={styles.detailItem}>
                <Text style={styles.detailItemName}>
                  {item.quantity} × {item.name}
                </Text>
                <Text style={styles.detailItemValue}>
                  {formatCents(itemTotalCents(item), language)}
                </Text>
              </View>
            ))}
            <View style={styles.detailActions}>
              <PrimaryButton
                label={t(language, "correctPurchase")}
                tone="soft"
                onPress={() => {
                  setPurchaseDraft({
                    ...selectedPurchase,
                    items: selectedPurchase.items.map((item) => ({ ...item })),
                  });
                  setSheet("correction");
                }}
              />
              <PrimaryButton
                label={t(language, "removePurchase")}
                tone="danger"
                onPress={() => deletePurchase(selectedPurchase)}
              />
            </View>
            <PrimaryButton label={t(language, "done")} onPress={closeDetail} />
          </>
        ) : null}
      </SheetShell>

      <SheetShell
        visible={sheet === "item-detail" && Boolean(selectedItem)}
        title={language === "es-PR" ? "Detalles del artículo" : "Item details"}
        onClose={closeDetail}
      >
        {selectedItem ? (
          <>
            <View style={styles.detailHero}>
              <StatusBadge
                language={language}
                value={selectedItem.item.eligibility}
              />
              <Text style={styles.detailStore}>{selectedItem.item.name}</Text>
              <Text style={styles.detailDate}>
                {selectedItem.purchase.store} ·{" "}
                {dateLabel(language, selectedItem.purchase.completedAt)}
              </Text>
            </View>
            <View style={styles.itemDetailGrid}>
              <View>
                <Text style={styles.detailLabel}>
                  {t(language, "quantity")}
                </Text>
                <Text style={styles.detailStatValue}>
                  {selectedItem.item.quantity}
                </Text>
              </View>
              <View>
                <Text style={styles.detailLabel}>
                  {t(language, "unitPrice")}
                </Text>
                <Text style={styles.detailStatValue}>
                  {formatCents(selectedItem.item.priceCents, language)}
                </Text>
              </View>
              <View>
                <Text style={styles.detailLabel}>{t(language, "card")}</Text>
                <Text style={styles.detailStatValue}>
                  {selectedItem.purchase.cardName || t(language, "noCard")}
                </Text>
              </View>
            </View>
            <Text style={styles.formLabel}>
              {t(language, "editClassification")}
            </Text>
            <View style={styles.statusOptions}>
              {(["eligible", "not-eligible", "unsure"] as Eligibility[]).map(
                (value) => (
                  <Pressable
                    key={value}
                    onPress={() =>
                      changeHistoricalClassification(selectedItem, value)
                    }
                    style={[
                      styles.statusOption,
                      selectedItem.item.eligibility === value &&
                        styles.statusOptionOn,
                    ]}
                  >
                    <StatusBadge language={language} value={value} />
                    <Text style={styles.statusOptionText}>
                      {statusLabel(language, value)}
                    </Text>
                  </Pressable>
                ),
              )}
            </View>
            <Text style={styles.clarification}>
              {t(language, "reportOnly")}
            </Text>
            <PrimaryButton label={t(language, "done")} onPress={closeDetail} />
          </>
        ) : null}
      </SheetShell>

      <SheetShell
        visible={sheet === "correction" && Boolean(purchaseDraft)}
        title={t(language, "correctPurchase")}
        onClose={() => {
          setPurchaseDraft(null);
          setSheet("purchase-detail");
        }}
      >
        {purchaseDraft ? (
          <>
            <Text style={styles.formLabel}>{t(language, "storeName")}</Text>
            <TextInput
              style={styles.input}
              value={purchaseDraft.store}
              onChangeText={(store) =>
                setPurchaseDraft({ ...purchaseDraft, store })
              }
            />
            <Text style={styles.clarification}>
              {language === "es-PR"
                ? "Los cambios de precio o cantidad ajustan el balance registrado. Los cambios de clasificación se hacen en los detalles del artículo y solo afectan los informes."
                : "Price or quantity corrections adjust the tracked balance. Classification changes are made in item details and affect reports only."}
            </Text>
            {purchaseDraft.items.map((item) => (
              <View key={item.id} style={styles.correctionRow}>
                <View style={styles.grow}>
                  <Text style={styles.correctionName}>{item.name}</Text>
                  <TextInput
                    style={styles.correctionInput}
                    defaultValue={(item.priceCents / 100).toFixed(2)}
                    inputMode="decimal"
                    onEndEditing={(event) => {
                      const priceCents = parseCents(event.nativeEvent.text);
                      if (priceCents && priceCents > 0)
                        setPurchaseDraft({
                          ...purchaseDraft,
                          items: purchaseDraft.items.map((value) =>
                            value.id === item.id
                              ? { ...value, priceCents }
                              : value,
                          ),
                        });
                    }}
                  />
                </View>
                <View style={styles.stepper}>
                  <Pressable
                    onPress={() =>
                      setPurchaseDraft({
                        ...purchaseDraft,
                        items: purchaseDraft.items.map((value) =>
                          value.id === item.id
                            ? {
                                ...value,
                                quantity: Math.max(1, value.quantity - 1),
                              }
                            : value,
                        ),
                      })
                    }
                  >
                    <Text style={styles.stepperButton}>−</Text>
                  </Pressable>
                  <Text style={styles.stepperValue}>{item.quantity}</Text>
                  <Pressable
                    onPress={() =>
                      setPurchaseDraft({
                        ...purchaseDraft,
                        items: purchaseDraft.items.map((value) =>
                          value.id === item.id
                            ? {
                                ...value,
                                quantity: Math.min(99, value.quantity + 1),
                              }
                            : value,
                        ),
                      })
                    }
                  >
                    <Text style={styles.stepperButton}>＋</Text>
                  </Pressable>
                </View>
              </View>
            ))}
            <PrimaryButton
              label={
                language === "es-PR" ? "Guardar corrección" : "Save correction"
              }
              onPress={saveCorrection}
            />
          </>
        ) : null}
      </SheetShell>

      <SheetShell
        visible={sheet === "reports"}
        title={t(language, "report")}
        onClose={() => setSheet(null)}
      >
        <View style={styles.reportHero}>
          <Text style={styles.reportHeroGlyph}>▥</Text>
          <Text style={styles.reportHeroKicker}>
            {language === "es-PR"
              ? "TU HISTORIAL DE COMPRAS"
              : "YOUR PURCHASE STORY"}
          </Text>
          <Text style={styles.reportHeroTitle}>
            {language === "es-PR"
              ? "Informes que valen la pena ver"
              : "Reports worth opening"}
          </Text>
          <Text style={styles.reportHeroBody}>
            {t(language, "differentiate")}
          </Text>
        </View>
        <Pressable
          onPress={() => openReport("all-time")}
          style={styles.reportOption}
        >
          <Text style={styles.reportOptionGlyph}>↗</Text>
          <View style={styles.grow}>
            <Text style={styles.reportOptionKicker}>
              {language === "es-PR" ? "HISTORIAL COMPLETO" : "FULL HISTORY"}
            </Text>
            <Text style={styles.reportOptionTitle}>
              {t(language, "allTime")}
            </Text>
            <Text style={styles.reportOptionNote}>
              {formatCents(allTotals.eligibleCents, language)} ·{" "}
              {state.purchases.length}{" "}
              {countLabel(
                language,
                state.purchases.length,
                "purchase",
                "purchases",
                "compra",
                "compras",
              )}
            </Text>
          </View>
          <Text style={styles.reportOptionAction}>
            {billing.isAdFree || Platform.OS === "ios"
              ? language === "es-PR"
                ? "Abrir"
                : "Open"
              : state.allTimeAdProgress === 1
                ? language === "es-PR" ? "1 de 2" : "1 of 2"
                : language === "es-PR" ? "2 anuncios" : "2 ads"}
          </Text>
        </Pressable>
        <View style={styles.reportOption}>
          <Text style={styles.reportOptionGlyph}>▦</Text>
          <View style={styles.grow}>
            <Text style={styles.reportOptionKicker}>
              {language === "es-PR" ? "MENSUAL" : "MONTHLY"}
            </Text>
            <Text style={styles.reportOptionTitle}>
              {monthLabel(language, selectedMonth)}
            </Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {months.map((month) => (
                <Pressable
                  key={month}
                  onPress={() => setSelectedMonth(month)}
                  style={[
                    styles.monthChip,
                    selectedMonth === month && styles.monthChipOn,
                  ]}
                >
                  <Text
                    style={[
                      styles.monthChipText,
                      selectedMonth === month && styles.monthChipTextOn,
                    ]}
                  >
                    {monthLabel(language, month)}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
          <Pressable
            onPress={() => openReport("monthly")}
            style={styles.reportMiniButton}
          >
            <Text style={styles.reportMiniButtonText}>
              {billing.isAdFree || Platform.OS === "ios"
                ? language === "es-PR"
                  ? "Abrir"
                  : "Open"
                : t(language, "watchView")}
            </Text>
          </Pressable>
        </View>
        <Pressable
          onPress={() => setSheet("custom-report")}
          style={[styles.reportOption, styles.reportOptionCustom]}
        >
          <Text style={styles.originalStudioGlyph}>⌁</Text>
          <View style={styles.grow}>
            <Text style={styles.reportOptionKicker}>
              {language === "es-PR" ? "CREA EL TUYO" : "BUILD YOUR OWN"}
            </Text>
            <Text style={styles.reportOptionTitle}>
              {t(language, "custom")}
            </Text>
            <Text style={styles.reportOptionNote}>
              {language === "es-PR"
                ? "Elige fechas, tiendas, tarjetas, clasificaciones y artículos"
                : "Pick dates, stores, cards, classifications and items"}
            </Text>
          </View>
          <Text style={styles.chevron}>›</Text>
        </Pressable>
      </SheetShell>

      <SheetShell
        visible={sheet === "report-view"}
        title={
          reportMode === "all-time"
            ? t(language, "allTime")
            : reportMode === "monthly"
              ? t(language, "monthly")
              : t(language, "custom")
        }
        onClose={() => {
          setReportPurchases([]);
          setSheet(null);
        }}
      >
        {reportPurchases.length ? (
          <>
            <View style={styles.reportTotal}>
              <Text style={styles.reportTotalLabel}>
                {t(language, "benefitsUsed").toLocaleUpperCase()}
              </Text>
              <Text style={styles.reportTotalValue}>
                {formatCents(reportTotals.eligibleCents, language)}
              </Text>
              <Text style={styles.reportTotalNote}>
                {reportPurchases.length}{" "}
                {countLabel(
                  language,
                  reportPurchases.length,
                  "purchase",
                  "purchases",
                  "compra",
                  "compras",
                )}
              </Text>
            </View>
            <View style={styles.reportStatRow}>
              <View style={styles.reportStatCell}>
                <Text style={styles.detailLabel}>
                  {t(language, "itemCount")}
                </Text>
                <Text style={styles.reportStatValue}>
                  {reportTotals.itemCount}
                </Text>
              </View>
              <View style={styles.reportStatCell}>
                <Text style={styles.detailLabel}>
                  {t(language, "totalSpent")}
                </Text>
                <Text style={styles.reportStatValue}>
                  {formatCents(reportTotals.totalCents, language)}
                </Text>
              </View>
            </View>
            <View style={styles.chartCard}>
              <Text style={styles.chartTitle}>
                {language === "es-PR"
                  ? "Beneficios por compra"
                  : "Benefits by purchase"}
              </Text>
              <View style={styles.barChart}>
                {reportPurchases
                  .slice(0, 8)
                  .reverse()
                  .map((purchase) => {
                    const max = Math.max(
                      1,
                      ...reportPurchases.map((value) => value.eligibleCents),
                    );
                    return (
                      <View key={purchase.id} style={styles.barSlot}>
                        <View
                          style={[
                            styles.bar,
                            {
                              height: Math.max(
                                5,
                                (100 * purchase.eligibleCents) / max,
                              ),
                            },
                          ]}
                        />
                        <Text numberOfLines={1} style={styles.barLabel}>
                          {purchase.store}
                        </Text>
                      </View>
                    );
                  })}
              </View>
            </View>
            {!billing.isAdFree ? <InlineReportAd language={language} /> : null}
            <Text style={styles.clarification}>
              {t(language, "disclaimer")}
            </Text>
            <Text style={styles.exportWarning}>
              {t(language, "exportWarning")}
            </Text>
            <Text style={styles.unlockedNote}>
              {t(language, "reportUnlocked")}
            </Text>
            <View style={styles.exportButtons}>
              <PrimaryButton
                label={
                  busy
                    ? language === "es-PR"
                      ? "Creando…"
                      : "Creating…"
                    : t(language, "downloadExcel")
                }
                tone="soft"
                disabled={busy}
                onPress={() =>
                  exportReport("excel", reportPurchases, reportMode)
                }
              />
              <PrimaryButton
                label={
                  busy
                    ? language === "es-PR"
                      ? "Creando…"
                      : "Creating…"
                    : t(language, "downloadPdf")
                }
                tone="soft"
                disabled={busy}
                onPress={() => exportReport("pdf", reportPurchases, reportMode)}
              />
            </View>
          </>
        ) : (
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>
              {language === "es-PR"
                ? "No hay compras en este período"
                : "No purchases in this period"}
            </Text>
          </View>
        )}
      </SheetShell>

      <SheetShell
        visible={sheet === "custom-report"}
        title={t(language, "custom")}
        onClose={() => setSheet("reports")}
      >
        <View style={styles.customHero}>
          <Text style={styles.originalStudioGlyph}>⌁</Text>
          <View>
            <Text style={styles.reportOptionKicker}>
              {language === "es-PR" ? "INFORME PERSONALIZADO" : "CUSTOM REPORT"}
            </Text>
            <Text style={styles.customTitle}>
              {language === "es-PR" ? "Hazlo a tu manera" : "Make it yours"}
            </Text>
          </View>
        </View>
        <View style={styles.customStats}>
          <View style={styles.customStatCell}>
            <Text style={styles.customDetailLabel}>
              {t(language, "purchases")}
            </Text>
            <Text style={styles.customStatValue}>
              {customReportPurchases.length}
            </Text>
          </View>
          <View style={styles.customStatCell}>
            <Text style={styles.customDetailLabel}>
              {t(language, "itemCount")}
            </Text>
            <Text style={styles.customStatValue}>
              {totalsFromPurchases(customReportPurchases).itemCount}
            </Text>
          </View>
          <View style={styles.customStatCell}>
            <Text style={styles.customDetailLabel}>
              {t(language, "benefitsUsed")}
            </Text>
            <Text style={styles.customStatValue}>
              {formatCents(
                totalsFromPurchases(customReportPurchases).eligibleCents,
                language,
              )}
            </Text>
          </View>
        </View>
        <Text style={styles.formLabel}>
          {language === "es-PR"
            ? "Buscar dentro del informe"
            : "Search within report"}
        </Text>
        <TextInput
          value={customSearch}
          onChangeText={setCustomSearch}
          style={styles.input}
          placeholder={t(language, "search")}
        />
        <View style={styles.twoColumns}>
          <View style={styles.grow}>
            <Text style={styles.formLabel}>
              {language === "es-PR"
                ? "Desde (AAAA-MM-DD)"
                : "From (YYYY-MM-DD)"}
            </Text>
            <TextInput
              value={customFrom}
              onChangeText={setCustomFrom}
              style={styles.input}
              placeholder="2026-01-01"
            />
          </View>
          <View style={styles.grow}>
            <Text style={styles.formLabel}>
              {language === "es-PR" ? "Hasta (AAAA-MM-DD)" : "To (YYYY-MM-DD)"}
            </Text>
            <TextInput
              value={customTo}
              onChangeText={setCustomTo}
              style={styles.input}
              placeholder="2026-12-31"
            />
          </View>
        </View>
        <Text style={styles.formLabel}>{t(language, "classification")}</Text>
        <View style={styles.wrapChips}>
          {(["eligible", "not-eligible", "unsure"] as Eligibility[]).map(
            (value) => (
              <Pressable
                key={value}
                onPress={() =>
                  setCustomStatuses((current) =>
                    current.includes(value)
                      ? current.filter((item) => item !== value)
                      : [...current, value],
                  )
                }
                style={[
                  styles.filterChip,
                  customStatuses.includes(value) && styles.filterChipOn,
                ]}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    customStatuses.includes(value) && styles.filterChipTextOn,
                  ]}
                >
                  {statusLabel(language, value)}
                </Text>
              </Pressable>
            ),
          )}
        </View>
        <Text style={styles.formLabel}>{t(language, "storeName")}</Text>
        <View style={styles.wrapChips}>
          <Pressable
            onPress={() => setCustomStores(null)}
            style={[
              styles.filterChip,
              customStores === null && styles.filterChipOn,
            ]}
          >
            <Text
              style={[
                styles.filterChipText,
                customStores === null && styles.filterChipTextOn,
              ]}
            >
              {language === "es-PR" ? "Todas" : "All"}
            </Text>
          </Pressable>
          {uniqueStores.map((store) => (
            <Pressable
              key={store}
              onPress={() =>
                setCustomStores((current) =>
                  current === null
                    ? [store]
                    : current.includes(store)
                      ? current.filter((value) => value !== store)
                      : [...current, store],
                )
              }
              style={[
                styles.filterChip,
                customStores?.includes(store) && styles.filterChipOn,
              ]}
            >
              <Text
                style={[
                  styles.filterChipText,
                  customStores?.includes(store) && styles.filterChipTextOn,
                ]}
              >
                {store}
              </Text>
            </Pressable>
          ))}
        </View>
        <Text style={styles.formLabel}>{t(language, "card")}</Text>
        <View style={styles.wrapChips}>
          <Pressable
            onPress={() => setCustomCards(null)}
            style={[
              styles.filterChip,
              customCards === null && styles.filterChipOn,
            ]}
          >
            <Text
              style={[
                styles.filterChipText,
                customCards === null && styles.filterChipTextOn,
              ]}
            >
              {language === "es-PR" ? "Todas" : "All"}
            </Text>
          </Pressable>
          {state.cards.map((card) => (
            <Pressable
              key={card.id}
              onPress={() =>
                setCustomCards((current) =>
                  current === null
                    ? [card.id]
                    : current.includes(card.id)
                      ? current.filter((value) => value !== card.id)
                      : [...current, card.id],
                )
              }
              style={[
                styles.filterChip,
                customCards?.includes(card.id) && styles.filterChipOn,
              ]}
            >
              <Text
                style={[
                  styles.filterChipText,
                  customCards?.includes(card.id) && styles.filterChipTextOn,
                ]}
              >
                {card.name}
              </Text>
            </Pressable>
          ))}
        </View>
        <Text style={styles.formLabel}>{t(language, "itemCount")}</Text>
        <View style={styles.wrapChips}>
          <Pressable
            onPress={() => setCustomItems(null)}
            style={[
              styles.filterChip,
              customItems === null && styles.filterChipOn,
            ]}
          >
            <Text
              style={[
                styles.filterChipText,
                customItems === null && styles.filterChipTextOn,
              ]}
            >
              {language === "es-PR" ? "Todos" : "All"}
            </Text>
          </Pressable>
          {uniqueItemNames
            .filter(
              (name) =>
                !customSearch ||
                name
                  .toLocaleLowerCase()
                  .includes(customSearch.toLocaleLowerCase()),
            )
            .slice(0, 80)
            .map((name) => (
              <Pressable
                key={name}
                onPress={() =>
                  setCustomItems((current) =>
                    current === null
                      ? [name]
                      : current.includes(name)
                        ? current.filter((value) => value !== name)
                        : [...current, name],
                  )
                }
                style={[
                  styles.filterChip,
                  customItems?.includes(name) && styles.filterChipOn,
                ]}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    customItems?.includes(name) && styles.filterChipTextOn,
                  ]}
                >
                  {name}
                </Text>
              </Pressable>
            ))}
        </View>
        <Text style={styles.exportWarning}>{t(language, "exportWarning")}</Text>
        <View style={styles.exportButtons}>
          <PrimaryButton
            label={
              billing.isAdFree ||
              Platform.OS === "ios" ||
              (exportRetry?.key === "custom:excel" &&
                exportRetry.until > Date.now())
                ? t(language, "downloadExcel")
                : `${t(language, "watchGenerate")} Excel`
            }
            tone="soft"
            disabled={busy || !customReportPurchases.length}
            onPress={() => requestCustomExport("excel")}
          />
          <PrimaryButton
            label={
              billing.isAdFree ||
              Platform.OS === "ios" ||
              (exportRetry?.key === "custom:pdf" &&
                exportRetry.until > Date.now())
                ? t(language, "downloadPdf")
                : `${t(language, "watchGenerate")} PDF`
            }
            tone="soft"
            disabled={busy || !customReportPurchases.length}
            onPress={() => requestCustomExport("pdf")}
          />
        </View>
      </SheetShell>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppContent />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  grow: { flex: 1, minWidth: 0 },
  safe: { flex: 1, backgroundColor: palette.canvas },
  screen: { padding: 18, paddingBottom: 150 },
  loading: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.canvas,
    gap: 13,
  },
  loadingTitle: { color: palette.ink, fontSize: 20, fontWeight: "800" },
  onboarding: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 26,
    backgroundColor: palette.canvas,
  },
  languageArt: { flexDirection: "row", alignItems: "center", marginBottom: 28 },
  languageBubble: {
    width: 67,
    height: 67,
    borderRadius: 23,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.green,
    shadowColor: palette.green,
    shadowOpacity: 0.25,
    shadowRadius: 16,
  },
  languageBubbleOrange: { backgroundColor: palette.orange },
  languageBubbleText: { color: "#FFF", fontSize: 20, fontWeight: "900" },
  languagePlus: { marginHorizontal: -2, color: palette.muted, fontSize: 18 },
  kicker: {
    color: palette.green,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.6,
  },
  onboardingTitle: {
    maxWidth: 320,
    marginTop: 9,
    color: palette.ink,
    fontSize: 33,
    lineHeight: 36,
    fontWeight: "900",
    textAlign: "center",
  },
  onboardingBody: {
    maxWidth: 345,
    marginTop: 10,
    marginBottom: 22,
    color: palette.muted,
    fontSize: 14,
    lineHeight: 21,
    textAlign: "center",
  },
  languageOption: {
    width: "100%",
    minHeight: 70,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginTop: 10,
    padding: 13,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 20,
    backgroundColor: palette.white,
  },
  languageCode: {
    width: 43,
    height: 43,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.mint,
  },
  languageCodeText: { color: palette.green, fontWeight: "900" },
  languageCodeOrange: { backgroundColor: palette.orangeSoft },
  languageCodeOrangeText: { color: "#B35A34", fontWeight: "900" },
  optionTitle: { color: palette.ink, fontSize: 15, fontWeight: "800" },
  optionNote: { marginTop: 2, color: palette.muted, fontSize: 11 },
  chevron: { color: "#92A19C", fontSize: 24 },
  termsArt: {
    width: 77,
    height: 77,
    marginBottom: 25,
    borderRadius: 27,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.mint,
  },
  termsCheck: {
    width: 42,
    height: 42,
    paddingTop: 8,
    borderRadius: 21,
    overflow: "hidden",
    backgroundColor: palette.green,
    color: "#FFF",
    fontSize: 20,
    fontWeight: "900",
    textAlign: "center",
  },
  legalRow: { width: "100%", flexDirection: "row", gap: 9, marginVertical: 12 },
  legalTile: {
    flex: 1,
    minHeight: 60,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 11,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    backgroundColor: "#FFF",
  },
  legalGlyph: {
    width: 29,
    height: 29,
    paddingTop: 6,
    borderRadius: 9,
    backgroundColor: palette.mint,
    color: palette.green,
    textAlign: "center",
    fontWeight: "900",
  },
  legalTileText: {
    flex: 1,
    color: palette.ink,
    fontSize: 11,
    fontWeight: "800",
  },
  agreement: {
    width: "100%",
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    marginVertical: 12,
    padding: 13,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    backgroundColor: "#FFF",
  },
  checkbox: {
    width: 22,
    height: 22,
    borderWidth: 2,
    borderColor: "#9EB0A9",
    borderRadius: 7,
    alignItems: "center",
    justifyContent: "center",
  },
  checkboxOn: { borderColor: palette.green, backgroundColor: palette.green },
  checkboxText: { color: "#FFF", fontSize: 12, fontWeight: "900" },
  agreementText: { flex: 1, color: palette.ink, fontSize: 12, lineHeight: 18 },
  primaryButton: {
    minHeight: 50,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
    paddingHorizontal: 15,
    borderRadius: 16,
    backgroundColor: palette.dark,
  },
  primaryGreen: { backgroundColor: palette.green },
  primaryDanger: { backgroundColor: "#A94F31" },
  primarySoft: { backgroundColor: "#E5F1EB" },
  primaryButtonText: { color: "#FFF", fontSize: 13, fontWeight: "900" },
  primarySoftText: { color: palette.green },
  disabled: { opacity: 0.45 },
  pressed: { opacity: 0.72 },
  linkButton: {
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    padding: 8,
  },
  linkButtonText: { color: palette.muted, fontSize: 12, fontWeight: "800" },
  appHeader: {
    minHeight: 72,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 19,
    paddingTop: 4,
    backgroundColor: palette.canvas,
  },
  brand: {
    color: palette.muted,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.1,
  },
  pageTitle: {
    marginTop: 3,
    color: palette.ink,
    fontSize: 28,
    fontWeight: "900",
    letterSpacing: -1,
  },
  reportButton: {
    minHeight: 42,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 13,
    borderRadius: 14,
    backgroundColor: "#E3EFE9",
  },
  reportButtonText: { color: palette.green, fontSize: 12, fontWeight: "900" },
  message: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 18,
    marginBottom: 4,
    padding: 11,
    borderRadius: 13,
    backgroundColor: "#FFF0E8",
  },
  messageText: {
    flex: 1,
    color: "#8F4D2E",
    fontSize: 11,
    lineHeight: 16,
    fontWeight: "700",
  },
  messageClose: { paddingHorizontal: 5, color: "#8F4D2E", fontSize: 20 },
  sectionLabel: {
    marginBottom: 8,
    color: palette.ink,
    fontSize: 13,
    fontWeight: "900",
  },
  cardSwitcher: { gap: 8, paddingBottom: 5 },
  cardChipButton: {
    minWidth: 165,
    minHeight: 55,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    padding: 10,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    backgroundColor: "#FFF",
  },
  cardChipActive: { borderColor: "#7CBCA4", backgroundColor: "#EDF7F2" },
  cardChipName: {
    maxWidth: 92,
    color: palette.ink,
    fontSize: 11,
    fontWeight: "800",
  },
  cardChipBalance: {
    marginTop: 2,
    color: palette.muted,
    fontSize: 10,
    fontWeight: "700",
  },
  cardCheck: { color: palette.green, fontSize: 13, fontWeight: "900" },
  cardGlyph: {
    position: "relative",
    width: 34,
    height: 25,
    overflow: "hidden",
    borderRadius: 7,
  },
  cardGlyphLarge: { width: 49, height: 36, borderRadius: 10 },
  cardStripe: {
    position: "absolute",
    top: 7,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: "#FFFFFF40",
  },
  cardChip: {
    position: "absolute",
    left: 6,
    bottom: 5,
    width: 10,
    height: 5,
    borderRadius: 2,
    backgroundColor: "#FFFFFFA8",
  },
  firstCard: {
    minHeight: 72,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: "#94C8B4",
    borderRadius: 20,
    backgroundColor: "#F1F8F4",
  },
  firstCardTitle: { color: palette.ink, fontSize: 13, fontWeight: "900" },
  firstCardAdd: { color: palette.green, fontSize: 23, fontWeight: "800" },
  balanceCard: { marginTop: 11, padding: 18, borderRadius: 23 },
  balanceTop: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
  },
  balanceCardName: {
    flex: 1,
    color: "#D9F2E9",
    fontSize: 13,
    fontWeight: "800",
  },
  balanceAction: {
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 11,
    backgroundColor: "#FFFFFF24",
  },
  balanceActionText: { color: "#FFF", fontSize: 9, fontWeight: "900" },
  balanceLabel: {
    marginTop: 14,
    color: "#C8EADF",
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 1.2,
  },
  balanceValue: {
    marginTop: 2,
    color: "#FFF",
    fontSize: 36,
    fontWeight: "900",
    letterSpacing: -1.4,
  },
  balanceBar: {
    height: 7,
    marginTop: 12,
    overflow: "hidden",
    borderRadius: 4,
    backgroundColor: "#FFFFFF35",
  },
  balanceBarFill: {
    height: "100%",
    borderRadius: 4,
    backgroundColor: "#C6F3DF",
  },
  balanceFoot: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
  balanceFootText: { color: "#D8F0E7", fontSize: 10 },
  balanceFootStrong: { color: "#FFF", fontSize: 11, fontWeight: "900" },
  storeBlock: { position: "relative", zIndex: 5, marginTop: 14 },
  labelRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  fieldLabel: {
    marginBottom: 6,
    color: palette.ink,
    fontSize: 11,
    fontWeight: "900",
  },
  optional: { color: "#91A09B", fontSize: 10 },
  input: {
    minHeight: 49,
    width: "100%",
    paddingHorizontal: 13,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 14,
    backgroundColor: "#FFF",
    color: palette.ink,
    fontSize: 14,
  },
  suggestions: {
    marginTop: 4,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 14,
    backgroundColor: "#FFF",
  },
  suggestion: {
    minHeight: 45,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    paddingHorizontal: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: palette.line,
  },
  storeDot: { color: palette.green },
  suggestionText: {
    flex: 1,
    color: palette.ink,
    fontSize: 12,
    fontWeight: "700",
  },
  cloneButton: {
    minHeight: 58,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: "#CFE2D9",
    borderRadius: 16,
    backgroundColor: "#F1F8F4",
  },
  cloneGlyph: {
    width: 37,
    height: 37,
    paddingTop: 7,
    borderRadius: 12,
    backgroundColor: palette.mint,
    color: palette.green,
    fontSize: 20,
    textAlign: "center",
  },
  cloneTitle: { color: palette.ink, fontSize: 11, fontWeight: "900" },
  cloneNote: { marginTop: 2, color: palette.muted, fontSize: 9 },
  statRow: { flexDirection: "row", gap: 7, marginTop: 11 },
  stat: {
    flex: 1,
    minHeight: 78,
    padding: 11,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    backgroundColor: "#FFF",
  },
  statDot: { width: 7, height: 7, marginBottom: 6, borderRadius: 3.5 },
  statLabel: {
    minHeight: 19,
    color: palette.muted,
    fontSize: 7,
    lineHeight: 9,
    fontWeight: "900",
  },
  statValue: {
    marginTop: 4,
    color: palette.ink,
    fontSize: 13,
    fontWeight: "900",
  },
  listHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 18,
  },
  listCount: { color: palette.muted, fontSize: 12, fontWeight: "800" },
  itemRow: {
    minHeight: 66,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 7,
    padding: 10,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 17,
    backgroundColor: "#FFF",
  },
  statusBadge: {
    width: 34,
    height: 34,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 11,
  },
  statusEligible: { backgroundColor: palette.mint },
  statusNotEligible: { backgroundColor: palette.orangeSoft },
  statusUnsure: { backgroundColor: "#E8EBF0" },
  statusBadgeText: { color: palette.ink, fontSize: 14, fontWeight: "900" },
  itemName: { color: palette.ink, fontSize: 13, fontWeight: "900" },
  itemMeta: { marginTop: 3, color: palette.muted, fontSize: 9 },
  itemTotal: { color: palette.ink, fontSize: 12, fontWeight: "900" },
  minusButton: {
    width: 32,
    height: 32,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 10,
    backgroundColor: palette.orangeSoft,
  },
  minusText: { color: "#B65B34", fontSize: 19, fontWeight: "900" },
  empty: {
    alignItems: "center",
    justifyContent: "center",
    minHeight: 190,
    padding: 30,
  },
  emptyTitle: {
    marginTop: 12,
    color: palette.ink,
    fontSize: 16,
    fontWeight: "900",
    textAlign: "center",
  },
  emptyNote: {
    marginTop: 5,
    color: palette.muted,
    fontSize: 11,
    textAlign: "center",
  },
  emptySearch: { color: palette.green, fontSize: 42 },
  cloneWarning: {
    marginTop: 8,
    padding: 10,
    borderRadius: 12,
    backgroundColor: "#FFF4E8",
    color: "#875A34",
    fontSize: 10,
    lineHeight: 15,
  },
  bottomSpace: { height: 30 },
  cartActions: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 74,
    flexDirection: "row",
    gap: 8,
    paddingTop: 7,
    backgroundColor: `${palette.canvas}F2`,
  },
  tabBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    height: 76,
    flexDirection: "row",
    paddingTop: 7,
    paddingBottom: 11,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: palette.line,
    backgroundColor: "#FFFFFFF2",
  },
  tab: {
    flex: 1,
    minHeight: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  tabGlyph: { color: "#81908B", fontSize: 23 },
  tabText: { marginTop: 1, color: "#81908B", fontSize: 10, fontWeight: "800" },
  tabTextOn: { color: palette.green },
  undoToast: {
    position: "absolute",
    left: 14,
    right: 14,
    bottom: 82,
    minHeight: 58,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 10,
    borderRadius: 17,
    backgroundColor: "#102D2AF5",
    shadowColor: "#000",
    shadowOpacity: 0.25,
    shadowRadius: 12,
  },
  undoLabel: { color: "#FFF", fontSize: 11, fontWeight: "900" },
  undoNote: { marginTop: 2, color: "#BDD8CF", fontSize: 9 },
  undoButton: {
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 9,
    backgroundColor: palette.mint,
  },
  undoButtonText: { color: palette.green, fontSize: 10, fontWeight: "900" },
  undoClose: {
    width: 31,
    height: 31,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 9,
    backgroundColor: "#FFFFFF18",
  },
  undoCloseText: { color: "#FFF", fontSize: 17 },
  historySummary: {
    minHeight: 82,
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 13,
    padding: 10,
    borderRadius: 20,
    backgroundColor: "#E1F1E9",
  },
  summaryCell: { flex: 1, alignItems: "center" },
  historyNumber: {
    color: palette.ink,
    fontSize: 15,
    fontWeight: "900",
    textAlign: "center",
  },
  historyLabel: {
    marginTop: 4,
    color: "#5F786F",
    fontSize: 7,
    fontWeight: "900",
    textAlign: "center",
  },
  searchRow: {
    minHeight: 48,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 15,
    backgroundColor: "#FFF",
  },
  searchGlyph: { color: palette.muted, fontSize: 20 },
  searchInput: {
    flex: 1,
    paddingHorizontal: 9,
    color: palette.ink,
    fontSize: 12,
  },
  segment: {
    flexDirection: "row",
    marginVertical: 10,
    padding: 3,
    borderRadius: 14,
    backgroundColor: "#E9EEEB",
  },
  segmentButton: {
    flex: 1,
    minHeight: 40,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 11,
  },
  segmentOn: { backgroundColor: "#FFF" },
  segmentText: { color: palette.muted, fontSize: 11, fontWeight: "800" },
  segmentTextOn: { color: palette.green },
  filterRow: { gap: 6, paddingBottom: 11 },
  filterChip: {
    minHeight: 38,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 11,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 19,
    backgroundColor: "#FFF",
  },
  filterChipOn: { borderColor: "#82BFA8", backgroundColor: "#E7F4EE" },
  filterChipText: { color: palette.muted, fontSize: 9, fontWeight: "800" },
  filterChipTextOn: { color: palette.green },
  historyCard: {
    minHeight: 75,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginBottom: 8,
    padding: 11,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 18,
    backgroundColor: "#FFF",
  },
  storeBadge: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 13,
    backgroundColor: palette.green,
  },
  storeBadgeText: { color: "#FFF", fontSize: 15, fontWeight: "900" },
  historyStore: { color: palette.ink, fontSize: 12, fontWeight: "900" },
  historyMeta: { marginTop: 3, color: palette.muted, fontSize: 9 },
  historyCardName: {
    alignSelf: "flex-start",
    marginTop: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    backgroundColor: palette.mint,
    color: palette.green,
    fontSize: 8,
    fontWeight: "800",
  },
  historyAmount: {
    color: palette.ink,
    fontSize: 12,
    fontWeight: "900",
    textAlign: "right",
  },
  historyBenefit: {
    marginTop: 3,
    color: palette.green,
    fontSize: 9,
    fontWeight: "700",
    textAlign: "right",
  },
  settingsSection: {
    marginBottom: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 20,
    backgroundColor: "#FFF",
  },
  settingsHeading: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  settingsTitle: { color: palette.ink, fontSize: 13, fontWeight: "900" },
  settingsNote: {
    maxWidth: 280,
    marginTop: 3,
    color: palette.muted,
    fontSize: 9,
    lineHeight: 13,
  },
  countBubble: {
    width: 27,
    height: 27,
    paddingTop: 7,
    borderRadius: 9,
    backgroundColor: palette.mint,
    color: palette.green,
    fontSize: 9,
    fontWeight: "900",
    textAlign: "center",
  },
  settingsCard: {
    overflow: "hidden",
    marginTop: 7,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 16,
    backgroundColor: "#FBFCFA",
  },
  settingsCardActive: { borderColor: "#87BFA9" },
  settingsCardMain: {
    minHeight: 56,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 10,
  },
  settingsCardName: { color: palette.ink, fontSize: 11, fontWeight: "900" },
  settingsCardBalance: { marginTop: 2, color: palette.muted, fontSize: 9 },
  settingsActions: {
    minHeight: 42,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: palette.line,
    backgroundColor: "#F0F7F3",
  },
  settingsActionText: {
    padding: 9,
    color: palette.green,
    fontSize: 8,
    fontWeight: "900",
  },
  deleteText: { color: "#B75F36", fontSize: 8, fontWeight: "900" },
  languageSettings: { flexDirection: "row", gap: 7, marginTop: 10 },
  languageSetting: {
    flex: 1,
    minHeight: 55,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    padding: 9,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 14,
    backgroundColor: "#F8FAF9",
  },
  languageSettingOn: { borderColor: "#7DBBA3", backgroundColor: "#EAF5EF" },
  languageSettingCode: {
    width: 28,
    height: 28,
    paddingTop: 7,
    borderRadius: 8,
    backgroundColor: palette.mint,
    color: palette.green,
    fontSize: 8,
    fontWeight: "900",
    textAlign: "center",
  },
  languageSettingText: {
    flex: 1,
    color: palette.ink,
    fontSize: 9,
    fontWeight: "800",
  },
  qaBadge: {
    overflow: "hidden",
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
    backgroundColor: "#FFF0CC",
    color: "#805C00",
    fontSize: 8,
    fontWeight: "900",
  },
  purchaseActive: {
    minHeight: 62,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: 10,
    padding: 11,
    borderRadius: 14,
    backgroundColor: "#E7F5EE",
  },
  purchaseActiveMark: {
    width: 34,
    height: 34,
    paddingTop: 7,
    borderRadius: 17,
    backgroundColor: palette.green,
    color: "#FFF",
    fontSize: 14,
    fontWeight: "900",
    textAlign: "center",
  },
  purchaseActiveTitle: { color: palette.green, fontSize: 11, fontWeight: "900" },
  planCard: {
    minHeight: 68,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginTop: 9,
    padding: 11,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 15,
    backgroundColor: "#F8FAF9",
  },
  planCardFeatured: { borderColor: "#72B49A", backgroundColor: "#EAF5EF" },
  planTitle: { color: palette.ink, fontSize: 10, fontWeight: "900" },
  planNote: { marginTop: 3, color: palette.muted, fontSize: 8, lineHeight: 11 },
  planPrice: { color: palette.green, fontSize: 12, fontWeight: "900" },
  purchaseDisclosure: {
    marginTop: 10,
    color: palette.muted,
    fontSize: 8,
    lineHeight: 12,
  },
  purchaseActions: { gap: 5, marginTop: 9 },
  purchaseLink: {
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 10,
    borderRadius: 12,
    backgroundColor: "#F0F7F3",
  },
  purchaseLinkText: { color: palette.green, fontSize: 9, fontWeight: "900" },
  qaNotice: {
    marginTop: 9,
    padding: 9,
    borderRadius: 10,
    backgroundColor: "#FFF8E6",
    color: "#725B1B",
    fontSize: 8,
    fontWeight: "700",
    lineHeight: 12,
  },
  activityRow: {
    minHeight: 49,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginTop: 7,
    padding: 9,
    borderRadius: 12,
    backgroundColor: "#F5F8F6",
  },
  activityReversed: { opacity: 0.5 },
  activityCard: { color: palette.ink, fontSize: 9, fontWeight: "800" },
  activityDate: { marginTop: 2, color: palette.muted, fontSize: 8 },
  activityAmount: { color: palette.ink, fontSize: 10, fontWeight: "900" },
  reverseButton: {
    padding: 7,
    borderRadius: 8,
    backgroundColor: palette.orangeSoft,
  },
  reverseText: { color: "#B55C35", fontSize: 8, fontWeight: "900" },
  legalSetting: {
    minHeight: 49,
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginTop: 5,
    padding: 9,
    borderRadius: 12,
    backgroundColor: "#F7F9F8",
  },
  legalSettingGlyph: {
    width: 29,
    height: 29,
    paddingTop: 7,
    borderRadius: 9,
    backgroundColor: palette.mint,
    color: palette.green,
    fontSize: 10,
    fontWeight: "900",
    textAlign: "center",
  },
  legalSettingText: {
    flex: 1,
    color: palette.ink,
    fontSize: 10,
    fontWeight: "800",
  },
  deleteData: { backgroundColor: "#FCF2ED" },
  deleteGlyph: { backgroundColor: palette.orangeSoft, color: "#A85232" },
  independenceNote: {
    padding: 12,
    color: palette.muted,
    fontSize: 9,
    lineHeight: 14,
    textAlign: "center",
  },
  sheetSafe: { flex: 1, backgroundColor: "#FBFCF9" },
  sheetHeader: {
    minHeight: 64,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: palette.line,
  },
  sheetTitle: {
    flex: 1,
    color: palette.ink,
    fontSize: 22,
    fontWeight: "900",
    letterSpacing: -0.6,
  },
  closeButton: {
    width: 42,
    height: 42,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    backgroundColor: "#E9EFEC",
  },
  closeButtonText: { color: palette.ink, fontSize: 25 },
  sheetContent: { padding: 20, paddingBottom: 45 },
  formArt: {
    alignSelf: "center",
    width: 76,
    height: 70,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
    borderRadius: 23,
    backgroundColor: palette.mint,
  },
  formLabel: {
    marginTop: 14,
    marginBottom: 6,
    color: palette.ink,
    fontSize: 11,
    fontWeight: "900",
  },
  itemSuggestions: {
    maxHeight: 240,
    overflow: "hidden",
    marginTop: 5,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 14,
    backgroundColor: "#FFF",
  },
  itemSuggestion: {
    minHeight: 43,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 11,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: palette.line,
  },
  suggestionSource: { color: palette.green, fontSize: 7, fontWeight: "900" },
  twoColumns: { flexDirection: "row", gap: 10, alignItems: "flex-end" },
  quantityBlock: { width: 132 },
  stepper: {
    minHeight: 48,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 6,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 14,
    backgroundColor: "#FFF",
  },
  stepperButton: {
    width: 32,
    height: 32,
    paddingTop: 5,
    borderRadius: 9,
    backgroundColor: palette.mint,
    color: palette.green,
    fontSize: 18,
    fontWeight: "900",
    textAlign: "center",
  },
  stepperValue: { color: palette.ink, fontSize: 14, fontWeight: "900" },
  statusOptions: { gap: 7, marginBottom: 10 },
  statusOption: {
    minHeight: 53,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 9,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 15,
    backgroundColor: "#FFF",
  },
  statusOptionOn: { borderColor: "#7ABAA1", backgroundColor: "#EFF8F4" },
  statusOptionText: {
    flex: 1,
    color: palette.ink,
    fontSize: 11,
    fontWeight: "800",
  },
  cardFormHeading: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 12,
  },
  cardFormName: { color: palette.ink, fontSize: 17, fontWeight: "900" },
  cardFormBalance: { marginTop: 3, color: palette.muted, fontSize: 10 },
  previewBalance: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 12,
    padding: 13,
    borderRadius: 14,
    backgroundColor: "#E7F3ED",
  },
  previewLabel: { color: palette.muted, fontSize: 10, fontWeight: "800" },
  previewValue: { color: palette.ink, fontSize: 16, fontWeight: "900" },
  clarification: {
    marginTop: 12,
    padding: 11,
    borderRadius: 12,
    backgroundColor: "#EEF4F1",
    color: "#526B63",
    fontSize: 10,
    lineHeight: 15,
  },
  sheetLead: {
    marginBottom: 15,
    color: palette.muted,
    fontSize: 12,
    lineHeight: 18,
  },
  colorGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9 },
  colorOption: {
    width: "30%",
    alignItems: "center",
    gap: 7,
    padding: 10,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 14,
    backgroundColor: "#FFF",
  },
  colorSwatch: { width: 48, height: 33, borderRadius: 10 },
  colorName: { color: palette.ink, fontSize: 9, fontWeight: "800" },
  successArt: {
    alignSelf: "center",
    width: 72,
    height: 72,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 25,
    backgroundColor: palette.mint,
  },
  successMark: { color: palette.green, fontSize: 30, fontWeight: "900" },
  successStore: {
    marginTop: 16,
    color: palette.ink,
    fontSize: 18,
    fontWeight: "900",
    textAlign: "center",
  },
  successTotal: {
    marginTop: 5,
    color: palette.ink,
    fontSize: 37,
    fontWeight: "900",
    textAlign: "center",
  },
  successNote: {
    marginVertical: 15,
    color: palette.muted,
    fontSize: 10,
    textAlign: "center",
  },
  detailHero: { alignItems: "center", paddingVertical: 10 },
  storeBadgeLarge: {
    width: 65,
    height: 65,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 22,
    backgroundColor: palette.green,
  },
  storeBadgeLargeText: { color: "#FFF", fontSize: 24, fontWeight: "900" },
  detailStore: {
    marginTop: 10,
    color: palette.ink,
    fontSize: 18,
    fontWeight: "900",
    textAlign: "center",
  },
  detailDate: {
    marginTop: 4,
    color: palette.muted,
    fontSize: 10,
    textAlign: "center",
  },
  detailStats: { flexDirection: "row", gap: 6, marginVertical: 12 },
  detailStatCell: {
    flex: 1,
    minHeight: 62,
    justifyContent: "center",
    padding: 9,
    borderRadius: 13,
    backgroundColor: "#F0F5F2",
  },
  detailStatValue: {
    marginTop: 5,
    color: palette.ink,
    fontSize: 12,
    fontWeight: "900",
  },
  detailCardLine: {
    minHeight: 58,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 15,
    backgroundColor: "#F0F7F3",
  },
  detailCardName: { color: palette.ink, fontSize: 11, fontWeight: "900" },
  detailCardMeta: { marginTop: 2, color: palette.muted, fontSize: 9 },
  detailItem: {
    minHeight: 42,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 5,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: palette.line,
  },
  detailItemName: { flex: 1, color: palette.ink, fontSize: 10 },
  detailItemValue: { color: palette.ink, fontSize: 10, fontWeight: "900" },
  detailActions: { flexDirection: "row", gap: 7, marginTop: 10 },
  itemDetailGrid: { flexDirection: "row", gap: 7, marginVertical: 12 },
  detailLabel: { color: palette.muted, fontSize: 9, fontWeight: "800" },
  correctionRow: {
    minHeight: 75,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: 8,
    padding: 10,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 15,
    backgroundColor: "#FFF",
  },
  correctionName: { color: palette.ink, fontSize: 11, fontWeight: "900" },
  correctionInput: {
    minHeight: 37,
    marginTop: 5,
    paddingHorizontal: 8,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 10,
    backgroundColor: "#F8FAF9",
    color: palette.ink,
  },
  reportHero: {
    marginBottom: 14,
    padding: 18,
    borderRadius: 22,
    backgroundColor: palette.dark,
  },
  reportHeroGlyph: { color: "#BDE7D7", fontSize: 29 },
  reportHeroKicker: {
    marginTop: 10,
    color: "#BDE7D7",
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 1.2,
  },
  reportHeroTitle: {
    marginTop: 5,
    color: "#FFF",
    fontSize: 24,
    fontWeight: "900",
  },
  reportHeroBody: {
    marginTop: 6,
    color: "#D7ECE4",
    fontSize: 11,
    lineHeight: 17,
  },
  reportOption: {
    minHeight: 88,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 9,
    padding: 12,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 18,
    backgroundColor: "#FFF",
  },
  reportOptionCustom: { backgroundColor: "#F8F5FF" },
  reportOptionGlyph: {
    width: 45,
    height: 45,
    paddingTop: 11,
    borderRadius: 14,
    backgroundColor: palette.mint,
    color: palette.green,
    fontSize: 19,
    textAlign: "center",
  },
  originalStudioGlyph: {
    width: 45,
    height: 45,
    paddingTop: 9,
    borderRadius: 14,
    backgroundColor: "#EAE3F8",
    color: "#6852A3",
    fontSize: 22,
    fontWeight: "900",
    textAlign: "center",
  },
  reportOptionKicker: {
    color: palette.green,
    fontSize: 7,
    fontWeight: "900",
    letterSpacing: 1,
  },
  reportOptionTitle: {
    marginTop: 3,
    color: palette.ink,
    fontSize: 13,
    fontWeight: "900",
  },
  reportOptionNote: {
    marginTop: 3,
    color: palette.muted,
    fontSize: 9,
    lineHeight: 13,
  },
  reportOptionAction: {
    maxWidth: 83,
    padding: 7,
    borderRadius: 9,
    backgroundColor: "#EDF4F0",
    color: palette.green,
    fontSize: 8,
    lineHeight: 11,
    fontWeight: "900",
    textAlign: "center",
  },
  reportMiniButton: {
    maxWidth: 83,
    padding: 8,
    borderRadius: 10,
    backgroundColor: palette.dark,
  },
  reportMiniButtonText: {
    color: "#FFF",
    fontSize: 8,
    fontWeight: "900",
    textAlign: "center",
  },
  monthChip: {
    minHeight: 30,
    justifyContent: "center",
    marginTop: 6,
    marginRight: 5,
    paddingHorizontal: 8,
    borderRadius: 10,
    backgroundColor: "#EEF2F0",
  },
  monthChipOn: { backgroundColor: palette.green },
  monthChipText: { color: palette.muted, fontSize: 8, fontWeight: "800" },
  monthChipTextOn: { color: "#FFF" },
  reportTotal: {
    padding: 18,
    borderRadius: 20,
    backgroundColor: palette.green,
  },
  reportTotalLabel: {
    color: "#CBEADF",
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1,
  },
  reportTotalValue: {
    marginTop: 5,
    color: "#FFF",
    fontSize: 34,
    fontWeight: "900",
  },
  reportTotalNote: { marginTop: 3, color: "#D8EFE7", fontSize: 10 },
  reportStatRow: { flexDirection: "row", gap: 8, marginTop: 9 },
  reportStatCell: {
    flex: 1,
    padding: 12,
    borderRadius: 14,
    backgroundColor: "#F0F5F2",
  },
  reportStatValue: {
    marginTop: 4,
    color: palette.ink,
    fontSize: 14,
    fontWeight: "900",
  },
  chartCard: {
    marginTop: 12,
    padding: 13,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 17,
    backgroundColor: "#FFF",
  },
  chartTitle: { color: palette.ink, fontSize: 12, fontWeight: "900" },
  barChart: {
    height: 135,
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 5,
    marginTop: 12,
  },
  barSlot: {
    flex: 1,
    height: 115,
    alignItems: "center",
    justifyContent: "flex-end",
  },
  bar: {
    width: "70%",
    minHeight: 5,
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
    backgroundColor: palette.green,
  },
  barLabel: {
    width: "100%",
    marginTop: 4,
    color: palette.muted,
    fontSize: 6,
    textAlign: "center",
  },
  exportWarning: {
    marginTop: 8,
    padding: 10,
    borderRadius: 11,
    backgroundColor: "#F0F2F6",
    color: "#59667B",
    fontSize: 9,
    lineHeight: 14,
  },
  unlockedNote: {
    marginTop: 8,
    color: palette.green,
    fontSize: 9,
    fontWeight: "800",
    textAlign: "center",
  },
  exportButtons: { flexDirection: "row", gap: 8, marginTop: 8 },
  customHero: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 12,
  },
  customTitle: {
    marginTop: 3,
    color: palette.ink,
    fontSize: 20,
    fontWeight: "900",
  },
  customStats: {
    flexDirection: "row",
    gap: 7,
    marginBottom: 5,
    padding: 12,
    borderRadius: 16,
    backgroundColor: palette.dark,
  },
  customStatCell: { flex: 1, alignItems: "center" },
  customDetailLabel: {
    color: "#B9D8CE",
    fontSize: 8,
    fontWeight: "800",
    textAlign: "center",
  },
  customStatValue: {
    marginTop: 4,
    color: "#FFF",
    fontSize: 13,
    fontWeight: "900",
    textAlign: "center",
  },
  wrapChips: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
});
